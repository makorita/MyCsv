import java.util.*;
import java.io.*;
import java.nio.file.*;

public class MyJson{
	String value;
	LinkedHashMap<String,MyJson> childMap;
	
	public MyJson(){
		childMap=new LinkedHashMap<String,MyJson>();
	}
	
	public String getValue(){
		return value;
	}
	
	public void setValue(String value){
		this.value=value;
		childMap.clear();
	}
	
	public LinkedHashMap<String,MyJson> getChildMap(){
		return childMap;
	}
	
	public MyJson getChild(String key){
		return childMap.get(key);
	}
	
	public void put(String key,MyJson childJson){
		value=null;
		childMap.put(key,childJson);
	}
	
	public boolean isJson(){
		if(childMap.size()>0)return true;
		else return false;
	}
	
	/*
	public void loadJson(String srcPath) throws Exception{	//loadは順序を保持できない
		Path file = Paths.get(srcPath);
		String text = Files.readString(file);
		JSONObject srcJson = new JSONObject(text);
		recursiveLoad(this,srcJson);
	}
	
	private void recursiveLoad(MyJson curJson,JSONObject curSrcJson){
		for (String key : curSrcJson.keySet()) {
			Object value = curSrcJson.get(key);
			if (value instanceof String) {
				MyJson childJson=new MyJson();
				curJson.put(key,childJson);
				childJson.setValue((String)value);
				
				
			} else if (value instanceof JSONObject) {
				MyJson childJson=new MyJson();
				curJson.put(key,childJson);
				recursiveLoad(childJson,(JSONObject)value);
				
			} else {
				System.out.println(key + " is neither a String nor an Object");
				if(true)System.exit(0);
			}
		}
	}
	*/
	
	public void saveJson(String dstPath) throws Exception{
		PrintWriter wr=new PrintWriter(new FileWriter(dstPath));
		wr.print("{");
		if(isJson()){
			recursiveWrite(this,wr);
		}else{
			wr.print("\n"+getValue());
		}
		wr.print("\n}\n");	
		wr.close();
	}
	
	private void recursiveWrite(MyJson curJson,PrintWriter wr) throws Exception{
		boolean firstCheck=false;
		for (String key : curJson.getChildMap().keySet()) {
			MyJson childJson=curJson.getChildMap().get(key);
			
			if(firstCheck){
				if(childJson.isJson()){
					wr.print(",\n\""+key+"\" : {");
					recursiveWrite(childJson,wr);
					wr.print("\n}");
				}else{
					wr.print(",\n\""+key+"\" : \""+childJson.getValue()+"\"");
				}
			}else{
				if(childJson.isJson()){
					wr.print("\n\""+key+"\" : {");
					recursiveWrite(childJson,wr);
					wr.print("\n}");
				}else{
					wr.print("\n\""+key+"\" : \""+childJson.getValue()+"\"");
				}
				
				firstCheck=true;
			}
		}
	}
}
