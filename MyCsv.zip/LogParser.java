import java.util.*;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.*;

public class LogParser{
	public static LinkedHashMap<String,List<String>> getLogMap(String srcDirPath) throws Exception{	//ログリスト取得。returnMap<[ファイル名],[Log]>
		LinkedHashMap<String,List<String>> returnMap=new LinkedHashMap<String,List<String>>();
		
		ArrayList<File> fileList=FileLoader.loadFileList(srcDirPath,null,"jogai.txt");
		for(File curFile:fileList){
			//System.out.println(curFile.getName());
			List<String> lines =null;
			try{
				lines = Files.readAllLines(curFile.toPath());
			}catch(MalformedInputException e){
				CharsetDecoder decoder = Charset.forName("UTF-8")
					.newDecoder()
					.onMalformedInput(CodingErrorAction.IGNORE) // 壊れた文字を無視
					.onUnmappableCharacter(CodingErrorAction.IGNORE); // マッピングできない文字も無視

				try (BufferedReader reader = new BufferedReader(
						new InputStreamReader(Files.newInputStream(curFile.toPath()), decoder))) {
					lines = new ArrayList<>();
					String line;
					while ((line = reader.readLine()) != null) {
						lines.add(line);
					}
				}
			}
			returnMap.put(curFile.getName(),lines);
			//break;
		}
		
		return returnMap;
	}
	
	public static String getType(List<String> lines){	//コンフィグタイプ取得
		for(String curStr:lines){
			if(curStr.matches("service timestamps .*"))return "CISCO";
			if(curStr.matches("ASA Version .*"))return "CISCO_FW";
			if(curStr.matches("/c/.*"))return "ALTEON";
			if(curStr.matches("set system host-name .*"))return "JUNIPER";
		}
		
		return null;
	}
	
	public static void deleteFileAtFolder(String dirPath) throws Exception{
		File rootDir=new File(dirPath);
		File[] fileList=rootDir.listFiles();
		for(File curFile:fileList){
			if(!curFile.isFile())continue;
			
			curFile.delete();
		}
	}
}
