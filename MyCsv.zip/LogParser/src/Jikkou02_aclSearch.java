import java.io.*;
import java.util.*;

public class Jikkou02_aclSearch{
/*
javac -cp "./;lib/*" Jikkou02_aclSearch.java
java -cp "./;lib/*" Jikkou02_aclSearch
*/
	public static void main(String[] args) throws Exception{
		//検索Exl取得
		HashMap<String,String> configMap=ConfigLoader.loadConfig("../config.txt");
		NExcel searchExl=NExcelIO.loadExcel(configMap.get("aclSearchExl"),configMap.get("aclSearchSheet"));
		
		//configJsonMap取得
		HashMap<String,NJson> jsonMap=new HashMap<String,NJson>();
		File rootDir=new File(configMap.get("outputFolder"));
		File[] fileList=rootDir.listFiles();
		for(File curFile:fileList){
			NJson curJson=NJsonParser.loadJson(curFile);
			jsonMap.put(curJson.getChild("hostname").getValue(),curJson);
		}
		
		//outputJson準備
		NJson outputJson=new NJson();
		
		for(int rowIndex=0;rowIndex<searchExl.getContentSize();rowIndex++){	//検索条件回し
			//実行フラグチェック
			String jikkouFlag=searchExl.getValue(rowIndex,"実行フラグ");
			if(jikkouFlag==null)continue;
			
			//hostname取得
			String hostname=searchExl.getValue(rowIndex,"ホスト名");
			if(hostname==null)throw new IllegalArgumentException("hostname未取得:");
			outputJson.addPathChild("検索条件:"+String.format("%04d", rowIndex)+"##hostname",hostname);
			System.out.println(hostname);
			
			//acl番号取得
			String aclNum=searchExl.getValue(rowIndex,"acl番号");
			if(aclNum==null)throw new IllegalArgumentException("acl番号未取得:");
			//acl番号の整数化
			if(aclNum.matches("\\d+\\.\\d{2}"))aclNum=aclNum.substring(0,aclNum.indexOf("."));
			outputJson.addPathChild("検索条件:"+String.format("%04d", rowIndex)+"##acl番号",aclNum);
			
			//結果に検索条件セット
			if(searchExl.getValue(rowIndex,"許可_拒否")!=null)outputJson.addPathChild("検索条件:"+String.format("%04d", rowIndex)+"##許可_拒否",searchExl.getValue(rowIndex,"許可_拒否"));
			if(searchExl.getValue(rowIndex,"プロトコル")!=null)outputJson.addPathChild("検索条件:"+String.format("%04d", rowIndex)+"##プロトコル",searchExl.getValue(rowIndex,"プロトコル"));
			if(searchExl.getValue(rowIndex,"送信元IP")!=null)outputJson.addPathChild("検索条件:"+String.format("%04d", rowIndex)+"##送信元IP",searchExl.getValue(rowIndex,"送信元IP"));
			if(searchExl.getValue(rowIndex,"送信元ポート")!=null)outputJson.addPathChild("検索条件:"+String.format("%04d", rowIndex)+"##送信元ポート",searchExl.getValue(rowIndex,"送信元ポート"));
			if(searchExl.getValue(rowIndex,"宛先IP")!=null)outputJson.addPathChild("検索条件:"+String.format("%04d", rowIndex)+"##宛先IP",searchExl.getValue(rowIndex,"宛先IP"));
			if(searchExl.getValue(rowIndex,"宛先ポート")!=null)outputJson.addPathChild("検索条件:"+String.format("%04d", rowIndex)+"##宛先ポート",searchExl.getValue(rowIndex,"宛先ポート"));
			
			//aclJson取得
			NJson aclJson=jsonMap.get(hostname).getChild("acl").getChild(aclNum);
			List<NJson> aclList=aclJson.getChildList();
			List<NJson> resultList=null;
			
			//ogDB取得
			NJson ogDB=jsonMap.get(hostname).getChild("object-group");
			
			//許可・拒否
			resultList=new ArrayList<NJson>();
			for(NJson curJson:aclList){
				if(searchExl.getValue(rowIndex,"許可_拒否")==null)resultList.add(curJson);
				else if(curJson.getChild("許可")==null)resultList.add(curJson);
				else if(curJson.getChild("許可").getValue().equals(searchExl.getValue(rowIndex,"許可_拒否")))resultList.add(curJson);
			}
			
			//プロトコル
			aclList=resultList;
			resultList=new ArrayList<NJson>();
			for(NJson curJson:aclList){
				if(curJson.getChild("プロトコル")==null)resultList.add(curJson);
				else if(curJson.getChild("プロトコル").getValue().equals("ip"))resultList.add(curJson);
				else if(searchExl.getValue(rowIndex,"プロトコル")==null)resultList.add(curJson);
				else if(curJson.getChild("プロトコル").getValue().equals(searchExl.getValue(rowIndex,"プロトコル")))resultList.add(curJson);
			}
			if(jsonMap.get(hostname).getChild("機器タイプ").getValue().equals("CISCO_FW")){
				aclList=resultList;
				resultList=CiscoNJsonFilter.ciscoFWProtocolFilter(aclList,ogDB,searchExl.getValue(rowIndex,"プロトコル"));
			}
			
			//送信元IP
			if(jsonMap.get(hostname).getChild("機器タイプ").getValue().equals("CISCO")){
				aclList=resultList;
				resultList=CiscoNJsonFilter.ciscoIPFilter(aclList,"ソースIP","ソースWILD",new Address(searchExl.getValue(rowIndex,"送信元IP")));
			}else if(jsonMap.get(hostname).getChild("機器タイプ").getValue().equals("CISCO_FW")){
				aclList=resultList;
				resultList=CiscoNJsonFilter.ciscoFWIPFilter(aclList,"ソースIP","ソースMASK",new Address(searchExl.getValue(rowIndex,"送信元IP")));
				aclList=resultList;
				resultList=CiscoNJsonFilter.ciscoFWIPGrpFilterList(aclList,"ソースIPogName",ogDB,new Address(searchExl.getValue(rowIndex,"送信元IP")));
			}
			
			//送信元PORT
			if(searchExl.getValue(rowIndex,"送信元ポート")==null){
				aclList=resultList;
				resultList=CiscoNJsonFilter.ciscoPortFilter(aclList,"ソースPORT",null);
				if(jsonMap.get(hostname).getChild("機器タイプ").getValue().equals("CISCO_FW")){
					aclList=resultList;
					resultList=CiscoNJsonFilter.ciscoFWPortFilter(aclList,"ソースPORTogName",ogDB,null);
				}
				
			}else{
				aclList=resultList;
				resultList=CiscoNJsonFilter.ciscoPortFilter(aclList,"ソースPORT",Integer.parseInt(searchExl.getValue(rowIndex,"送信元ポート").substring(0,searchExl.getValue(rowIndex,"送信元ポート").indexOf("."))));
				if(jsonMap.get(hostname).getChild("機器タイプ").getValue().equals("CISCO_FW")){
					aclList=resultList;
					resultList=CiscoNJsonFilter.ciscoFWPortFilter(aclList,"ソースPORTogName",ogDB,Integer.parseInt(searchExl.getValue(rowIndex,"送信元ポート").substring(0,searchExl.getValue(rowIndex,"送信元ポート").indexOf("."))));
				}
			}
			
			//宛先IP
			if(jsonMap.get(hostname).getChild("機器タイプ").getValue().equals("CISCO")){
				aclList=resultList;
				resultList=CiscoNJsonFilter.ciscoIPFilter(aclList,"宛先IP","宛先WILD",new Address(searchExl.getValue(rowIndex,"宛先IP")));
				
			}else if(jsonMap.get(hostname).getChild("機器タイプ").getValue().equals("CISCO_FW")){
				aclList=resultList;
				resultList=CiscoNJsonFilter.ciscoFWIPFilter(aclList,"宛先IP","宛先MASK",new Address(searchExl.getValue(rowIndex,"宛先IP")));
				aclList=resultList;
				resultList=CiscoNJsonFilter.ciscoFWIPGrpFilterList(aclList,"宛先IPogName",ogDB,new Address(searchExl.getValue(rowIndex,"宛先IP")));
			}
			
			//宛先PORT
			if(searchExl.getValue(rowIndex,"宛先ポート")==null){
				aclList=resultList;
				resultList=CiscoNJsonFilter.ciscoPortFilter(aclList,"宛先PORT",null);
				if(jsonMap.get(hostname).getChild("機器タイプ").getValue().equals("CISCO_FW")){
					aclList=resultList;
					resultList=CiscoNJsonFilter.ciscoFWPortFilter(aclList,"宛先PORTogName",ogDB,null);
				}
				
			}else{
				aclList=resultList;
				resultList=CiscoNJsonFilter.ciscoPortFilter(aclList,"宛先PORT",Integer.parseInt(searchExl.getValue(rowIndex,"宛先ポート").substring(0,searchExl.getValue(rowIndex,"宛先ポート").indexOf("."))));
				if(jsonMap.get(hostname).getChild("機器タイプ").getValue().equals("CISCO_FW")){
					aclList=resultList;
					resultList=CiscoNJsonFilter.ciscoFWPortFilter(aclList,"宛先PORTogName",ogDB,Integer.parseInt(searchExl.getValue(rowIndex,"宛先ポート").substring(0,searchExl.getValue(rowIndex,"宛先ポート").indexOf("."))));
				}
			}
			
			//結果追加
			NJson tmpResultJson=new NJson();
			tmpResultJson.indexAddList(resultList);
			outputJson.getChild("検索条件:"+String.format("%04d", rowIndex)).put("match_acl",tmpResultJson);
			
			//break;
		}
		
		//Json出力
		if(outputJson.childSize()>0){
			PrintWriter wr=new PrintWriter(new FileWriter("../acl検索結果.json"));
			wr.println(outputJson.toPrettyJsonString());
			//System.out.println(outputJson.toPrettyJsonString());
			wr.close();
		}
	}
}
