import java.util.*;
import java.io.*;
import java.nio.file.*;

public class NJsonParser{
	private static String json;
	private static int pos;
	
	public static NJson loadJson(File srcFile) throws Exception{	//Jsonファイルのロード
		return loadJson(srcFile.getPath());
	}
	
	public static NJson loadJson(String srcPath) throws Exception{	//Jsonファイルのロード
		Path file=Paths.get(srcPath);
		json=Files.readString(file);
		pos=0;
		
		NJson returnJson=parseObject();
		skipWhitespace();
		if(pos!=json.length())throw new IllegalStateException("Extra characters after JSON");
		
		return returnJson;
	}
	
	//基本:{...}をオブジェクトとしてパース
	private static NJson parseObject(){
		if(json.charAt(pos)!='{'){
			throw new IllegalArgumentException("Expected '{' at position "+pos);
		}
		pos++;
		skipWhitespace();
		NJson node=new NJson();
		
		boolean first=true;	//最初かどうかチェック。2回目以降は,で始まる。
		while(pos<json.length() && json.charAt(pos)!='}'){
			if(!first){	//,をスキップ
				if(json.charAt(pos)!=','){
					throw new IllegalArgumentException("Expected ',' at position "+pos);
				}
				pos++;
				skipWhitespace();
			}
			first=false;
			
			//キー読み取り
			String key=parseString();
			skipWhitespace();
			if(json.charAt(pos)!=':'){
				throw new IllegalArgumentException("Expected ':' at position "+pos);
			}
			pos++;
			skipWhitespace();
			
			//値はオブジェクトか文字列
			NJson child;
			if(json.charAt(pos)=='{'){
				child=parseObject();
			}else if(json.charAt(pos)=='"'){
				String value=parseString();
				child=new NJson();
				child.setValue(value);
			}else{
				System.out.println(json.charAt(pos));
				throw new IllegalArgumentException("Unexpected character at position "+pos);
			}
			node.put(key,child);
			skipWhitespace();
		}
		
		if(pos>=json.length() || json.charAt(pos)!='}'){
			throw new IllegalArgumentException("Expected '}' at position "+pos);
		}
		pos++;
		
		return node;
	}
	
	private static String parseString(){	//""で囲まれた文字列を取得
		if(json.charAt(pos)!='"'){
			throw new IllegalArgumentException("Expected '\"' at position "+pos);
		}
		pos++;
		StringBuilder sb=new StringBuilder();
		while(pos<json.length()){
			char c=json.charAt(pos);
			if(c=='\\'){	//簡易エスケープ対応\"だけ対応
				pos++;
				if(pos>=json.length())throw new IllegalArgumentException("Invalid escape");
				
				char next=json.charAt(pos++);
				if(next=='"')sb.append('"');
				else if(next=='\\')sb.append('\\');
				else throw new IllegalArgumentException("\\ escape unsupported: "+next);
			}else if(c=='"'){
				pos++;
				break;
			}else{
				sb.append(c);
				pos++;
			}
		}
		
		return sb.toString();
	}
	
	private static void skipWhitespace(){	//空白文字をスキップ。posを進める。
		while(pos<json.length() && Character.isWhitespace(json.charAt(pos))){
			pos++;
		}
	}
}
