import java.util.*;
import java.io.*;

public class CiscoNJsonFilter{
/*
NJsonの子供のフィルタは難しいためList<NJson>をフィルタしていく
*/
	public static List<NJson> ciscoFWProtocolFilter(List<NJson> srcList,NJson ogDB,String searcProto){
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curAcl:srcList){
			if(curAcl.getChild("プロトコルogName")==null){
				returnList.add(curAcl);
				continue;
			}
			if(searcProto==null)continue;
			
			String curOgName=curAcl.getChild("プロトコルogName").getValue();
			NJson ogJson=ogDB.getChild(curOgName);
			boolean containFlag=recursiveContainProtoCheck(ogJson,ogDB,searcProto);
			if(containFlag)returnList.add(curAcl);
		}
		
		return returnList;
	}
	
	private static boolean recursiveContainProtoCheck(NJson ogJson,NJson ogDB,String searcProto){
		Iterator<NJson> it=ogJson.getChild("child").childIterator();
		while(it.hasNext()){
			NJson memberJson=it.next();
			if(memberJson.getChild("ogType").getValue().equals("protocol")){
				if(memberJson.getChild("protocol").getValue().equals(searcProto))return true;
				
			}else if(memberJson.getChild("ogType").getValue().equals("group")){
				NJson childJson=ogDB.getChild(memberJson.getChild("ogName").getValue());
				boolean childBoolean=recursiveContainProtoCheck(childJson,ogDB,searcProto);
				if(childBoolean)return true;
			}else throw new IllegalArgumentException("想定外メンバーJson:"+memberJson.toPrettyJsonString());
		}
		
		return false;
	}
	
	public static List<NJson> ciscoIPFilter(List<NJson> srcList,String ipPath,String wildPath,Address searchedIP){
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curJson:srcList){
			if(searchedIP==null){
				returnList.add(curJson);
				continue;
			}
			if(curJson.getChild(ipPath)==null){
				returnList.add(curJson);
				continue;
			}
			String curIP=curJson.getChild(ipPath).getValue();
			long curWildBit=AddressUtility.getBit(curJson.getChild(wildPath).getValue());
			long curMaskBit=AddressUtility.reverseBit(curWildBit);
			String curMask=AddressUtility.getStrExp(curMaskBit);
			Address curAddr=new Address(curIP,curMask);
			if(AddressUtility.contains(curAddr,searchedIP))returnList.add(curJson);
		}
		
		return returnList;
	}
	
	public static List<NJson> ciscoFWIPFilter(List<NJson> srcList,String ipPath,String maskPath,Address searchedIP){
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curJson:srcList){
			if(searchedIP==null){
				returnList.add(curJson);
				continue;
			}
			if(curJson.getChild(ipPath)==null){
				returnList.add(curJson);
				continue;
			}
			String curIP=curJson.getChild(ipPath).getValue();
			String curMask=curJson.getChild(maskPath).getValue();
			Address curAddr=new Address(curIP,curMask);
			if(AddressUtility.contains(curAddr,searchedIP))returnList.add(curJson);
		}
		
		return returnList;
	}
	
	public static List<NJson> ciscoFWIPGrpFilterList(List<NJson> srcList,String ogPath,NJson ogDB,Address searchedIP){
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curJson:srcList){
			if(searchedIP==null){
				returnList.add(curJson);
				continue;
			}
			if(curJson.getChild(ogPath)==null){
				returnList.add(curJson);
				continue;
			}
			
			String curOgName=curJson.getChild(ogPath).getValue();
			NJson ogJson=ogDB.getChild(curOgName);
			boolean containFlag=recursiveContainIPCheck(ogJson,ogDB,searchedIP);
			if(containFlag)returnList.add(curJson);
		}
		
		return returnList;
	}
	
	private static boolean recursiveContainIPCheck(NJson ogJson,NJson ogDB,Address searchedIP){
		Iterator<NJson> it=ogJson.getChild("child").childIterator();
		while(it.hasNext()){
			NJson memberJson=it.next();
			if(memberJson.getChild("ogType").getValue().equals("network")){
				Address tmpAddr=new Address(memberJson.getChild("ip").getValue(),memberJson.getChild("mask").getValue());
				if(AddressUtility.contains(tmpAddr,searchedIP))return true;
			}else if(memberJson.getChild("ogType").getValue().equals("group")){
				NJson childJson=ogDB.getChild(memberJson.getChild("ogName").getValue());
				boolean childBoolean=recursiveContainIPCheck(childJson,ogDB,searchedIP);
				if(childBoolean)return true;
			}else throw new IllegalArgumentException("想定外メンバーJson:"+memberJson.toPrettyJsonString());
		}
		
		return false;
	}
	
	public static List<NJson> ciscoPortFilter(List<NJson> srcList,String portPath,Integer port){
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curJson:srcList){
			if(curJson.getChild(portPath)==null){	//any扱い
				returnList.add(curJson);
				continue;
			}
			if(port==null)continue;	//ポートの場合だけフィルタする。
			
			String curPort=curJson.getChild(portPath).getValue();
			if(curPort.matches("eq \\d+")){
				String[] word=curPort.split(" ");
				if(port==Integer.parseInt(word[1]))returnList.add(curJson);
			}else if(curPort.matches("gt \\d+")){
				String[] word=curPort.split(" ");
				if(port>Integer.parseInt(word[1]))returnList.add(curJson);
			}else if(curPort.matches("range \\d+ \\d+")){
				String[] word=curPort.split(" ");
				if(port>=Integer.parseInt(word[1]) && port<=Integer.parseInt(word[2]))returnList.add(curJson);
			}else throw new IllegalArgumentException("想定外PORT:"+curPort);
		}
		
		return returnList;
	}
	
	public static List<NJson> ciscoFWPortFilter(List<NJson> srcList,String ogPath,NJson ogDB,Integer port){
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curJson:srcList){
			if(curJson.getChild(ogPath)==null){
				returnList.add(curJson);
				continue;
			}
			if(port==null){	//ポートの場合だけフィルタする。
				continue;
			}
			
			String curOgName=curJson.getChild(ogPath).getValue();
			NJson ogJson=ogDB.getChild(curOgName);
			boolean containFlag=recursiveContainPortCheck(ogJson,ogDB,port);
			if(containFlag)returnList.add(curJson);
		}
		
		return returnList;
	}
	
	private static boolean recursiveContainPortCheck(NJson ogJson,NJson ogDB,Integer port){
		Iterator<NJson> it=ogJson.getChild("child").childIterator();
		while(it.hasNext()){
			NJson memberJson=it.next();
			if(memberJson.getChild("ogType").getValue().equals("port")){
				String curPort=memberJson.getChild("port").getValue();
				if(curPort.matches("eq \\d+")){
					String[] word=curPort.split(" ");
					if(port==Integer.parseInt(word[1]))return true;
				}else if(curPort.matches("gt \\d+")){
					String[] word=curPort.split(" ");
					if(port>Integer.parseInt(word[1]))return true;
				}else if(curPort.matches("range \\d+ \\d+")){
					String[] word=curPort.split(" ");
					if(port>=Integer.parseInt(word[1]) && port<=Integer.parseInt(word[2]))return true;
				}else throw new IllegalArgumentException("想定外PORT:"+curPort);
				
			}else if(memberJson.getChild("ogType").getValue().equals("group")){
				NJson childJson=ogDB.getChild(memberJson.getChild("ogName").getValue());
				boolean childBoolean=recursiveContainPortCheck(childJson,ogDB,port);
				if(childBoolean)return true;
				
			}else throw new IllegalArgumentException("想定外メンバーJson:"+memberJson.toPrettyJsonString());
		}
		
		return false;
	}
	
}
