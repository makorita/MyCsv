import java.util.*;
import java.io.*;

public class CiscoNJsonFilter{
/*
List<NJson>⇒フィルタ⇒List<NJson>
NJsonの子供のフィルタは難しいためList<NJson>をフィルタしていく
階層の違うNJsonを返さないといけない場合はStringで返す
*/
	public static List<NJson> hostnameMatchFilter(List<NJson> srcList,String hostnameStr){	//ホスト名を含むコンフィグリスト取得
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curJson:srcList){
			if(hostnameStr==null)returnList.add(curJson);
			else if(curJson.getChild("hostname").getValue().contains(hostnameStr))returnList.add(curJson);
		}
		
		return returnList;
	}

	public static List<NJson> getIfResultList(NJson curConfig,Address searchedIP,boolean exactFlag){	//Cisco I/Fのip,secondaryIP,standbyIPに一致、含まれるものをフィルタ
		List<NJson> returnList=new ArrayList<NJson>();
		
		NJson ifRoot=curConfig.getChild("interface");
		Iterator<NJson> ifIt=ifRoot.childIterator();
		while(ifIt.hasNext()){
			NJson curIf=ifIt.next();
			
			if(curIf.getChild("ip")!=null){
				Address curAddr=new Address(curIf.getChild("ip").getValue(),curIf.getChild("mask").getValue());
				if((exactFlag && curAddr.getAddress()==searchedIP.getAddress()) || (!exactFlag && AddressUtility.contains(curAddr,searchedIP))){
					NJson resultJson=new NJson();
					resultJson.put("機器タイプ",curConfig.getChild("機器タイプ").getValue());
					resultJson.put("hostname",curConfig.getChild("hostname").getValue());
					resultJson.put("ifName",curIf.getChild("ifName").getValue());
					if(curIf.getChild("nameif")!=null)resultJson.put("nameif",curIf.getChild("nameif").getValue());
					resultJson.put("ip",curIf.getChild("ip").getValue());
					resultJson.put("mask",curIf.getChild("mask").getValue());
					if(curIf.getChild("acl_in")!=null)resultJson.put("acl_in",curIf.getChild("acl_in").getValue());
					if(curIf.getChild("acl_out")!=null)resultJson.put("acl_out",curIf.getChild("acl_out").getValue());
					returnList.add(resultJson);
				}
			}
			
			if(curIf.getChild("secondary")!=null){	//セカンダリIPチェック
				NJson secRoot=curIf.getChild("secondary");
				Iterator<NJson> secIt=secRoot.childIterator();
				while(secIt.hasNext()){
					NJson curSec=secIt.next();
					Address curAddr=new Address(curSec.getChild("ip").getValue(),curSec.getChild("mask").getValue());
					if((exactFlag && curAddr.getAddress()==searchedIP.getAddress()) || (!exactFlag && AddressUtility.contains(curAddr,searchedIP))){
						NJson resultJson=new NJson();
						resultJson.put("機器タイプ",curConfig.getChild("機器タイプ").getValue());
						resultJson.put("hostname",curConfig.getChild("hostname").getValue());
						resultJson.put("ifName",curIf.getChild("ifName").getValue());
						resultJson.put("secondary_ip",curSec.getChild("ip").getValue());
						resultJson.put("secondary_mask",curSec.getChild("mask").getValue());
						if(curIf.getChild("acl_in")!=null)resultJson.put("acl_in",curIf.getChild("acl_in").getValue());
						if(curIf.getChild("acl_out")!=null)resultJson.put("acl_out",curIf.getChild("acl_out").getValue());
						returnList.add(resultJson);
					}
				}
			}
			
			if(!exactFlag)continue;
			if(curIf.getChild("standby")!=null){	//standbyIPチェック
				NJson standbyRoot=curIf.getChild("standby");
				Iterator<NJson> standbyIt=standbyRoot.childIterator();
				while(standbyIt.hasNext()){
					NJson curStandby=standbyIt.next();
					Address curAddr=new Address(curStandby.getChild("ip").getValue());
					if(exactFlag && curAddr.getAddress()==searchedIP.getAddress()){
						NJson resultJson=new NJson();
						resultJson.put("機器タイプ",curConfig.getChild("機器タイプ").getValue());
						resultJson.put("hostname",curConfig.getChild("hostname").getValue());
						resultJson.put("ifName",curIf.getChild("ifName").getValue());
						resultJson.put("standby_IP",curStandby.getChild("ip").getValue());
						if(curIf.getChild("acl_in")!=null)resultJson.put("acl_in",curIf.getChild("acl_in").getValue());
						if(curIf.getChild("acl_out")!=null)resultJson.put("acl_out",curIf.getChild("acl_out").getValue());
						returnList.add(resultJson);
					}
				}
			}
		}
		
		return returnList;
	}

	public static List<NJson> getRoutingResultList(NJson curConfig,Address searchedIP){
		List<NJson> returnList=new ArrayList<NJson>();
		
		if(curConfig.getChild("log_route")!=null){
			NJson logRouteRoot=curConfig.getChild("log_route");
			Iterator<NJson> logRouteIt=logRouteRoot.childIterator();
			while(logRouteIt.hasNext()){
				NJson curLogRoute=logRouteIt.next();
				Address curAddr=new Address(curLogRoute.getChild("宛先ネットワーク").getValue(),Integer.parseInt(curLogRoute.getChild("宛先マスク長").getValue()));
				if(AddressUtility.contains(curAddr,searchedIP)){
					NJson resultJson=new NJson();
					resultJson.put("hostname",curConfig.getChild("hostname").getValue());
					resultJson.put("raw_output",curLogRoute.getChild("raw_output").getValue());
					resultJson.put("宛先ネットワーク",curLogRoute.getChild("宛先ネットワーク").getValue());
					resultJson.put("宛先マスク長",curLogRoute.getChild("宛先マスク長").getValue());
					resultJson.put("ネクストホップ",curLogRoute.getChild("ネクストホップ").getValue());
					returnList.add(resultJson);
				}
			}
			
		}else if(curConfig.getChild("static_route")!=null){
			NJson staticRoot=curConfig.getChild("static_route");
			Iterator<NJson> staticIt=staticRoot.childIterator();
			while(staticIt.hasNext()){
				NJson curStatic=staticIt.next();
				Address curAddr=new Address(curStatic.getChild("宛先ネットワーク").getValue(),curStatic.getChild("宛先マスク").getValue());
				if(AddressUtility.contains(curAddr,searchedIP)){
					NJson resultJson=new NJson();
					resultJson.put("hostname",curConfig.getChild("hostname").getValue());
					resultJson.put("raw_config",curStatic.getChild("raw_config").getValue());
					resultJson.put("宛先ネットワーク",curStatic.getChild("宛先ネットワーク").getValue());
					resultJson.put("宛先マスク",curStatic.getChild("宛先マスク").getValue());
					resultJson.put("ネクストホップ",curStatic.getChild("ネクストホップ").getValue());
					returnList.add(resultJson);
				}
			}
		}
		
		return returnList;
	}
	
	public static List<NJson> getNatResultList(NJson curConfig,Address searchedIP){
		List<NJson> returnList=new ArrayList<NJson>();
		
		if(curConfig.getChild("nat")!=null){
			NJson natRoot=curConfig.getChild("nat");
			Iterator<NJson> natIt=natRoot.childIterator();
			while(natIt.hasNext()){
				NJson curNat=natIt.next();
				String befIP=curNat.getChild("befIP").getValue();
				String aftIP=curNat.getChild("aftIP").getValue();
				if(curNat.getChild("nat_mask")!=null){
					befIP+=curNat.getChild("nat_mask").getValue();
					aftIP+=curNat.getChild("nat_mask").getValue();
				}
				Address befAddr=new Address(befIP);
				Address aftAddr=new Address(aftIP);
				
				if(AddressUtility.contains(befAddr,searchedIP) || AddressUtility.contains(aftAddr,searchedIP)){
					NJson resultJson=new NJson();
					resultJson.put("hostname",curConfig.getChild("hostname").getValue());
					resultJson.put("raw_config",curNat.getChild("raw_config").getValue());
					if(AddressUtility.contains(befAddr,searchedIP)){
						resultJson.put("beforeIP",curNat.getChild("befIP").getValue());
						resultJson.put("afterIP",curNat.getChild("aftIP").getValue());
					}else{
						resultJson.put("beforeIP",curNat.getChild("aftIP").getValue());
						resultJson.put("afterIP",curNat.getChild("befIP").getValue());
					}
					returnList.add(resultJson);
				}
			}
		}
		
		return returnList;
	}
	
	public static List<NJson> ciscoPermitFilter(List<NJson> srcList,String permitStr){
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curAcl:srcList){
			if(curAcl.getChild("許可")==null){
				continue;
			}
			if(permitStr==null){
				returnList.add(curAcl);
				continue;
			}
			
			String curPermit=curAcl.getChild("許可").getValue();
			if(curPermit.equals(permitStr))returnList.add(curAcl);
		}
		
		return returnList;
	}
	
	public static List<NJson> ciscoProtocolFilter(List<NJson> srcList,String searcProto){
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curAcl:srcList){
			if(curAcl.getChild("プロトコル")==null)returnList.add(curAcl);
			else if(curAcl.getChild("プロトコル").getValue().equals("ip"))returnList.add(curAcl);
			else if(searcProto==null)returnList.add(curAcl);
			else if(curAcl.getChild("プロトコル").getValue().equals(searcProto))returnList.add(curAcl);
		}
		
		return returnList;
	}
	
	public static List<NJson> ciscoFWProtocolFilter(List<NJson> srcList,NJson ogDB,String searcProto){
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curAcl:srcList){
			if(curAcl.getChild("プロトコルogName")==null){
				returnList.add(curAcl);
				continue;
			}
			if(searcProto==null)continue;
			
			String curOgName=curAcl.getChild("プロトコルogName").getValue();
			NJson ogJson=ogDB.getChild(curOgName);
			boolean containFlag=recursiveContainProtoCheck(ogJson,ogDB,searcProto);
			if(containFlag)returnList.add(curAcl);
		}
		
		return returnList;
	}
	
	private static boolean recursiveContainProtoCheck(NJson ogJson,NJson ogDB,String searcProto){
		Iterator<NJson> it=ogJson.getChild("child").childIterator();
		while(it.hasNext()){
			NJson memberJson=it.next();
			if(memberJson.getChild("ogType").getValue().equals("protocol")){
				if(memberJson.getChild("protocol").getValue().equals(searcProto))return true;
				
			}else if(memberJson.getChild("ogType").getValue().equals("group")){
				NJson childJson=ogDB.getChild(memberJson.getChild("ogName").getValue());
				boolean childBoolean=recursiveContainProtoCheck(childJson,ogDB,searcProto);
				if(childBoolean)return true;
			}else throw new IllegalArgumentException("想定外メンバーJson:"+memberJson.toPrettyJsonString());
		}
		
		return false;
	}
	
	public static List<NJson> ciscoIPFilter(List<NJson> srcList,String ipPath,String wildPath,Address searchedIP){	//Ciscoのaccess-listフィルタ
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curJson:srcList){
			if(searchedIP==null){
				returnList.add(curJson);
				continue;
			}
			if(curJson.getChild(ipPath)==null){
				returnList.add(curJson);
				continue;
			}
			String curIP=curJson.getChild(ipPath).getValue();
			long curWildBit=AddressUtility.getBit(curJson.getChild(wildPath).getValue());
			long curMaskBit=AddressUtility.reverseBit(curWildBit);
			String curMask=AddressUtility.getStrExp(curMaskBit);
			Address curAddr=new Address(curIP,curMask);
			if(AddressUtility.contains(curAddr,searchedIP))returnList.add(curJson);
		}
		
		return returnList;
	}
	
	public static List<NJson> ciscoFWIPFilter(List<NJson> srcList,String ipPath,String maskPath,Address searchedIP){	//ASAのaccess-listフィルタ。ip,mask表示
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curJson:srcList){
			if(searchedIP==null){
				returnList.add(curJson);
				continue;
			}
			if(curJson.getChild(ipPath)==null){
				returnList.add(curJson);
				continue;
			}
			String curIP=curJson.getChild(ipPath).getValue();
			String curMask=curJson.getChild(maskPath).getValue();
			Address curAddr=new Address(curIP,curMask);
			if(AddressUtility.contains(curAddr,searchedIP))returnList.add(curJson);
		}
		
		return returnList;
	}
	
	public static List<NJson> ciscoFWIPGrpFilterList(List<NJson> srcList,String ogPath,NJson ogDB,Address searchedIP){	//ASAのaccess-listフィルタ。ネットワークオブジェクト
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curJson:srcList){
			if(searchedIP==null){
				returnList.add(curJson);
				continue;
			}
			if(curJson.getChild(ogPath)==null){
				returnList.add(curJson);
				continue;
			}
			
			String curOgName=curJson.getChild(ogPath).getValue();
			NJson ogJson=ogDB.getChild(curOgName);
			boolean containFlag=recursiveContainIPCheck(ogJson,ogDB,searchedIP);
			if(containFlag)returnList.add(curJson);
		}
		
		return returnList;
	}
	
	private static boolean recursiveContainIPCheck(NJson ogJson,NJson ogDB,Address searchedIP){
		Iterator<NJson> it=ogJson.getChild("child").childIterator();
		while(it.hasNext()){
			NJson memberJson=it.next();
			if(memberJson.getChild("ogType").getValue().equals("network")){
				Address tmpAddr=new Address(memberJson.getChild("ip").getValue(),memberJson.getChild("mask").getValue());
				if(AddressUtility.contains(tmpAddr,searchedIP))return true;
			}else if(memberJson.getChild("ogType").getValue().equals("group")){
				NJson childJson=ogDB.getChild(memberJson.getChild("ogName").getValue());
				boolean childBoolean=recursiveContainIPCheck(childJson,ogDB,searchedIP);
				if(childBoolean)return true;
			}else throw new IllegalArgumentException("想定外メンバーJson:"+memberJson.toPrettyJsonString());
		}
		
		return false;
	}
	
	public static List<NJson> ciscoPortFilter(List<NJson> srcList,String portPath,Integer port){
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curJson:srcList){
			if(curJson.getChild(portPath)==null){	//any扱い
				returnList.add(curJson);
				continue;
			}
			if(port==null)continue;	//ポートの場合だけフィルタする。
			
			String curPort=curJson.getChild(portPath).getValue();
			if(curPort.matches("eq \\d+")){
				String[] word=curPort.split(" ");
				if(port==Integer.parseInt(word[1]))returnList.add(curJson);
			}else if(curPort.matches("gt \\d+")){
				String[] word=curPort.split(" ");
				if(port>Integer.parseInt(word[1]))returnList.add(curJson);
			}else if(curPort.matches("range \\d+ \\d+")){
				String[] word=curPort.split(" ");
				if(port>=Integer.parseInt(word[1]) && port<=Integer.parseInt(word[2]))returnList.add(curJson);
			}else throw new IllegalArgumentException("想定外PORT:"+curPort);
		}
		
		return returnList;
	}
	
	public static List<NJson> ciscoFWPortFilter(List<NJson> srcList,String ogPath,NJson ogDB,Integer port){
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson curJson:srcList){
			if(curJson.getChild(ogPath)==null){
				returnList.add(curJson);
				continue;
			}
			if(port==null){	//ポートの場合だけフィルタする。
				continue;
			}
			
			String curOgName=curJson.getChild(ogPath).getValue();
			NJson ogJson=ogDB.getChild(curOgName);
			boolean containFlag=recursiveContainPortCheck(ogJson,ogDB,port);
			if(containFlag)returnList.add(curJson);
		}
		
		return returnList;
	}
	
	private static boolean recursiveContainPortCheck(NJson ogJson,NJson ogDB,Integer port){
		Iterator<NJson> it=ogJson.getChild("child").childIterator();
		while(it.hasNext()){
			NJson memberJson=it.next();
			if(memberJson.getChild("ogType").getValue().equals("port")){
				String curPort=memberJson.getChild("port").getValue();
				if(curPort.matches("eq \\d+")){
					String[] word=curPort.split(" ");
					if(port==Integer.parseInt(word[1]))return true;
				}else if(curPort.matches("gt \\d+")){
					String[] word=curPort.split(" ");
					if(port>Integer.parseInt(word[1]))return true;
				}else if(curPort.matches("range \\d+ \\d+")){
					String[] word=curPort.split(" ");
					if(port>=Integer.parseInt(word[1]) && port<=Integer.parseInt(word[2]))return true;
				}else throw new IllegalArgumentException("想定外PORT:"+curPort);
				
			}else if(memberJson.getChild("ogType").getValue().equals("group")){
				NJson childJson=ogDB.getChild(memberJson.getChild("ogName").getValue());
				boolean childBoolean=recursiveContainPortCheck(childJson,ogDB,port);
				if(childBoolean)return true;
				
			}else throw new IllegalArgumentException("想定外メンバーJson:"+memberJson.toPrettyJsonString());
		}
		
		return false;
	}
	
}
