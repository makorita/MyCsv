import java.util.*;

public class AddressUtility{
	public static boolean isLegalAddrStr(String addrStr){	//アドレス形式をチェック
		if(!addrStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}(/\\d{1,2})*"))return false;
		
		String[] word1=addrStr.split("/");
		String[] word2=word1[0].split("\\.");
		for(String curStr:word2){
			if(Integer.parseInt(curStr)<0)return false;
			if(Integer.parseInt(curStr)>255)return false;
		}
		
		if(word1.length>=2){
			if(Integer.parseInt(word1[1])<0)return false;
			if(Integer.parseInt(word1[1])>32)return false;
		}
		
		return true;
	}
	
	public static boolean isLegalMask(String maskStr){	//マスク文字列が合法か
		if(!isLegalAddrStr(maskStr))return false;;
		
		long maskBit=getBit(maskStr);
		return isLegalMask(maskBit);
	}
	
	public static boolean isLegalMask(long maskBit){	//ビット列がマスク形式かチェック
		if(maskBit<0)return false;
		long maxLong=Long.parseLong("11111111111111111111111111111111",2);
		if(maskBit>maxLong)return false;
		
		boolean checkBool=true;
		for(int i=0;i<32;i++){	//ビット列を下から確認。1度ビット列が立った後、0がきたらfalse
			if(checkBool && (maskBit&1)==1){
				checkBool=false;
			}else if(!checkBool && (maskBit&1)==0)return false;
			maskBit=maskBit>>>1;
		}
		
		return true;
	}
	
	public static long getBit(String addrStr){	//アドレス形式をビット列に変換
		if(!isLegalAddrStr(addrStr))throw new IllegalArgumentException("想定外アドレス:"+addrStr);
		
		long returnBit=0;
		
		String[] word1=addrStr.split("/");
		String[] word2=word1[0].split("\\.");
		for(int i=0;i<word2.length;i++){
			returnBit=returnBit|Long.parseLong(word2[i]);
			if(i<word2.length-1)returnBit=returnBit<<8;
		}
		
		return returnBit;
	}
	
	public static String getStrExp(long tmpAddr){	//ビット列をアドレス形式に変換
		String returnStr=null;
		
		for(int i=0;i<4;i++){
			long tmpOct=tmpAddr&Long.parseLong("11111111", 2);
			if(returnStr==null)returnStr=String.valueOf(tmpOct);
			else returnStr=String.valueOf(tmpOct)+"."+returnStr;
			
			tmpAddr=tmpAddr>>>8;
		}
		
		return returnStr;
	}
	
	public static long getMaskBit(int maskLength){	//マスク長をビット列に変換
		if(maskLength<0 || maskLength>32)throw new IllegalArgumentException("想定外マスク長:"+maskLength);
		
		String tmpStr="1".repeat(maskLength)+"0".repeat(32-maskLength);
		long returnBit=Long.parseLong(tmpStr,2);
		
		return returnBit;
	}
	
	public static int getMaskLength(long maskBit){	//ビット列のマスク長を返す
		if(!AddressUtility.isLegalMask(maskBit))throw new IllegalArgumentException("想定外マスクビット:"+maskBit);
		
		return Long.toBinaryString(maskBit).replaceAll("0","").length();
	}
	
	public static long reverseBit(long srcBit){	//ビットを32ビット分反転
		return Long.parseLong("11111111111111111111111111111111",2)&(~srcBit);
	}
	
	public static long getNetwork(Address tmpAddr){	//ネットワークアドレス
		return tmpAddr.getAddress()&tmpAddr.getMask();
	}
	
	public static long getBroadcast(Address tmpAddr){	//ブロードキャストアドレス
		return tmpAddr.getAddress()|reverseBit(tmpAddr.getMask());
	}
	
	public static boolean contains(Address tmpAddr,Address taisyouAddr){	//対象がレンジに含まれるかどうか
		long beginBit=getNetwork(tmpAddr);
		long endBit=getBroadcast(tmpAddr);
		long taisyouBegin=getNetwork(taisyouAddr);
		long taisyouEnd=getBroadcast(taisyouAddr);
		
		if(beginBit<=taisyouBegin && endBit>=taisyouEnd)return true;
		else return false;
	}
}
