import java.util.*;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;

public class SearchWindow extends JFrame{
	JTextField hostnameText;
	JTextField ipText;
	JCheckBox ifCheck;
	JCheckBox routingCheck;
	JCheckBox natCheck;
	JButton searchIPButton;
	JButton searchContainIPButton;
	
	public SearchWindow() {
		super("IP検索");
		
		//ボタンに日本語表示させるため
		System.setProperty("file.encoding", "UTF-8");
		
		//位置サイズ決め
		setBounds(300, 300, 250, 180);
		
		//クローズボタン定義
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setLayout(null); 
		
		// ラベル作成
		JLabel hostnameLabel = new JLabel("ホスト名：");
		hostnameLabel.setBounds(10, 10, 80, 20); // x, y, 幅, 高さ
		
		// テキストボックス作成（幅20文字分）
		hostnameText = new JTextField(20);
		hostnameText.setBounds(90, 10, 130, 20); // x, y, 幅, 高さ
		
		// ラベル作成
		JLabel ipLabel = new JLabel("IPアドレス：");
		ipLabel.setBounds(10, 40, 80, 20); // x, y, 幅, 高さ
		
		// テキストボックス作成（幅20文字分）
		ipText = new JTextField(20);
		ipText.setBounds(90, 40,130, 20); // x, y, 幅, 高さ
		
		// チェックボックス作成（初期は未チェック）
		ifCheck = new JCheckBox("I/F",true);
		ifCheck.setBounds(10, 60, 60, 40);
		// フォントサイズを大きくする（チェックマークと文字が大きくなる）
		ifCheck.setFont(new Font("Dialog", Font.PLAIN, 15));
		
		routingCheck = new JCheckBox("Routing");
		routingCheck.setBounds(70, 60, 80, 40);
		routingCheck.setFont(new Font("Dialog", Font.PLAIN, 15));
		
		natCheck = new JCheckBox("NAT");
		natCheck.setBounds(160, 60, 60, 40);
		natCheck.setFont(new Font("Dialog", Font.PLAIN, 15));
		
		// ボタン作成
		searchIPButton = new JButton("IP検索");
		searchIPButton.setBounds(10, 100, 70, 30); // x, y, 幅, 高さ
		searchIPButton.setActionCommand("search");
		
		// ボタン作成
		searchContainIPButton = new JButton("IP含む検索");
		searchContainIPButton.setBounds(90, 100, 100, 30); // x, y, 幅, 高さ
		searchContainIPButton.setActionCommand("contain");
		
		// フレームに追加
		add(hostnameLabel);
		add(hostnameText);
		add(ipLabel);
		add(ipText);
		add(ifCheck);
		add(routingCheck);
		add(natCheck);
		add(searchIPButton);
		add(searchContainIPButton);
		
		//その他オプション
		setVisible(true);
		//setAlwaysOnTop(true);
		setResizable(false);
	}
	
	public static String getHtmlText(String befStr){
		String returnStr="<html><body style='text-align:center;width:100%; color:black;'>"+befStr+"</body></html>";
		
		return returnStr;
	}
}

