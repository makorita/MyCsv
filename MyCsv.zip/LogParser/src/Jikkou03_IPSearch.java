import java.io.*;
import java.util.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Jikkou03_IPSearch implements ActionListener{
	static SearchWindow sw;
	static java.util.List<NJson> jsonList;
	
	public static void main(String[] args) throws Exception{
		//コンフィグマップロード
		HashMap<String,String> configMap=ConfigLoader.loadConfig("../config.txt");
		
		//jsonList取得
		jsonList=new ArrayList<NJson>();
		File rootDir=new File(configMap.get("outputFolder"));
		File[] fileList=rootDir.listFiles();
		for(File curFile:fileList){
			NJson curJson=NJsonParser.loadJson(curFile);
			jsonList.add(curJson);
		}
		
		//検索ウィンドウ表示
		Jikkou03_IPSearch parent=new Jikkou03_IPSearch();
		sw=new SearchWindow();
		sw.searchIPButton.addActionListener(parent);
		sw.searchContainIPButton.addActionListener(parent);
	}
	
	// 別ウィンドウ（モーダルダイアログ）を表示するメソッド
	private static void showMessageDialog(String message) {
		// モーダルダイアログ作成
		JDialog dialog = new JDialog(sw, "検索結果", true);
		dialog.setLayout(new BorderLayout());

		// 複数行対応のテキストエリア（編集不可）
		JTextArea textArea = new JTextArea(message);
		textArea.setEditable(false);
		//textArea.setBackground(new JLabel().getBackground()); // 背景をラベルと同じ色に
		textArea.setBackground(Color.WHITE);
		textArea.setFont(new Font("Dialog", Font.PLAIN, 14));

		// スクロール可能に
		JScrollPane scrollPane = new JScrollPane(textArea);
		dialog.add(scrollPane, BorderLayout.CENTER);

		// OKボタン
		JButton okButton = new JButton("OK");
		okButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog.dispose(); // 閉じる
			}
		});
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(okButton);
		dialog.add(buttonPanel, BorderLayout.SOUTH);

		// 行数に応じて高さを調整
		int lineCount = message.split("\n").length;
		int height = Math.min(100 + lineCount * 20, 600); // 最大高さ400px
		dialog.setSize(500, height);

		dialog.setLocationRelativeTo(sw); // 中央表示
		dialog.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e){
		//モード取得。ボタンイベント以外除外。
		boolean exactFlag=false;
		if(e.getActionCommand().equals("search")){
			exactFlag=true;
		}else if(e.getActionCommand().equals("contain")){
			exactFlag=false;
		}else return;
		
		//IPチェック
		if(sw.ipText.getText().trim().isEmpty()){
			showMessageDialog("IP欄が空欄です");
			return;
		}
		if(!AddressUtility.isLegalAddrStr(sw.ipText.getText())){
			showMessageDialog("無効なIP文字列:"+sw.ipText.getText());
			return;
		}
		Address searchIP=new Address(sw.ipText.getText());
		
		//ホスト名を含むコンフィグリスト取得
		String hostnameStr=hostnameStr=sw.hostnameText.getText();
		java.util.List<NJson> hostnameFilterList=CiscoNJsonFilter.hostnameMatchFilter(jsonList,hostnameStr);
		
		StringBuilder returnBuilder=new StringBuilder();
		//チェックボックス分岐
		if(sw.ifCheck.isSelected()){
			returnBuilder.append("◆I/F\n");
			for(NJson curConfig:hostnameFilterList){
				java.util.List<NJson> returnList=CiscoNJsonFilter.getIfResultList(curConfig,searchIP,exactFlag);
				for(NJson curJson:returnList){
					Iterator<String> resultIt=curJson.childKeyIterator();
					while(resultIt.hasNext()){
						String curKey=resultIt.next();
						String value=curJson.getChild(curKey).getValue();
						returnBuilder.append(curKey+"::"+value+"\n");
					}
					returnBuilder.append("\n");
				}
			}
		}
		if(sw.routingCheck.isSelected()){
			returnBuilder.append("◆Routing\n");
			for(NJson curConfig:hostnameFilterList){
				java.util.List<NJson> returnList=CiscoNJsonFilter.getRoutingResultList(curConfig,searchIP);
				for(NJson curJson:returnList){
					Iterator<String> resultIt=curJson.childKeyIterator();
					while(resultIt.hasNext()){
						String curKey=resultIt.next();
						String value=curJson.getChild(curKey).getValue();
						returnBuilder.append(curKey+"::"+value+"\n");
					}
					returnBuilder.append("\n");
				}
			}
		}
		if(sw.natCheck.isSelected()){
			returnBuilder.append("◆NAT\n");
			for(NJson curConfig:hostnameFilterList){
				java.util.List<NJson> returnList=CiscoNJsonFilter.getNatResultList(curConfig,searchIP);
				for(NJson curJson:returnList){
					Iterator<String> resultIt=curJson.childKeyIterator();
					while(resultIt.hasNext()){
						String curKey=resultIt.next();
						String value=curJson.getChild(curKey).getValue();
						returnBuilder.append(curKey+"::"+value+"\n");
					}
					returnBuilder.append("\n");
				}
			}
		}
		
		showMessageDialog(returnBuilder.toString());
	}
}
