import java.io.*;
import java.util.*;

public class Test02_CiscoNjsonFilter{
	public static void main(String[] args) throws Exception{
		if(false){	//permitフィルタまで
			HashMap<String,NJson> returnMap=CiscoNJsonFilter.loadJson("../output");
			//for(NJson tmpJson:returnMap.values())System.out.println(tmpJson.getChild("hostname").getValue());
			NJson curJson=returnMap.get("EJMSUPRT03-B");
			NJson aclJson=null;
			aclJson=curJson.getChild("acl").getChild("100");
			aclJson=CiscoNJsonFilter.containProtocolFilter(aclJson,"tcp");
			aclJson=NJsonFilter.matchValueFilter(aclJson,"許可","permit");
			System.out.println(aclJson.toPrettyJsonString());
		}
		
		if(false){
			HashMap<String,NJson> returnMap=CiscoNJsonFilter.loadJson("../output");
			NJson curJson=returnMap.get("EJMSUPRT03-B");
			NJson aclJson=null;
			aclJson=curJson.getChild("acl").getChild("10");
			aclJson=CiscoNJsonFilter.ciscoIPFilter(aclJson,"ソースIP","ソースWILD",new Address("192.168.96.128/26"));
			System.out.println(aclJson.toPrettyJsonString());
		}
		
		if(true){
			HashMap<String,NJson> returnMap=CiscoNJsonFilter.loadJson("../output");
			NJson curJson=returnMap.get("EJNROBFW03");
			NJson aclJson=null;
			aclJson=curJson.getChild("acl").getChild("acl-in_EJCOB_B");
			aclJson=CiscoNJsonFilter.ciscoFWIPFilter(aclJson,"宛先IPogName",curJson.getChild("object-group"),new Address("172.21.1.1/24"));
			System.out.println(aclJson.toPrettyJsonString());
		}
		
		if(false){
			HashMap<String,NJson> returnMap=CiscoNJsonFilter.loadJson("../output");
			NJson curJson=returnMap.get("EJNRYDRT01");
			NJson aclJson=null;
			aclJson=curJson.getChild("acl").getChild("From_Kaihatsu_1");
			aclJson=CiscoNJsonFilter.ciscoPortFilter(aclJson,"宛先PORT",80);
			System.out.println(aclJson.toPrettyJsonString());
		}
	}
}
