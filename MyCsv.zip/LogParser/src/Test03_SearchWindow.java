import java.io.*;
import java.util.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Test03_SearchWindow implements ActionListener{
	static SearchWindow sw;
	static HashMap<String,NJson> jsonMap;
	
	public static void main(String[] args) throws Exception{
		HashMap<String,String> configMap=ConfigLoader.loadConfig("../config.txt");
		
		//configJsonMap取得
		jsonMap=new HashMap<String,NJson>();
		File rootDir=new File(configMap.get("outputFolder"));
		File[] fileList=rootDir.listFiles();
		for(File curFile:fileList){
			NJson curJson=NJsonParser.loadJson(curFile);
			jsonMap.put(curJson.getChild("hostname").getValue(),curJson);
		}
		
		Test03_SearchWindow parent=new Test03_SearchWindow();
		sw=new SearchWindow();
		sw.searchIPButton.addActionListener(parent);
		sw.searchContainIPButton.addActionListener(parent);
	}
	
	// 別ウィンドウ（モーダルダイアログ）を表示するメソッド
	private static void showMessageDialog(String message) {
		// モーダルダイアログ作成
		JDialog dialog = new JDialog(sw, "検索結果", true);
		dialog.setLayout(new BorderLayout());

		// 複数行対応のテキストエリア（編集不可）
		JTextArea textArea = new JTextArea(message);
		textArea.setEditable(false);
		textArea.setBackground(new JLabel().getBackground()); // 背景をラベルと同じ色に
		textArea.setFont(new Font("Dialog", Font.PLAIN, 14));

		// スクロール可能に
		JScrollPane scrollPane = new JScrollPane(textArea);
		dialog.add(scrollPane, BorderLayout.CENTER);

		// OKボタン
		JButton okButton = new JButton("OK");
		okButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog.dispose(); // 閉じる
			}
		});
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(okButton);
		dialog.add(buttonPanel, BorderLayout.SOUTH);

		// 行数に応じて高さを調整
		int lineCount = message.split("\n").length;
		int height = Math.min(100 + lineCount * 20, 400); // 最大高さ400px
		dialog.setSize(400, height);

		dialog.setLocationRelativeTo(sw); // 中央表示
		dialog.setVisible(true);
	}
	
	private static String getIfStr(NJson srcJson,Address checkedAddr,String mode){
		StringBuilder returnBuilder=new StringBuilder();
		
		NJson ifJson=srcJson.getChild("interface");
		if(ifJson==null)return null;
		
		Iterator<NJson> it=ifJson.childIterator();
		while(it.hasNext()){
			NJson curJson=it.next();
			if(curJson.getChild("ip")!=null){	//IPチェックブロック
				Address curAddr=new Address(curJson.getChild("ip").getValue(),curJson.getChild("mask").getValue());
				if((mode.equals("IPSearch") && curAddr.getAddress()==checkedAddr.getAddress()) || 
				(mode.equals("IPContainSearch") && AddressUtility.contains(curAddr,checkedAddr))){
					if(returnBuilder.length()==0)returnBuilder.append("hostname::"+srcJson.getChild("hostname").getValue()+"\n");
					returnBuilder.append("インターフェース名::"+curJson.getChild("ifName").getValue()+"\n");
					returnBuilder.append("ip::"+curJson.getChild("ip").getValue()+"\n");
					returnBuilder.append("mask::"+curJson.getChild("mask").getValue()+"\n");
					if(curJson.getChild("acl_in")!=null)returnBuilder.append("access-list in::"+curJson.getChild("acl_in").getValue()+"\n");
					if(curJson.getChild("acl_out")!=null)returnBuilder.append("access-list out::"+curJson.getChild("acl_out").getValue()+"\n");
				}
			}
			
			if(curJson.getChild("secondary")!=null){	//セカンダリIPチェックブロック
				NJson secondaryJson=curJson.getChild("secondary");
				Iterator<NJson> secIt=secondaryJson.childIterator();
				while(secIt.hasNext()){
					NJson childJson=it.next();
					Address curAddr=new Address(childJson.getChild("ip").getValue(),childJson.getChild("mask").getValue());
		}
		
		if(returnBuilder.length()==0)return null;
		else return returnBuilder.toString();
	}
	
	@Override
	public void actionPerformed(ActionEvent e){
		String mode=null;
		if(e.getActionCommand().equals("search")){
			mode="IPSearch";
		}else if(e.getActionCommand().equals("contain")){
			mode="IPContainSearch";
		}else return;
		
		StringBuilder returnBuilder=new StringBuilder();
		if(sw.ifCheck.isSelected()){
			returnBuilder.append("[I/F]\n");
			if(!sw.hostnameText.getText().trim().isEmpty()){
				NJson curJson=jsonMap.get(sw.hostnameText.getText());
				if(curJson==null){
					showMessageDialog(sw.hostnameText.getText()+"のコンフィグが存在しません");
					return;
				}
				if(sw.ipText.getText().trim().isEmpty()){
					showMessageDialog("IP欄が空欄です");
					return;
				}
				Address checkedAddr=new Address(sw.ipText.getText());
				String returnStr=getIfStr(curJson,checkedAddr,mode);
				if(returnStr!=null)returnBuilder.append(returnStr);
			}
		}
		
		if(returnBuilder.length()>0)showMessageDialog(returnBuilder.toString());
	}
}
