import java.util.*;

public class CiscoFWParser{
	public static List<String> extractConfig(List<String> lines){	//コンフィグ抽出
		List<String> returnList=new ArrayList<String>();
		
		String mode="START";
		for(String curStr:lines){
			if(mode.equals("START")){	//開始条件
				if(curStr.matches(".*sh.* run.*"))mode="RUN";
				else if(curStr.matches(".*sh.* sta.*"))mode="RUN";
				
			}else if(mode.equals("RUN")){
				returnList.add(curStr);
				
				//終了条件
				if(curStr.matches(": end"))mode="END";
				if(mode.equals("END"))break;
			}
			
		}
		
		if(!mode.equals("END"))throw new IllegalArgumentException("想定外モード:"+mode);
		
		return returnList;
	}
	
	public static String getHostname(List<String> curConfig){
		for(String curStr:curConfig){
			if(curStr.matches("hostname .*"))return curStr.replace("hostname ","");
		}
		
		return null;
	}
	
	public static void addInterface(List<String> curConfig,LinkedHashMap<String,String> pathValueMap){
		String mode="IF_OUT";
		String curIfName=null;
		for(String curStr:curConfig){
			curStr=curStr.trim();	//トリム実行
			//if(mode.equals("IF_IN"))System.out.println(curStr);
			//if(curStr.matches("interface .*"))System.out.println(curStr);
			
			if(mode.equals("IF_OUT") && curStr.matches("interface .*")){
				curIfName=curStr.replace("interface ","");
				pathValueMap.put("interface##"+curIfName+"##ifName",curIfName);
				mode="IF_IN";
			}else if(mode.equals("IF_IN") && curStr.matches("!")){
				mode="IF_OUT";
			}else if(mode.equals("IF_IN") && curStr.matches("description .*")){
				pathValueMap.put("interface##"+curIfName+"##description",curStr.replaceAll("description ",""));
				mode="IF_IN";
			}else if(mode.equals("IF_IN") && curStr.matches("nameif .*")){
				pathValueMap.put("interface##"+curIfName+"##nameif",curStr.replace("nameif ",""));
				mode="IF_IN";
			}else if(mode.equals("IF_IN") && curStr.matches("security-level .*")){
				pathValueMap.put("interface##"+curIfName+"##security-level",curStr.replace("security-level ",""));
				mode="IF_IN";
			}else if(mode.equals("IF_IN") && curStr.matches("switchport access vlan .*")){
				pathValueMap.put("interface##"+curIfName+"##access_vlan",curStr.replace("switchport access vlan ",""));
				pathValueMap.put("interface##"+curIfName+"##switch_mode","access");
				mode="IF_IN";
			}else if(mode.equals("IF_IN") && curStr.matches("vlan \\d+")){
				pathValueMap.put("interface##"+curIfName+"##allowed_vlan",curStr.replace("vlan ",""));
				mode="IF_IN";
			}else if(mode.equals("IF_IN") && curStr.matches("shutdown")){
				pathValueMap.put("interface##"+curIfName+"##shutdown","true");
			}else if(mode.equals("IF_IN") && curStr.matches("ip address \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")){
				String[] word=curStr.split(" ");
				pathValueMap.put("interface##"+curIfName+"##ip",word[2]);
				pathValueMap.put("interface##"+curIfName+"##mask",word[3]);
			}else if(mode.equals("IF_IN") && curStr.matches("ip address \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} standby \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")){
				String[] word=curStr.split(" ");
				pathValueMap.put("interface##"+curIfName+"##ip",word[2]);
				pathValueMap.put("interface##"+curIfName+"##mask",word[3]);
				pathValueMap.put("interface##"+curIfName+"##standby_ip",word[5]);
			}else if(mode.equals("IF_IN") && curStr.matches("ip address \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} pppoe setroute")){
				String[] word=curStr.split(" ");
				pathValueMap.put("interface##"+curIfName+"##ip",word[2]);
				pathValueMap.put("interface##"+curIfName+"##mask",word[3]);
				pathValueMap.put("interface##"+curIfName+"##option",word[4]+" "+word[5]);
			}else if(mode.equals("IF_IN") && curStr.matches("speed .+")){
				String[] word=curStr.split(" ");
				pathValueMap.put("interface##"+curIfName+"##speed",word[1]);
			}else if(mode.equals("IF_IN") && curStr.matches("duplex .+")){
				String[] word=curStr.split(" ");
				pathValueMap.put("interface##"+curIfName+"##duplex",word[1]);
			}
		}
	}
	
	public static void addStaticRoute(List<String> curConfig,LinkedHashMap<String,String> pathValueMap){
		int routeIndex=1;
		for(String curStr:curConfig){
			if(!curStr.matches("route .*"))continue;
			//System.out.println(curStr);
			curStr=curStr.trim();	//トリム実行
			
			if(curStr.matches("route (.*?) \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d")){
				String[] word=curStr.split(" ");
				pathValueMap.put("static_route##"+String.format("%04d", routeIndex)+"##raw_config",curStr);
				pathValueMap.put("static_route##"+String.format("%04d", routeIndex)+"##宛先ネットワーク",word[2]);
				pathValueMap.put("static_route##"+String.format("%04d", routeIndex)+"##宛先マスク",word[3]);
				pathValueMap.put("static_route##"+String.format("%04d", routeIndex)+"##送出IF",word[1]);
				pathValueMap.put("static_route##"+String.format("%04d", routeIndex)+"##ネクストホップ",word[4]);
				pathValueMap.put("static_route##"+String.format("%04d", routeIndex)+"##AD値",word[5]);
			}else throw new IllegalArgumentException("想定外Static Route設定:"+curStr);
			
			routeIndex++;
		}
	}

	public static void addObjectGroup(List<String> curConfig,LinkedHashMap<String,String> pathValueMap){
		String rowMode="OG_OUT";
		String curOgName=null;
		String curOgType=null;
		for(String curStr:curConfig){
			curStr=curStr.trim();	//トリム実行
			if(curStr.matches("object-group .*")){
				rowMode="OG_IN";
			}else if(rowMode.equals("OG_IN") && !curStr.matches("(network|port|protocol|group)-object .*")){
				rowMode="OG_OUT";
				continue;
			}else if(rowMode.equals("OG_OUT"))continue;
			//System.out.println(curStr);
			
			if(curStr.matches("object-group (network|protocol) .*")){
				String[] word=curStr.split(" ");
				curOgType=word[1];
				curOgName=word[2];
				pathValueMap.put("object-group##"+curOgName+"##ogName",word[2]);
				pathValueMap.put("object-group##"+curOgName+"##ogType",word[1]);
			}else if(curStr.matches("object-group service (.*?) (tcp|udp)")){
				String[] word=curStr.split(" ");
				curOgType=word[1];
				curOgName=word[2];
				pathValueMap.put("object-group##"+curOgName+"##ogName",word[2]);
				pathValueMap.put("object-group##"+curOgName+"##ogType",word[1]);
				pathValueMap.put("object-group##"+curOgName+"##protocol",word[3]);
			}else if(curStr.matches("object-group service (.*?) .*")){
				String[] word=curStr.split(" ");
				curOgType=word[1];
				curOgName=word[2];
				pathValueMap.put("object-group##"+curOgName+"##ogName",word[2]);
				pathValueMap.put("object-group##"+curOgName+"##ogType",word[1]);
				pathValueMap.put("object-group##"+curOgName+"##protocolOGName",word[3]);
			}else if(curStr.matches("network-object \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")){
				String[] word=curStr.split(" ");
				pathValueMap.put("object-group##"+curOgName+"##child##"+word[1]+"##ogType","network");
				pathValueMap.put("object-group##"+curOgName+"##child##"+word[1]+"##ip",word[1]);
				pathValueMap.put("object-group##"+curOgName+"##child##"+word[1]+"##mask",word[2]);
			}else if(curStr.matches("network-object host \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")){
				String[] word=curStr.split(" ");
				pathValueMap.put("object-group##"+curOgName+"##child##"+word[2]+"##ogType","network");
				pathValueMap.put("object-group##"+curOgName+"##child##"+word[2]+"##ip",word[2]);
				pathValueMap.put("object-group##"+curOgName+"##child##"+word[2]+"##mask","255.255.255.255");
			}else if(curStr.matches("port-object eq .*")){
				String[] word=curStr.split(" ");
				pathValueMap.put("object-group##"+curOgName+"##child##"+NetworkUtility.toPortNumber(word[2])+"##ogType","port");
				pathValueMap.put("object-group##"+curOgName+"##child##"+NetworkUtility.toPortNumber(word[2])+"##port","eq "+NetworkUtility.toPortNumber(word[2]));
			}else if(curStr.matches("port-object range (.*?) .*")){
				String[] word=curStr.split(" ");
				pathValueMap.put("object-group##"+curOgName+"##child##"+NetworkUtility.toPortNumber(word[2])+"-"+NetworkUtility.toPortNumber(word[3])+"##ogType","port");
				pathValueMap.put("object-group##"+curOgName+"##child##"+NetworkUtility.toPortNumber(word[2])+"-"+NetworkUtility.toPortNumber(word[3])+"##port","range "+NetworkUtility.toPortNumber(word[2])+" "+NetworkUtility.toPortNumber(word[3]));
			}else if(curStr.matches("protocol-object (tcp|udp)")){
				String[] word=curStr.split(" ");
				pathValueMap.put("object-group##"+curOgName+"##child##"+word[1]+"##ogType","protocol");
				pathValueMap.put("object-group##"+curOgName+"##child##"+word[1]+"##protocol",word[1]);
			}else if(curStr.matches("group-object .*")){
				String[] word=curStr.split(" ");
				pathValueMap.put("object-group##"+curOgName+"##child##"+word[1]+"##ogType","group");
				pathValueMap.put("object-group##"+curOgName+"##child##"+word[1]+"##ogName",word[1]);
			}else throw new IllegalArgumentException("想定外object-group設定:"+curStr);
		}
	}
	
	public static void addAccessGroup(List<String> curConfig,LinkedHashMap<String,String> pathValueMap){
		for(String curStr:curConfig){
			curStr=curStr.trim();	//トリム実行
			
			if(curStr.matches("access-group (.*?) in interface .*")){
				String[] word=curStr.split(" ");
				pathValueMap.put("access-group##"+word[1]+"##name",word[1]);
				pathValueMap.put("access-group##"+word[1]+"##interface##"+word[4]+"##nameif",word[4]);
			}
		}
	}

	public static void addAcl(List<String> curConfig,LinkedHashMap<String,String> pathValueMap,NJson ogJson){	//ソースポートオブジェクトか宛先ネットワークオブジェクトか識別するためにobject-group参照用のNJsonを渡している
		int aclIndex=-1;
		String aclNum=null;
		for(String curStr:curConfig){
			if(!curStr.matches("access-list .*"))continue;
			//System.out.println(curStr);
			curStr=curStr.trim();	//トリム実行
			
			String editStr=curStr;
			String mode="START";
			while(editStr.length()>0){
				//System.out.println(mode+",#"+editStr+"#");
				if(mode.equals("START") && editStr.matches("access-list .*")){
					String[] word=editStr.split(" ");
					if(aclNum==null || !aclNum.equals(word[1])){
						aclNum=word[1];
						aclIndex=10;
					}
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##raw_config",curStr);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##acl番号",aclNum);
					editStr=editStr.replaceFirst("access-list","");
					editStr=editStr.replaceFirst(word[1],"");
					editStr=editStr.replaceFirst("extended","");
					editStr=editStr.trim();
					
					mode="許可";
				}else if(mode.equals("許可") && editStr.matches("(permit|deny) .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##許可",word[0]);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="プロトコル";
				}else if(mode.equals("許可") && editStr.matches("remark.*")){
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##許可","remark");
					editStr=editStr.replaceFirst("remark ","");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##remark文字",editStr);
					editStr="";
					mode="END";
				}else if(mode.equals("プロトコル") && NetworkUtility.isProtocol(editStr.split(" ")[0])){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##プロトコル",word[0]);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="ソースIP";
				}else if(mode.equals("プロトコル") && editStr.matches("object-group .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##プロトコルogName",word[1]);
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="ソースIP";
				}else if(mode.equals("ソースIP") && editStr.matches("any.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースIP","0.0.0.0");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースMASK","0.0.0.0");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="ソースPORT";
				}else if(mode.equals("ソースIP") && editStr.matches("object-group .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースIPogName",word[1]);
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="ソースPORT";
				}else if(mode.equals("ソースPORT") && editStr.matches("eq .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースPORT","eq "+NetworkUtility.toPortNumber(word[1]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="宛先IP";
				}else if(mode.equals("ソースPORT") && editStr.matches("range .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースPORT","range "+NetworkUtility.toPortNumber(word[1])+" "+NetworkUtility.toPortNumber(word[2]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1]+" "+word[2],"");
					editStr=editStr.trim();
					mode="宛先IP";
				}else if(mode.equals("ソースPORT") && editStr.matches("object-group .*")){
					String[] word=editStr.split(" ");
					String tmpOgName=word[1];
					NJson tmpJson=ogJson.getChild("object-group").getChild(tmpOgName);
					if(tmpJson.getChild("ogType").getValue().equals("network")){
						pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先IPogName",word[1]);
						mode="宛先PORT";
					}else if(tmpJson.getChild("ogType").equals("service")){
						pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースPORTogName",word[1]);
						mode="宛先IP";
					}
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
				}else if(mode.equals("宛先IP") && editStr.matches("object-group .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先IPogName",word[1]);
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="宛先PORT";
				}else if((mode.equals("宛先IP") || mode.equals("ソースPORT")) && editStr.matches("any.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先IP","0.0.0.0");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先MASK","0.0.0.0");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="宛先PORT";
				}else if(mode.equals("宛先PORT") && editStr.matches("eq .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先PORT","eq "+NetworkUtility.toPortNumber(word[1]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else if(mode.equals("宛先PORT") && editStr.matches("object-group .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先PORTogName",word[1]);
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else if((mode.equals("OPTION") || mode.equals("宛先PORT")) && editStr.matches("log.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##log","true");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else throw new IllegalArgumentException("想定外access-list:"+mode+","+editStr);
			}
			
			aclIndex+=10;
		}
	}
}
