import java.io.*;
import java.util.*;

public class Jikkou04_TraceRoute{
/*
javac -cp "./;lib/*" Jikkou04_TraceRoute.java
java -cp "./;lib/*" Jikkou04_TraceRoute
*/

	static LinkedHashMap<String,NJson> jsonMap;
	static String mode;
	static PrintWriter wr;
	
	public static void main(String[] args) throws Exception{
		//コンフィグマップロード
		HashMap<String,String> configMap=ConfigLoader.loadConfig("../config.txt");
		
		//configJsonMap取得
		jsonMap=new LinkedHashMap<String,NJson>();
		File rootDir=new File(configMap.get("outputFolder"));
		File[] fileList=rootDir.listFiles();
		for(File curFile:fileList){
			NJson curJson=NJsonParser.loadJson(curFile);
			jsonMap.put(curJson.getChild("hostname").getValue(),curJson);
		}
		
		//検索Exl取得
		NExcel searchExl=NExcelIO.loadExcel(configMap.get("traceRouteExl"),configMap.get("traceRouteSheet"));
		
		for(int rowIndex=0;rowIndex<searchExl.getContentSize();rowIndex++){	//検索条件回し
			//実行フラグチェック
			String jikkouFlag=searchExl.getValue(rowIndex,"実行フラグ");
			if(jikkouFlag==null)continue;
			
			mode="src_seg";
			boolean reverseFlag=false;
			String hostname=null;
			String i_f=null;
			String acl_in=null;
			String acl_out=null;
			String nexthop=null;
			
			String protocol=searchExl.getValue(rowIndex,"プロトコル");
			String srcIP=searchExl.getValue(rowIndex,"送信元IP");
			String srcPort=searchExl.getValue(rowIndex,"送信元ポート");
			if(srcPort!=null)srcPort=srcPort.substring(0,srcPort.indexOf("."));
			String dstIP=searchExl.getValue(rowIndex,"宛先IP");
			String dstPort=searchExl.getValue(rowIndex,"宛先ポート");
			if(dstPort!=null)dstPort=dstPort.substring(0,dstPort.indexOf("."));
			
			//結果出力用
			String searchStr=getSearchStr(protocol,srcIP,srcPort,dstIP,dstPort);
			wr=new PrintWriter(new FileWriter("../"+searchStr+".txt"));
			System.out.println(searchStr+"のTraceRoute");
			
			for(int hopCount=0;hopCount<100;hopCount++){	//hopCount回し(アクション回数)
				if(mode.equals("src_seg")){
					wr.println("■"+getSearchStr(protocol,srcIP,srcPort,dstIP,dstPort)+"の設定確認\n");
					Address searchedIP=new Address(srcIP);
					for(NJson curConfig:jsonMap.values()){
						//System.out.println(curConfig.getChild("hostname").getValue());
						acl_in=null;
						acl_out=null;
						List<NJson> returnList=CiscoNJsonFilter.getIfResultList(curConfig,searchedIP,false);
						if(returnList.size()>0){
							hostname=returnList.get(0).getChild("hostname").getValue();
							i_f=returnList.get(0).getChild("ifName").getValue();
							if(returnList.get(0).getChild("acl_in")!=null)acl_in=returnList.get(0).getChild("acl_in").getValue();
							if(returnList.get(0).getChild("acl_out")!=null)acl_out=returnList.get(0).getChild("acl_out").getValue();
							
							//FWのacl_in取得
							if(curConfig.getChild("機器タイプ").getValue().equals("CISCO_FW")){
								NJson aclGrpRoot=curConfig.getChild("access-group");
								Iterator<NJson> aclGrpIt=aclGrpRoot.childIterator();
								LABEL:while(aclGrpIt.hasNext()){
									NJson curAclGrp=aclGrpIt.next();
									NJson nameifRoot=curAclGrp.getChild("interface");
									Iterator<NJson> nameifIt=nameifRoot.childIterator();
									while(nameifIt.hasNext()){
										NJson curNameif=nameifIt.next();
										if(curNameif.getChild("nameif").getValue().equals(returnList.get(0).getChild("nameif").getValue())){
											acl_in=curAclGrp.getChild("name").getValue();
											returnList.get(0).put("acl_in",acl_in);
											break LABEL;
										}
									}
								}
							}
							
							wr.println("・送信元IPの収容機器");
							Iterator<String> resultIt=returnList.get(0).childKeyIterator();
							while(resultIt.hasNext()){
								String curKey=resultIt.next();
								String value=returnList.get(0).getChild(curKey).getValue();
								wr.println(curKey+"::"+value);
							}
							wr.println();
							if(acl_in!=null)mode="in_acl";
							else if(curConfig.getChild("nat")!=null)mode="nat";
							else mode="dst_seg";
							break;
						}
					}
					if(mode.equals("src_seg")){
						wr.println("★送信元IPが見つかりません:"+srcIP);
						wr.close();
						if(true)System.exit(0);
					}
					
				}else if(mode.equals("in_acl")){
					NJson curConfig=jsonMap.get(hostname);
					NJson aclRoot=curConfig.getChild("acl");
					wr.println("・入力方向 in側 acl");
					NJson curAcl=aclRoot.getChild(acl_in);
					List<NJson> aclList=curAcl.getChildList();
					//System.out.println(aclList.size());
					aclList=CiscoNJsonFilter.ciscoPermitFilter(aclList,"permit");
					aclList=CiscoNJsonFilter.ciscoProtocolFilter(aclList,protocol);
					if(curConfig.getChild("機器タイプ").getValue().equals("CISCO_FW"))aclList=CiscoNJsonFilter.ciscoFWProtocolFilter(aclList,curConfig.getChild("object-group"),protocol);
					Address tmpSrcAddr=new Address(srcIP);
					if(curConfig.getChild("機器タイプ").getValue().equals("CISCO"))aclList=CiscoNJsonFilter.ciscoIPFilter(aclList,"ソースIP","ソースWILD",tmpSrcAddr);
					if(curConfig.getChild("機器タイプ").getValue().equals("CISCO_FW"))aclList=CiscoNJsonFilter.ciscoFWIPFilter(aclList,"ソースIP","ソースMASK",tmpSrcAddr);
					if(curConfig.getChild("機器タイプ").getValue().equals("CISCO_FW"))aclList=CiscoNJsonFilter.ciscoFWIPGrpFilterList(aclList,"ソースIPogName",curConfig.getChild("object-group"),tmpSrcAddr);
					if(srcPort==null)aclList=CiscoNJsonFilter.ciscoPortFilter(aclList,"ソースPORT",null);
					else aclList=CiscoNJsonFilter.ciscoPortFilter(aclList,"ソースPORT",Integer.parseInt(srcPort));
					if(curConfig.getChild("機器タイプ").getValue().equals("CISCO_FW")){
						if(srcPort==null)aclList=CiscoNJsonFilter.ciscoFWPortFilter(aclList,"ソースPORTogName",curConfig.getChild("object-group"),null);
						else aclList=CiscoNJsonFilter.ciscoFWPortFilter(aclList,"ソースPORTogName",curConfig.getChild("object-group"),Integer.parseInt(srcPort));
					}
					Address tmpDstAddr=new Address(dstIP);
					if(curConfig.getChild("機器タイプ").getValue().equals("CISCO"))aclList=CiscoNJsonFilter.ciscoIPFilter(aclList,"宛先IP","宛先WILD",tmpDstAddr);
					if(curConfig.getChild("機器タイプ").getValue().equals("CISCO_FW"))aclList=CiscoNJsonFilter.ciscoFWIPFilter(aclList,"宛先IP","宛先MASK",tmpDstAddr);
					if(curConfig.getChild("機器タイプ").getValue().equals("CISCO_FW"))aclList=CiscoNJsonFilter.ciscoFWIPGrpFilterList(aclList,"宛先IPogName",curConfig.getChild("object-group"),tmpDstAddr);
					if(dstPort==null)aclList=CiscoNJsonFilter.ciscoPortFilter(aclList,"宛先PORT",null);
					else aclList=CiscoNJsonFilter.ciscoPortFilter(aclList,"宛先PORT",Integer.parseInt(dstPort));
					if(curConfig.getChild("機器タイプ").getValue().equals("CISCO_FW")){
						if(dstPort==null)aclList=CiscoNJsonFilter.ciscoFWPortFilter(aclList,"宛先PORTogName",curConfig.getChild("object-group"),null);
						else aclList=CiscoNJsonFilter.ciscoFWPortFilter(aclList,"宛先PORTogName",curConfig.getChild("object-group"),Integer.parseInt(dstPort));
					}
					//System.out.println(aclList.size());
					if(aclList.size()==0)wr.println("★acl許可設定が見つかりません(FWの戻り通信であれば問題なし)\n");
					else{
						for(NJson resultAcl:aclList){
							Iterator<String> resultIt=resultAcl.childKeyIterator();
							while(resultIt.hasNext()){
								String curKey=resultIt.next();
								String value=resultAcl.getChild(curKey).getValue();
								wr.println(curKey+"::"+value);
							}
							wr.println();
						}
					}
					if(curConfig.getChild("nat")!=null)mode="nat";
					else mode="dst_seg";
					
				}else if(mode.equals("nat")){
					NJson curConfig=jsonMap.get(hostname);
					{
						Address tmpSrcAddr=new Address(srcIP);
						List<NJson> returnList=CiscoNJsonFilter.getNatResultList(curConfig,tmpSrcAddr);
						if(returnList.size()>0){
							wr.println("・送信元IP NA変換");
							Iterator<String> resultIt=returnList.get(0).childKeyIterator();
							while(resultIt.hasNext()){
								String curKey=resultIt.next();
								String value=returnList.get(0).getChild(curKey).getValue();
								wr.println(curKey+"::"+value);
							}
							wr.println();
							srcIP=returnList.get(0).getChild("afterIP").getValue();
						}
					}
					
					{
						Address tmpDstAddr=new Address(dstIP);
						List<NJson> returnList=CiscoNJsonFilter.getNatResultList(curConfig,tmpDstAddr);
						if(returnList.size()>0){
							wr.println("・宛先IP NA変換");
							Iterator<String> resultIt=returnList.get(0).childKeyIterator();
							while(resultIt.hasNext()){
								String curKey=resultIt.next();
								String value=returnList.get(0).getChild(curKey).getValue();
								wr.println(curKey+"::"+value);
							}
							wr.println();
							dstIP=returnList.get(0).getChild("afterIP").getValue();
						}
					}
					
					mode="dst_seg";
					
				}else if(mode.equals("dst_seg")){
					Address searchedIP=new Address(dstIP);
					acl_in=null;
					acl_out=null;
					NJson curConfig=jsonMap.get(hostname);
					List<NJson> returnList=CiscoNJsonFilter.getIfResultList(curConfig,searchedIP,false);
					if(returnList.size()>0){
						i_f=returnList.get(0).getChild("ifName").getValue();
						if(returnList.get(0).getChild("acl_in")!=null)acl_in=returnList.get(0).getChild("acl_in").getValue();
						if(returnList.get(0).getChild("acl_out")!=null)acl_in=returnList.get(0).getChild("acl_out").getValue();
						
						wr.println("・宛先IPの収容I/F");
						Iterator<String> resultIt=returnList.get(0).childKeyIterator();
						while(resultIt.hasNext()){
							String curKey=resultIt.next();
							String value=returnList.get(0).getChild(curKey).getValue();
							wr.println(curKey+"::"+value);
						}
						wr.println();
						if(acl_out!=null)mode="last_acl";
						else mode="end";
						
					}else mode="routing";
					
				}else if(mode.equals("routing")){
					Address searchedIP=new Address(dstIP);
					NJson curConfig=jsonMap.get(hostname);
					List<NJson> returnList=CiscoNJsonFilter.getRoutingResultList(curConfig,searchedIP);
					if(returnList.size()==0){
						wr.println("★宛先IPへのルーティングが見つかりません:"+dstIP);
						wr.close();
						if(true)System.exit(0);
						
					}
					nexthop=returnList.get(0).getChild("ネクストホップ").getValue();
					
					wr.println("・宛先IPへのルーティング");
					Iterator<String> resultIt=returnList.get(0).childKeyIterator();
					while(resultIt.hasNext()){
						String curKey=resultIt.next();
						String value=returnList.get(0).getChild(curKey).getValue();
						wr.println(curKey+"::"+value);
					}
					wr.println();
					mode="output_if";
					
				}else if(mode.equals("output_if")){
					Address searchedIP=new Address(nexthop);
					acl_in=null;
					acl_out=null;
					NJson curConfig=jsonMap.get(hostname);
					List<NJson> returnList=CiscoNJsonFilter.getIfResultList(curConfig,searchedIP,false);
					i_f=returnList.get(0).getChild("ifName").getValue();
					if(returnList.get(0).getChild("acl_in")!=null)acl_in=returnList.get(0).getChild("acl_in").getValue();
					if(returnList.get(0).getChild("acl_out")!=null)acl_out=returnList.get(0).getChild("acl_out").getValue();
					
					//FWのacl_in取得
					if(curConfig.getChild("機器タイプ").getValue().equals("CISCO_FW")){
						NJson aclGrpRoot=curConfig.getChild("access-group");
						Iterator<NJson> aclGrpIt=aclGrpRoot.childIterator();
						LABEL:while(aclGrpIt.hasNext()){
							NJson curAclGrp=aclGrpIt.next();
							NJson nameifRoot=curAclGrp.getChild("interface");
							Iterator<NJson> nameifIt=nameifRoot.childIterator();
							while(nameifIt.hasNext()){
								NJson curNameif=nameifIt.next();
								if(curNameif.getChild("nameif").getValue().equals(returnList.get(0).getChild("nameif").getValue())){
									acl_in=curAclGrp.getChild("name").getValue();
									returnList.get(0).put("acl_in",acl_in);
									break LABEL;
								}
							}
						}
					}
							
					wr.println("・送出I/F");
					Iterator<String> resultIt=returnList.get(0).childKeyIterator();
					while(resultIt.hasNext()){
						String curKey=resultIt.next();
						String value=returnList.get(0).getChild(curKey).getValue();
						wr.println(curKey+"::"+value);
					}
					wr.println();
					if(acl_out!=null)mode="out_acl";
					else mode="nexthop_search";
					
				}else if(mode.equals("out_acl")){	//FWはない
					NJson curConfig=jsonMap.get(hostname);
					NJson aclRoot=curConfig.getChild("acl");
					wr.println("・出力方向 out側 acl");
					NJson curAcl=aclRoot.getChild(acl_out);
					List<NJson> aclList=curAcl.getChildList();
					//System.out.println(aclList.size());
					aclList=CiscoNJsonFilter.ciscoPermitFilter(aclList,"permit");
					aclList=CiscoNJsonFilter.ciscoProtocolFilter(aclList,protocol);
					Address tmpSrcAddr=new Address(srcIP);
					aclList=CiscoNJsonFilter.ciscoIPFilter(aclList,"ソースIP","ソースWILD",tmpSrcAddr);
					if(srcPort==null)aclList=CiscoNJsonFilter.ciscoPortFilter(aclList,"ソースPORT",null);
					else aclList=CiscoNJsonFilter.ciscoPortFilter(aclList,"ソースPORT",Integer.parseInt(srcPort));
					Address tmpDstAddr=new Address(dstIP);
					aclList=CiscoNJsonFilter.ciscoIPFilter(aclList,"宛先IP","宛先WILD",tmpDstAddr);
					if(dstPort==null)aclList=CiscoNJsonFilter.ciscoPortFilter(aclList,"宛先PORT",null);
					else aclList=CiscoNJsonFilter.ciscoPortFilter(aclList,"宛先PORT",Integer.parseInt(dstPort));
					
					if(aclList.size()==0)wr.println("★acl許可設定が見つかりません");
					else{
						for(NJson resultAcl:aclList){
							Iterator<String> resultIt=resultAcl.childKeyIterator();
							while(resultIt.hasNext()){
								String curKey=resultIt.next();
								String value=resultAcl.getChild(curKey).getValue();
								wr.println(curKey+"::"+value);
							}
							wr.println();
						}
					}
					mode="nexthop_search";
					
				}else if(mode.equals("nexthop_search")){
					Address searchedIP=new Address(nexthop);
					for(NJson curConfig:jsonMap.values()){
						//System.out.println(curConfig.getChild("hostname").getValue());
						acl_in=null;
						acl_out=null;
						List<NJson> returnList=CiscoNJsonFilter.getIfResultList(curConfig,searchedIP,true);
						if(returnList.size()>0){
							hostname=returnList.get(0).getChild("hostname").getValue();
							i_f=returnList.get(0).getChild("ifName").getValue();
							if(returnList.get(0).getChild("acl_in")!=null)acl_in=returnList.get(0).getChild("acl_in").getValue();
							if(returnList.get(0).getChild("acl_out")!=null)acl_out=returnList.get(0).getChild("acl_out").getValue();
							
							//FWのacl_in取得
							if(curConfig.getChild("機器タイプ").getValue().equals("CISCO_FW")){
								NJson aclGrpRoot=curConfig.getChild("access-group");
								Iterator<NJson> aclGrpIt=aclGrpRoot.childIterator();
								LABEL:while(aclGrpIt.hasNext()){
									NJson curAclGrp=aclGrpIt.next();
									NJson nameifRoot=curAclGrp.getChild("interface");
									Iterator<NJson> nameifIt=nameifRoot.childIterator();
									while(nameifIt.hasNext()){
										NJson curNameif=nameifIt.next();
										if(curNameif.getChild("nameif").getValue().equals(returnList.get(0).getChild("nameif").getValue())){
											acl_in=curAclGrp.getChild("name").getValue();
											returnList.get(0).put("acl_in",acl_in);
											break LABEL;
										}
									}
								}
							}
							
							wr.println("・NextHopの収容機器");
							Iterator<String> resultIt=returnList.get(0).childKeyIterator();
							while(resultIt.hasNext()){
								String curKey=resultIt.next();
								String value=returnList.get(0).getChild(curKey).getValue();
								wr.println(curKey+"::"+value);
							}
							wr.println();
							if(acl_in!=null)mode="in_acl";
							else if(curConfig.getChild("nat")!=null)mode="nat";
							else mode="dst_seg";
							break;
						}
					}
					if(mode.equals("nexthop_search")){
						wr.println("★NextHopが見つかりません:"+nexthop);
						wr.close();
						if(true)System.exit(0);
					}
					
				}else if(mode.equals("last_acl")){
					NJson curConfig=jsonMap.get(hostname);
					NJson aclRoot=curConfig.getChild("acl");
					wr.println("・出力方向 out側 acl");
					NJson curAcl=aclRoot.getChild(acl_out);
					List<NJson> aclList=curAcl.getChildList();
					//System.out.println(aclList.size());
					aclList=CiscoNJsonFilter.ciscoPermitFilter(aclList,"permit");
					aclList=CiscoNJsonFilter.ciscoProtocolFilter(aclList,protocol);
					Address tmpSrcAddr=new Address(srcIP);
					aclList=CiscoNJsonFilter.ciscoIPFilter(aclList,"ソースIP","ソースWILD",tmpSrcAddr);
					if(srcPort==null)aclList=CiscoNJsonFilter.ciscoPortFilter(aclList,"ソースPORT",null);
					else aclList=CiscoNJsonFilter.ciscoPortFilter(aclList,"ソースPORT",Integer.parseInt(srcPort));
					Address tmpDstAddr=new Address(dstIP);
					aclList=CiscoNJsonFilter.ciscoIPFilter(aclList,"宛先IP","宛先WILD",tmpDstAddr);
					if(dstPort==null)aclList=CiscoNJsonFilter.ciscoPortFilter(aclList,"宛先PORT",null);
					else aclList=CiscoNJsonFilter.ciscoPortFilter(aclList,"宛先PORT",Integer.parseInt(dstPort));
					
					if(aclList.size()==0)wr.println("★acl許可設定が見つかりません");
					else{
						for(NJson resultAcl:aclList){
							Iterator<String> resultIt=resultAcl.childKeyIterator();
							while(resultIt.hasNext()){
								String curKey=resultIt.next();
								String value=resultAcl.getChild(curKey).getValue();
								wr.println(curKey+"::"+value);
							}
							wr.println();
						}
					}
					mode="end";
					
				}else if(mode.equals("end")){
					if(reverseFlag){
						//System.out.println(mode);
						break;
					}
					
					String tmpIP=dstIP;
					String tmpPort=dstPort;
					dstIP=srcIP;
					dstPort=srcPort;
					srcIP=tmpIP;
					srcPort=tmpPort;
					reverseFlag=true;
					mode="src_seg";
				}
			}
			
			//クローズ
			wr.close();
		}
	}
	
	private static String getSearchStr(String protocol,String srcIP,String srcPort,String dstIP,String dstPort){
		StringBuilder returnBuilder=new StringBuilder();
		
		returnBuilder.append(protocol+"_");
		returnBuilder.append(srcIP);
		if(srcPort!=null)returnBuilder.append("#"+srcPort);
		returnBuilder.append("→");
		returnBuilder.append(dstIP);
		if(dstPort!=null)returnBuilder.append("#"+dstPort);
		
		return returnBuilder.toString().trim();
	}
}
