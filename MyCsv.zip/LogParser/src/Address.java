import java.util.*;

public class Address{
	private long address;	//ビット列
	private long mask;	//ビット列
	
	public Address(String addrStr){	//アドレス形式。マスク長のないものは/32で生成
		if(!AddressUtility.isLegalAddrStr(addrStr))throw new IllegalArgumentException("想定外アドレス:"+addrStr);
		if(addrStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")){
			address=AddressUtility.getBit(addrStr);
			mask = Long.parseLong("11111111111111111111111111111111", 2);
			
		}else if(addrStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}/\\d{1,2}")){
			String[] word=addrStr.split("/");
			address=AddressUtility.getBit(word[0]);
			mask=AddressUtility.getMaskBit(Integer.parseInt(word[1]));
			
		}
	}
	
	public Address(String addrStr,int maskLength){	//アドレス形式とマスク長で生成
		if(!AddressUtility.isLegalAddrStr(addrStr))throw new IllegalArgumentException("想定外アドレス:"+addrStr);
		address=AddressUtility.getBit(addrStr);
		mask=AddressUtility.getMaskBit(maskLength);
	}
	
	public Address(String addrStr,String maskStr){	//アドレス形式のアドレス＋マスクで生成
		if(!AddressUtility.isLegalAddrStr(addrStr))throw new IllegalArgumentException("想定外アドレス:"+addrStr);
		if(!AddressUtility.isLegalMask(maskStr))throw new IllegalArgumentException("想定外マスク:"+maskStr);
		
		address=AddressUtility.getBit(addrStr);
		mask=AddressUtility.getBit(maskStr);
	}
	
	public long getAddress(){
		return address;
	}
	
	public long getMask(){
		return mask;
	}
	
	public String getSimpleStr(){
		return AddressUtility.getStrExp(address);
	}
	
	@Override
	public String toString(){	//Detail表示
		return AddressUtility.getStrExp(address)+"/"+AddressUtility.getMaskLength(mask);
	}
}
