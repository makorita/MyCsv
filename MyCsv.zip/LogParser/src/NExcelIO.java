import java.io.*;
import java.util.*;

import org.apache.poi.*;
import org.apache.poi.ss.formula.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.openxml4j.exceptions.*;
import org.apache.poi.xssf.usermodel.*;

public class NExcelIO{
	public static NExcel loadExcel(String srcPath,String sheetName) throws Exception{	//Excel単シートロード
		FileInputStream in=new FileInputStream(srcPath);
		Workbook wb = WorkbookFactory.create(in);
		in.close();
		
		return loadExcel(wb,sheetName);
	}
	
	public static NExcel loadExcel(Workbook wb,String sheetName) throws Exception{	//Excel単シートロード
		NExcel returnExl=new NExcel();
		
		Sheet sheet=wb.getSheet(sheetName);
		
		ArrayList<String> header=new ArrayList<String>();
		Row headerRow=sheet.getRow(0);
		if(headerRow==null)return null;
		for(int cellIndex=0;cellIndex<headerRow.getLastCellNum();cellIndex++){
			Cell cell=headerRow.getCell(cellIndex);
			if(cell==null)return null;
			if(cell.getCellType()==CellType.BLANK || cell.getCellType()==CellType.ERROR)return null;
			
			String tmpHeaderStr=null;
			if(cell.getCellType()==CellType.STRING)tmpHeaderStr=cell.getStringCellValue();
			else if(cell.getCellType()==CellType.NUMERIC)tmpHeaderStr=String.format("%.2f",cell.getNumericCellValue());
			else if(cell.getCellType()==CellType.BOOLEAN)tmpHeaderStr=String.valueOf(cell.getBooleanCellValue());
			header.add(tmpHeaderStr);
		}
		returnExl.setHeader(header);
		
		FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();
		for(int rowIndex=1;rowIndex<=sheet.getLastRowNum();rowIndex++){	//rowの最大値は最大index
			Row row=sheet.getRow(rowIndex);
			if(row==null)continue;
			HashMap<String,String> curRow=new HashMap<String,String>();
			for(int cellIndex=0;cellIndex<row.getLastCellNum();cellIndex++){
				Cell cell=row.getCell(cellIndex);
				if(cell==null)continue;
				if(cell.getCellType()==CellType.BLANK || cell.getCellType()==CellType.ERROR)continue;
				
				String tmpStr=null;
				if(cell.getCellType()==CellType.STRING)tmpStr=cell.getStringCellValue();
				else if(cell.getCellType()==CellType.NUMERIC)tmpStr=String.format("%.2f",cell.getNumericCellValue());
				else if(cell.getCellType()==CellType.BOOLEAN)tmpStr=String.valueOf(cell.getBooleanCellValue());
				else if(cell.getCellType()==CellType.FORMULA){
					CellValue cellValue = evaluator.evaluate(cell);
					if(cellValue.getCellType()==CellType.STRING)tmpStr=cellValue.getStringValue();
					else if(cellValue.getCellType()==CellType.NUMERIC)tmpStr=String.format("%.2f",cellValue.getNumberValue());
					else if(cellValue.getCellType()==CellType.BOOLEAN)tmpStr=String.valueOf(cellValue.getBooleanValue());
				}
				if(tmpStr!=null)curRow.put(header.get(cellIndex),tmpStr);
			}
			returnExl.addRow(curRow);
		}
		
		wb.close();
		
		return returnExl;
	}
	
	public static ArrayList<NExcel> loadExcel(String srcPath) throws Exception{	//Excelロード
		ArrayList<NExcel> returnList=new ArrayList<NExcel>();
		
		FileInputStream in=new FileInputStream(srcPath);
		Workbook wb = WorkbookFactory.create(in);
		in.close();
		
		for(int sheetIndex=0;sheetIndex<wb.getNumberOfSheets();sheetIndex++){
			Sheet sheet=wb.getSheetAt(sheetIndex);
			NExcel tmpExl=loadExcel(wb,sheet.getSheetName());
			if(tmpExl!=null)returnList.add(tmpExl);
		}
		
		return returnList;
	}
	
	//Workbookの初期化:
	//Workbook wb = new XSSFWorkbook();
	public static void saveExcel(NExcel curExl,Workbook wb,String sheetName,String dstPath) throws Exception{	//Excelセーブ
		int idx=wb.getSheetIndex(sheetName);
		if(idx>=0)wb.removeSheetAt(idx);
		
		Sheet sheet=wb.createSheet(sheetName);
		Row headerRow=sheet.createRow(0);
		for(int colIndex=0;colIndex<curExl.getHeaderSize();colIndex++){
			Cell tmpCell=headerRow.createCell(colIndex);
			tmpCell.setCellValue(curExl.getHeader(colIndex));
		}
		for(int rowIndex=0;rowIndex<curExl.getContentSize();rowIndex++){
			Row row=sheet.createRow(rowIndex+1);
			for(int colIndex=0;colIndex<curExl.getHeaderSize();colIndex++){
				Cell cell=row.createCell(colIndex);
				cell.setCellValue(curExl.getValue(rowIndex,curExl.getHeader(colIndex)));
			}
		}
		FileOutputStream out=new FileOutputStream(dstPath);
		wb.write(out);
		out.close();
	}
}
