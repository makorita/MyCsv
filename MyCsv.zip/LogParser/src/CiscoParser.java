import java.util.*;
import java.util.regex.*;

public class CiscoParser{
	public static List<String> extractConfig(List<String> lines){	//コンフィグ抽出
		List<String> returnList=new ArrayList<String>();
		
		String mode="START";
		for(String curStr:lines){
			if(mode.equals("START")){	//開始条件
				if(curStr.matches(".*sh.* run.*"))mode="RUN";
				else if(curStr.matches(".*sh.* sta.*"))mode="RUN";
				else if(curStr.matches("Building configuration.*"))mode="RUN";
				
			}else if(mode.equals("RUN")){
				returnList.add(curStr);
				
				//終了条件
				if(curStr.matches("end"))mode="END";
				if(mode.equals("END"))break;
			}
			
		}
		
		if(!mode.equals("END"))throw new IllegalArgumentException("想定外モード:"+mode);
		
		return returnList;
	}
	
	public static List<String> extractShIpRoute(List<String> lines){	//show ip route抽出
		List<String> returnList=new ArrayList<String>();
		
		String mode="START";
		for(String curStr:lines){
			if(mode.equals("START")){	//開始条件
				if(curStr.matches(".*sh.* ip.* rou.*")){
					if(curStr.matches(".*sh.* plat.* ip.* rou.*"))continue;	//show platform ip unicast failed route
					
					mode="HEAD";
				}
				
			}else if(mode.equals("HEAD")){
				//終了条件
				if(curStr.matches(".*#.*"))mode="END";
				if(mode.equals("END"))break;
				
				if(curStr.matches(".*\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}.*")){
					if(curStr.matches(".*last resort.*"))continue;
					if(curStr.matches(".*Default gateway.*"))continue;
					
					//System.out.println(curStr);
					returnList.add(curStr);
					mode="ROUTE";
				}
			}else if(mode.equals("ROUTE")){
				//終了条件
				if(curStr.matches(".*#.*"))mode="END";
				if(mode.equals("END"))break;
				
				if(!curStr.matches(".*\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}.*")){
					if(!curStr.matches(".*is directly connected.*"))throw new IllegalArgumentException("想定外ルーティングテーブル行:"+curStr);
				}
				//System.out.println(curStr);
				returnList.add(curStr);
			}
			
		}
		
		return returnList;
	}
	
	public static String getHostname(List<String> curConfig){
		for(String curStr:curConfig){
			if(curStr.matches("hostname .*"))return curStr.replace("hostname ","");
		}
		
		return null;
	}
	
	public static void addInterface(List<String> curConfig,LinkedHashMap<String,String> pathValueMap){
		String mode="IF_OUT";
		String curIfName=null;
		for(String curStr:curConfig){
			curStr=curStr.trim();	//トリム実行
			//if(mode.equals("IF_IN"))System.out.println(curStr);
			//if(curStr.matches("interface .*"))System.out.println(curStr);
			
			if(mode.equals("IF_OUT") && curStr.matches("interface .*")){
				curIfName=curStr.replace("interface ","");
				pathValueMap.put("interface##"+curIfName+"##ifName",curIfName);
				mode="IF_IN";
			}else if(mode.equals("IF_IN") && curStr.matches("!")){
				mode="IF_OUT";
			}else if(mode.equals("IF_IN") && curStr.matches("description .*")){
				pathValueMap.put("interface##"+curIfName+"##description",curStr.replace("description ",""));
			}else if(mode.equals("IF_IN") && curStr.matches("switchport access vlan .*")){
				pathValueMap.put("interface##"+curIfName+"##access_vlan",curStr.replace("switchport access vlan ",""));
				pathValueMap.put("interface##"+curIfName+"##switch_mode","access");
			}else if(mode.equals("IF_IN") && curStr.matches("switchport mode trunk")){
				pathValueMap.put("interface##"+curIfName+"##switch_mode","trunk");
			}else if(mode.equals("IF_IN") && curStr.matches("description .*")){
				pathValueMap.put("interface##"+curIfName+"##description",curStr.replace("description ",""));
			}else if(mode.equals("IF_IN") && curStr.matches("ip address \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")){
				String[] word=curStr.split(" ");
				pathValueMap.put("interface##"+curIfName+"##ip",word[2]);
				pathValueMap.put("interface##"+curIfName+"##mask",word[3]);
			}else if(mode.equals("IF_IN") && curStr.matches("ip address \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} secondary")){
				String[] word=curStr.split(" ");
				pathValueMap.put("interface##"+curIfName+"##secondary##"+word[2]+"##ip",word[2]);
				pathValueMap.put("interface##"+curIfName+"##secondary##"+word[2]+"##mask",word[3]);
			}else if(mode.equals("IF_IN") && curStr.matches("standby \\d+ ip \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")){
				String[] word=curStr.split(" ");
				pathValueMap.put("interface##"+curIfName+"##standby##"+word[1]+"##ip",word[3]);
			}else if(mode.equals("IF_IN") && curStr.matches("standby \\d+ priority \\d+")){
				String[] word=curStr.split(" ");
				pathValueMap.put("interface##"+curIfName+"##standby##"+word[1]+"##priority",word[3]);
			}else if(mode.equals("IF_IN") && curStr.matches("ip access-group .+ (in|out)")){
				String[] word=curStr.split(" ");
				pathValueMap.put("interface##"+curIfName+"##acl_"+word[3],word[2]);
			}else if(mode.equals("IF_IN") && curStr.matches("ip nat (inside|outside)")){
				String[] word=curStr.split(" ");
				pathValueMap.put("interface##"+curIfName+"##nat",word[2]);
			}else if(mode.equals("IF_IN") && curStr.matches("speed .+")){
				String[] word=curStr.split(" ");
				pathValueMap.put("interface##"+curIfName+"##speed",word[1]);
			}else if(mode.equals("IF_IN") && curStr.matches("duplex .+")){
				String[] word=curStr.split(" ");
				pathValueMap.put("interface##"+curIfName+"##duplex",word[1]);
			}else if(mode.equals("IF_IN") && curStr.matches("negotiation auto")){
				pathValueMap.put("interface##"+curIfName+"##duplex","auto");
			}else if(mode.equals("IF_IN") && curStr.matches("no negotiation auto")){
				pathValueMap.put("interface##"+curIfName+"##duplex","full");
			}else if(mode.equals("IF_IN") && curStr.matches("shutdown")){
				pathValueMap.put("interface##"+curIfName+"##shutdown","true");
			}
				
		}
	}
	
	public static void addNat(List<String> curConfig,LinkedHashMap<String,String> pathValueMap){
		int natIndex=1;
		for(String curStr:curConfig){
			if(!curStr.matches("ip nat .*"))continue;
			//System.out.println(curStr);
			curStr=curStr.trim();	//トリム実行
			
			String editStr=curStr;
			String mode="START";
			while(editStr.length()>0){
				if(mode.equals("START") && editStr.matches("ip nat .*")){
					pathValueMap.put("nat##"+String.format("%04d", natIndex)+"##raw_config",curStr);
					editStr=editStr.replaceFirst("ip nat ","");
					mode="IN_OUT";
				}else if(mode.equals("IN_OUT") && editStr.matches("(inside|outside) .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("nat##"+String.format("%04d", natIndex)+"##in_out",word[0]);
					editStr=editStr.replaceFirst(word[0]+" ","");
					mode="NAT_MODE";
				}else if(mode.equals("IN_OUT") && editStr.matches("pool .*")){	//nat poolの定義は未実装
					editStr="";
					natIndex--;
					mode="END";
				}else if(mode.equals("NAT_MODE") && editStr.matches("source static network .*")){
					pathValueMap.put("nat##"+String.format("%04d", natIndex)+"##mode","source_static_network");
					editStr=editStr.replaceFirst("source static network ","");
					mode="BEF_IP";
				}else if(mode.equals("NAT_MODE") && editStr.matches("source static .*")){
					pathValueMap.put("nat##"+String.format("%04d", natIndex)+"##mode","source_static");
					editStr=editStr.replaceFirst("source static ","");
					mode="BEF_IP";
				}else if(mode.equals("NAT_MODE") && editStr.matches("source list .*")){	//nat poolの定義は未実装
					editStr="";
					natIndex--;
					mode="END";
				}else if(mode.equals("BEF_IP") && editStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("nat##"+String.format("%04d", natIndex)+"##befIP",word[0]);
					editStr=editStr.replaceFirst(word[0]+" ","");
					mode="AFT_IP";
				}else if(mode.equals("AFT_IP") && editStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("nat##"+String.format("%04d", natIndex)+"##aftIP",word[0]);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else if(mode.equals("OPTION") && editStr.matches("/\\d+.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("nat##"+String.format("%04d", natIndex)+"##nat_mask",word[0]);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
				}else if(mode.equals("OPTION") && editStr.matches("add-route.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("nat##"+String.format("%04d", natIndex)+"##add-route","true");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
				}else if(mode.equals("OPTION") && editStr.matches("redundancy .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("nat##"+String.format("%04d", natIndex)+"##redundancy_name",word[1]);
					editStr=editStr.replaceFirst("redundancy "+word[1],"");
					editStr=editStr.trim();
				}else throw new IllegalArgumentException("想定外NAT設定:"+mode+","+editStr);
					
			}
			
			natIndex++;
		}
	}
	
	public static void addStaticRoute(List<String> curConfig,LinkedHashMap<String,String> pathValueMap){
		int routeIndex=1;
		for(String curStr:curConfig){
			if(!curStr.matches("ip route .*"))continue;
			//System.out.println(curStr);
			curStr=curStr.trim();	//トリム実行
			
			String editStr=curStr;
			String mode="START";
			while(editStr.length()>0){
				if(mode.equals("START") && editStr.matches("ip route .*")){
					pathValueMap.put("static_route##"+String.format("%04d", routeIndex)+"##raw_config",curStr);
					editStr=editStr.replace("ip route ","");
					mode="SRC_IP";
				}else if(mode.equals("SRC_IP") && editStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("static_route##"+String.format("%04d", routeIndex)+"##宛先ネットワーク",word[0]);
					pathValueMap.put("static_route##"+String.format("%04d", routeIndex)+"##宛先マスク",word[1]);
					editStr=editStr.replaceFirst(word[0]+" "+word[1]+" ","");
					mode="OUTPUT_IF";
				}else if(mode.equals("OUTPUT_IF") && NetworkUtility.isIfName(editStr.split(" ")[0])){
					String[] word=editStr.split(" ");
					pathValueMap.put("static_route##"+String.format("%04d", routeIndex)+"##送出IF",word[0]);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="NEXTHOP";
				}else if((mode.equals("OUTPUT_IF") || mode.equals("NEXTHOP")) && editStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("static_route##"+String.format("%04d", routeIndex)+"##ネクストホップ",word[0]);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else if((mode.equals("OPTION") || mode.equals("NEXTHOP")) && editStr.matches("\\d+.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("static_route##"+String.format("%04d", routeIndex)+"##AD値",word[0]);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else if(mode.equals("OPTION") && editStr.matches("track .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("static_route##"+String.format("%04d", routeIndex)+"##track",word[1]);
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else throw new IllegalArgumentException("想定外Static Route設定:"+mode+","+editStr);
			}
			
			routeIndex++;
		}
	}
	
	public static void addAcl(List<String> curConfig,LinkedHashMap<String,String> pathValueMap){
		int aclIndex=-1;
		String aclNum=null;
		for(String curStr:curConfig){
			if(!curStr.matches("access-list .*"))continue;
			//System.out.println(curStr);
			curStr=curStr.trim();	//トリム実行
			
			String editStr=curStr;
			String mode="START";
			while(editStr.length()>0){
				//System.out.println("#"+editStr+"#");
				if(mode.equals("START") && editStr.matches("access-list .*")){
					editStr=editStr.replaceFirst("access-list ","");
					mode="acl番号";
				}else if(mode.equals("acl番号") && editStr.matches("(.*?) .*")){
					String[] word=editStr.split(" ");
					if(aclNum==null || !aclNum.equals(word[0])){
						aclNum=word[0];
						aclIndex=10;
					}
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##raw_config",curStr);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##acl番号",word[0]);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="許可";
				}else if(mode.equals("許可") && editStr.matches("(permit|deny) .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##許可",word[0]);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="プロトコル";
				}else if(mode.equals("許可") && editStr.matches("remark.*")){
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##許可","remark");
					editStr=editStr.replaceFirst("remark ","");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##remark文字",editStr);
					editStr="";
					mode="END";
				}else if(mode.equals("プロトコル") && NetworkUtility.isProtocol(editStr.split(" ")[0])){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##プロトコル",word[0]);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="ソースIP";
				}else if((mode.equals("ソースIP") || mode.equals("プロトコル")) && editStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースIP",word[0]);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースWILD",word[1]);
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="ソースPORT";
				}else if((mode.equals("ソースIP") || mode.equals("プロトコル")) && editStr.matches("host.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースIP",word[1]);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースWILD","0.0.0.0");
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="ソースPORT";
				}else if((mode.equals("ソースIP") || mode.equals("プロトコル")) && editStr.matches("any.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースIP","0.0.0.0");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースWILD","255.255.255.255");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="ソースPORT";
				}else if(mode.equals("ソースPORT") && editStr.matches("eq .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースPORT","eq "+NetworkUtility.toPortNumber(word[1]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="宛先IP";
				}else if(mode.equals("ソースPORT") && editStr.matches("gt .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースPORT","gt "+NetworkUtility.toPortNumber(word[1]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="宛先IP";
				}else if(mode.equals("ソースPORT") && editStr.matches("range .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースPORT","range "+NetworkUtility.toPortNumber(word[1])+" "+NetworkUtility.toPortNumber(word[2]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1]+" "+word[2],"");
					editStr=editStr.trim();
					mode="宛先IP";
				}else if((mode.equals("宛先IP") || mode.equals("ソースPORT")) && editStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先IP",word[0]);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先WILD","0.0.0.0");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="宛先PORT";
				}else if((mode.equals("宛先IP") || mode.equals("ソースPORT")) && editStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先IP",word[0]);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先WILD",word[1]);
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="宛先PORT";
				}else if((mode.equals("宛先IP") || mode.equals("ソースPORT")) && editStr.matches("host.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先IP",word[1]);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先WILD","0.0.0.0");
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="宛先PORT";
				}else if((mode.equals("宛先IP") || mode.equals("ソースPORT")) && editStr.matches("any.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先IP","0.0.0.0");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先WILD","255.255.255.255");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="宛先PORT";
				}else if(mode.equals("宛先PORT") && editStr.matches("eq .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先PORT","eq "+NetworkUtility.toPortNumber(word[1]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else if(mode.equals("宛先PORT") && editStr.matches("gt .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先PORT","gt "+NetworkUtility.toPortNumber(word[1]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else if(mode.equals("宛先PORT") && editStr.matches("range .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先PORT","range "+NetworkUtility.toPortNumber(word[1])+" "+NetworkUtility.toPortNumber(word[2]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1]+" "+word[2],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else if((mode.equals("OPTION") || mode.equals("宛先PORT")) && editStr.matches("log.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##log","true");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else if((mode.equals("OPTION") || mode.equals("宛先PORT")) && editStr.matches("established.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##established","true");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else throw new IllegalArgumentException("想定外access-list:"+mode+","+editStr);
			}
			aclIndex+=10;
		}
	}

	public static void addAclNew(List<String> curConfig,LinkedHashMap<String,String> pathValueMap){
		String rowMode="ACL_OUT";
		int aclIndex=-1;
		String aclNum=null;
		for(String curStr:curConfig){
			curStr=curStr.trim();	//トリム実行
			if(curStr.matches("ip access-list .*")){
				rowMode="ACL_IN";
			}else if(rowMode.equals("ACL_IN") && !curStr.matches("\\d+ .*") && !curStr.matches("(permit|deny|remark) .*")){
				rowMode="ACL_OUT";
				continue;
			}else if(rowMode.equals("ACL_OUT"))continue;
			//System.out.println(curStr);
			
			String editStr=curStr;
			String mode="START";
			while(editStr.length()>0){
				if(mode.equals("START") && editStr.matches("ip access-list (standard|extended) .*")){
					String[] word=editStr.split(" ");
					editStr=editStr.replaceFirst("ip access-list (standard|extended) ","");
					editStr=editStr.trim();
					aclNum=editStr;
					aclIndex=0;
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##raw_config",curStr);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##acl番号",aclNum);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##mode",word[2]);
					
					editStr="";
					mode="END";
				}else if(mode.equals("START") && editStr.matches("\\d+ .*")){
					String[] word=editStr.split(" ");
					aclIndex=Integer.parseInt(word[0]);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##raw_config",curStr);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##acl番号",aclNum);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="許可";
				}else if((mode.equals("許可") || mode.equals("START")) && editStr.matches("(permit|deny) .*")){
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##raw_config",curStr);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##acl番号",aclNum);
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##許可",word[0]);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="プロトコル";
				}else if((mode.equals("許可") || mode.equals("START")) && editStr.matches("remark.*")){
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##raw_config",curStr);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##acl番号",aclNum);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##許可","remark");
					editStr=editStr.replaceFirst("remark ","");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##remark文字",editStr);
					editStr="";
					mode="END";
				}else if(mode.equals("プロトコル") && NetworkUtility.isProtocol(editStr.split(" ")[0])){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##プロトコル",word[0]);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="ソースIP";
				}else if(mode.equals("プロトコル") && NetworkUtility.isProtocol(editStr.split(" ")[0])){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##プロトコル",word[0]);
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="ソースIP";
				}else if((mode.equals("ソースIP") || mode.equals("プロトコル")) && editStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースIP",word[0]);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースWILD","0.0.0.0");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="ソースPORT";
				}else if((mode.equals("ソースIP") || mode.equals("プロトコル")) && editStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースIP",word[0]);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースWILD",word[1]);
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="ソースPORT";
				}else if((mode.equals("ソースIP") || mode.equals("プロトコル")) && editStr.matches("host.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースIP",word[1]);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースWILD","0.0.0.0");
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="ソースPORT";
				}else if((mode.equals("ソースIP") || mode.equals("プロトコル")) && editStr.matches("any.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースIP","0.0.0.0");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースWILD","255.255.255.255");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="ソースPORT";
				}else if(mode.equals("ソースPORT") && editStr.matches("eq .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースPORT","eq "+NetworkUtility.toPortNumber(word[1]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="宛先IP";
				}else if(mode.equals("ソースPORT") && editStr.matches("gt .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースPORT","gt "+NetworkUtility.toPortNumber(word[1]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="宛先IP";
				}else if(mode.equals("ソースPORT") && editStr.matches("range .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##ソースPORT","range "+NetworkUtility.toPortNumber(word[1])+" "+NetworkUtility.toPortNumber(word[2]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1]+" "+word[2],"");
					editStr=editStr.trim();
					mode="宛先IP";
				}else if((mode.equals("宛先IP") || mode.equals("ソースPORT")) && editStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先IP",word[0]);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先WILD",word[1]);
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="宛先PORT";
				}else if((mode.equals("宛先IP") || mode.equals("ソースPORT")) && editStr.matches("host.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先IP",word[1]);
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先WILD","0.0.0.0");
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="宛先PORT";
				}else if((mode.equals("宛先IP") || mode.equals("ソースPORT")) && editStr.matches("any.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先IP","0.0.0.0");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先WILD","255.255.255.255");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="宛先PORT";
				}else if(mode.equals("宛先PORT") && editStr.matches("eq .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先PORT","eq "+NetworkUtility.toPortNumber(word[1]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else if(mode.equals("宛先PORT") && editStr.matches("gt .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先PORT","gt "+NetworkUtility.toPortNumber(word[1]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else if(mode.equals("宛先PORT") && editStr.matches("range .*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##宛先PORT","range "+NetworkUtility.toPortNumber(word[1])+" "+NetworkUtility.toPortNumber(word[2]));
					editStr=editStr.replaceFirst(word[0]+" "+word[1]+" "+word[2],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else if((mode.equals("OPTION") || mode.equals("宛先PORT")) && editStr.matches("log.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##log","true");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else if((mode.equals("OPTION") || mode.equals("宛先PORT")) && editStr.matches("established.*")){
					String[] word=editStr.split(" ");
					pathValueMap.put("acl##"+aclNum+"##"+String.format("%05d", aclIndex)+"##established","true");
					editStr=editStr.replaceFirst(word[0],"");
					editStr=editStr.trim();
					mode="OPTION";
				}else throw new IllegalArgumentException("想定外access-list:"+mode+","+editStr);
			}
			aclIndex+=10;
		}
	}

	public static void addLogRoute(List<String> curRouteTable,LinkedHashMap<String,String> pathValueMap){
		Pattern ipP= Pattern.compile("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}(/\\d{1,2}) .*subnetted,");
		Matcher ipM = null;
		Pattern routeP1= Pattern.compile("(C|L|S) +(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})(/\\d{1,2})* is directly connected(, .*)*");
		Matcher routeM1=null;
		Pattern routeP2= Pattern.compile("(S)(\\*)* +(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})(/\\d{1,2})* \\[(\\d+)/(\\d+)\\] via (\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})(, .*)*");
		Matcher routeM2=null;
		Pattern routeP3= Pattern.compile("(D EX|D) +(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})(/\\d{1,2})* +\\[(\\d+)/(\\d+)\\] via (\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}), .*, (.*)");
		Matcher routeM3=null;
		Pattern routeP4= Pattern.compile(" +\\[(\\d+)/(\\d+)\\] via (\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}), .*, (.*)");
		Matcher routeM4=null;
		
		int routeIndex=1;
		String curSubnet=null;
		for(int rowIndex=0;rowIndex<curRouteTable.size();rowIndex++){
			String curStr=curRouteTable.get(rowIndex);
			
			ipM=ipP.matcher(curStr);
			if(ipM.find()){
				curSubnet=ipM.group(1).replaceFirst("/","");
				//System.out.println(curSubnet);
				continue;
			}
			routeM1=routeP1.matcher(curStr);
			if(routeM1.find()){
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##raw_output",curStr);
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##ルーティング種",routeM1.group(1));
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##宛先ネットワーク",routeM1.group(2));
				if(routeM1.group(3)!=null)pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##宛先マスク長",routeM1.group(3).replaceFirst("/",""));
				else pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##宛先マスク長",curSubnet);
				if(routeM1.group(4)!=null)pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##送出IF",routeM1.group(4).replaceFirst(", ",""));
				routeIndex++;
				continue;
			}
			routeM2=routeP2.matcher(curStr);
			if(routeM2.find()){
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##raw_output",curStr);
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##ルーティング種",routeM2.group(1));
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##宛先ネットワーク",routeM2.group(3));
				if(routeM2.group(4)!=null)pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##宛先マスク長",routeM2.group(4).replaceFirst("/",""));
				else pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##宛先マスク長",curSubnet);
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##ネクストホップ",routeM2.group(7));
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##AD値",routeM2.group(5));
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##メトリック",routeM2.group(6));
				if(routeM2.group(8)!=null)pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##送出IF",routeM2.group(8).replaceFirst(", ",""));
				routeIndex++;
				continue;
			}
			if(curStr.matches("(D EX|D) +(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})(/\\d{1,2})* +")){	//複数行補正
				curStr=curStr+curRouteTable.get(rowIndex+1);
				rowIndex++;
			}
			routeM3=routeP3.matcher(curStr);
			if(routeM3.find()){
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##raw_output",curStr);
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##ルーティング種",routeM3.group(1));
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##宛先ネットワーク",routeM3.group(2));
				if(routeM3.group(3)!=null)pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##宛先マスク長",routeM3.group(3).replaceFirst("/",""));
				else pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##宛先マスク長",curSubnet);
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##ネクストホップ",routeM3.group(6));
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##AD値",routeM3.group(4));
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##メトリック",routeM3.group(5));
				pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##送出IF",routeM3.group(7).replaceFirst(", ",""));
				routeIndex++;
				continue;
			}
			routeM4=routeP4.matcher(curStr);
			if(routeM4.find()){
				String preStr=curRouteTable.get(rowIndex-1);
				preStr=preStr.substring(0,preStr.indexOf("["));
				curStr=preStr+curStr;
				
				routeM3=routeP3.matcher(curStr);
				if(routeM3.find()){
					pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##raw_output",curStr);
					pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##ルーティング種",routeM3.group(1));
					pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##宛先ネットワーク",routeM3.group(2));
					if(routeM3.group(3)!=null)pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##宛先マスク長",routeM3.group(3).replaceFirst("/",""));
					else pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##宛先マスク長",curSubnet);
					pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##ネクストホップ",routeM3.group(6));
					pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##AD値",routeM3.group(4));
					pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##メトリック",routeM3.group(5));
					pathValueMap.put("log_route##"+String.format("%04d", routeIndex)+"##送出IF",routeM3.group(7).replaceFirst(", ",""));
					routeIndex++;
					continue;
				}
			}
			if(!curStr.matches(" +is directly connected.*"))throw new IllegalArgumentException("想定外ルーティングテーブル行:"+curStr);
			
		}
	}
}
