import java.util.*;
import java.io.*;
import java.nio.file.*;
import java.util.regex.*;

public class MyJson implements Serializable{
	private static final long serialVersionUID=1L;
	
	static final String SEP_STR="#SEP#";
	
	String value;
	LinkedHashMap<String,MyJson> childMap;
	
	public MyJson(){
		childMap=new LinkedHashMap<String,MyJson>();
	}
	
	public MyJson(String value){
		childMap=new LinkedHashMap<String,MyJson>();
		setValue(value);
	}
	
	public String getValue(){
		return value;
	}
	
	public void setValue(String value){
		this.value=escapeJsonString(value);
		childMap.clear();
	}
	
	/*
	public LinkedHashMap<String,MyJson> getChildMap(){
		return childMap;
	}
	*/
	
	public int childSize(){
		return childMap.size();
	}
	
	public boolean containsKey(String keyStr){
		return childMap.containsKey(keyStr);
	}
	
	public Iterator<String> childKeyIterator(){
		return childMap.keySet().iterator();
	}
	
	public MyJson getChild(String key){
		return childMap.get(key);
	}
	
	public void put(String key,MyJson childJson){
		value=null;
		childMap.put(escapeJsonString(key),childJson);
	}
	
	public MyJson pathGet(String pathStr){	//path指定されたMyJsonを返す。無い場合は作成。
		String[] pathList=pathStr.split(SEP_STR);
		
		MyJson curJson=this;
		for(String curPath:pathList){
			if(!curJson.containsKey(curPath)){
				MyJson childJson=new MyJson();
				curJson.put(curPath,childJson);
				curJson=childJson;
				continue;
			}
			
			curJson=curJson.getChild(curPath);
		}
		
		return curJson;
	}
	
	//↓↓↓utility
	public boolean isJson(){
		if(childMap.size()>0)return true;
		else return false;
	}
	
	public MyJson hasKeyChildGet(String eqStr){	//再帰検索してキーにeqStrを持つ場合、そのchild MyJsonを返す
		MyJson returnJson=new MyJson();
		
		for(String key:childMap.keySet()){
			MyJson curJson=childMap.get(key);
			if(key.equals(eqStr)){
				returnJson.put(key,curJson);
				continue;
			}
			if(!curJson.isJson())continue;
			
			boolean kekkaFlag=curJson.recursiveHasKey(eqStr);
			if(kekkaFlag)returnJson.put(key,curJson);
		}
		
		return returnJson;
	}
	
	private boolean recursiveHasKey(String eqStr){
		for(String key:childMap.keySet()){
			if(key.equals(eqStr))return true;
			
			MyJson curJson=childMap.get(key);
			if(!curJson.isJson())continue;
			
			boolean kekkaFlag=curJson.recursiveHasKey(eqStr);
			if(kekkaFlag)return true;
		}
		
		return false;
	}
	
	public MyJson hasValueChildGet(String reStr){	//再帰検索して値がreStr(正規表現)を包含する場合、そのchild MyJsonを返す
		MyJson returnJson=new MyJson();
		
		for(String key:childMap.keySet()){
			MyJson curJson=childMap.get(key);
			if(!curJson.isJson() && curJson.getValue()==null)continue;
			
			if(!curJson.isJson() && curJson.getValue().matches(".*"+reStr+".*")){
				returnJson.put(key,curJson);
				continue;
			}
			boolean kekkaFlag=curJson.recursiveHasValue(reStr);
			if(kekkaFlag)returnJson.put(key,curJson);
		}
		
		return returnJson;
	}
	
	private boolean recursiveHasValue(String reStr){
		for(String key:childMap.keySet()){
			MyJson curJson=childMap.get(key);
			if(curJson.isJson()){
				boolean kekkaFlag=curJson.recursiveHasValue(reStr);
				if(kekkaFlag)return true;
				
			}else if(curJson.getValue()==null){
				continue;
				
			}else if(curJson.getValue().matches(".*"+reStr+".*"))return true;
		}
		
		return false;
	}
	
	//↓↓↓loader,saver
	public void loadJson(String srcPath) throws Exception{	//loadは順序を保持できない
		Path file = Paths.get(srcPath);
		String text = Files.readString(file);
		
		parseObject(text,this);
	}
	
	private String parseObject(String curStr,MyJson curJson){
		Pattern strP = Pattern.compile("\"(.*?)\"", Pattern.DOTALL);
		Matcher m = null;
		
		String editStr=curStr;
		editStr=escape2(editStr);
		editStr=editStr.trim();
		
		//オブジェクトの先頭かっこ除去
		if(editStr.charAt(0)=='{'){
			editStr=editStr.replaceFirst("\\{","");
			editStr=editStr.trim();
		}else throw new IllegalArgumentException("想定外の文字列："+editStr);
		
		while(true){
			//キー取得
			String key=null;
			if(editStr.charAt(0)=='"'){
				m=strP.matcher(editStr);
				m.find();
				key = escape2(m.group(1)); // エスケープ解除を追加
				editStr=editStr.replaceFirst("\"(.*?)\"","");
				editStr=editStr.trim();
			}else throw new IllegalArgumentException("想定外のキー："+editStr);
			MyJson childJson=new MyJson();
			curJson.put(key,childJson);
			
			//:除去
			editStr=editStr.replaceFirst(" *: *","");
			editStr=editStr.trim();
			
			//値箇所の取得
			if(editStr.charAt(0)=='{'){
				editStr=parseObject(editStr,childJson);
			}else if(editStr.charAt(0)=='"'){
				m=strP.matcher(editStr);
				m.find();
				String value = escape2(m.group(1)); // エスケープ解除を追加
				childJson.setValue(value);
				editStr=editStr.replaceFirst("\"(.*?)\"","");
				editStr=editStr.trim();
			}else throw new IllegalArgumentException("想定外の値："+editStr);
			
			if(editStr.charAt(0)=='}'){
				editStr=editStr.replaceFirst("\\}","");
				editStr=editStr.trim();
				break;
			}else if(editStr.charAt(0)==','){
				editStr=editStr.replaceFirst(",","");
				editStr=editStr.trim();
				continue;
			}else throw new IllegalArgumentException("想定外の区切り："+editStr);
			
		}
		
		return editStr;
	}
	
	public static MyJson loadSerialze(String srcPath) throws Exception{
		MyJson returnJson=null;
		
		try{
			ObjectInputStream ois=new ObjectInputStream(new FileInputStream(srcPath));
			
			returnJson=(MyJson)ois.readObject();
			
			ois.close();
			
		}catch(IOException | ClassNotFoundException e){
			System.out.println(e);
			if(true)System.exit(0);
		}
		
		return returnJson;
	}
	
	public void saveJson(String dstPath) throws Exception{
		PrintWriter wr=new PrintWriter(new FileWriter(dstPath));
		wr.print("{");
		if(isJson()){
			recursiveWrite(this,wr);
		}else{
			//value変換
			String value=getValue();
			if(value==null)wr.print("\n");
			else{
				value=unescapeJsonString(value);
				
				wr.print("\n"+value);
			}
		}
		wr.print("\n}\n");	
		wr.close();
	}
	
	private void recursiveWrite(MyJson curJson,PrintWriter wr) throws Exception{
		boolean firstCheck=false;
		Iterator<String> it=curJson.childKeyIterator();
		while(it.hasNext()){
			String key=it.next();
			MyJson childJson=curJson.getChild(key);
			
			//key変換
			key=escapeJsonString(key);
			
			if(firstCheck){
				if(childJson.isJson()){
					wr.print(",\n\""+key+"\" : {");
					recursiveWrite(childJson,wr);
					wr.print("\n}");
				}else{
					String value=escapeJsonString(childJson.getValue());
					if(value==null)wr.print(",\n\""+key+"\" : \"\"");
					else{
						wr.print(",\n\""+key+"\" : \""+value+"\"");
					}
				}
			}else{
				if(childJson.isJson()){
					wr.print("\n\""+key+"\" : {");
					recursiveWrite(childJson,wr);
					wr.print("\n}");
				}else{
					String value=escapeJsonString(childJson.getValue());
					if(value==null)wr.print("\n\""+key+"\" : \"\"");
					else{
						wr.print("\n\""+key+"\" : \""+value+"\"");
					}
				}
				
				firstCheck=true;
			}
		}
	}
	
	public void saveSerialize(String dstPath) throws Exception{	//シリアライズ化
		FileOutputStream fileOutputStream=new FileOutputStream(dstPath);
		ObjectOutputStream objectOutputStream=new ObjectOutputStream(fileOutputStream);
		objectOutputStream.writeObject(this);
		objectOutputStream.flush();

		objectOutputStream.close();
	}
	
	public MyPathValue getMyPathValue(){
		MyPathValue returnPV=new MyPathValue();
		
		String pathStr=null;
		recursivePathValue(pathStr,returnPV);
		
		return returnPV;
	}
	
	public void recursivePathValue(String pathStr,MyPathValue returnPV){
		if(isJson()){
			for(String curStr:childMap.keySet()){
				String curPathStr=null;
				if(pathStr!=null)curPathStr=new String(pathStr);
				
				if(curPathStr==null)curPathStr=curStr;
				else curPathStr+=SEP_STR+curStr;
				
				childMap.get(curStr).recursivePathValue(curPathStr,returnPV);
			}
		}else{
			returnPV.put(unescapeJsonString(pathStr),unescapeJsonString(getValue()));
		}
	}
	
	private String escapeJsonString(String input) {
		if (input == null) {
			return null;
		}
		return input.replace("\\", "\\\\")
					.replace("\"", "\\\"")
					.replace("\n", "\\n")
					.replace("\r", "\\r")
					.replace("\t", "\\t");
	}
	
	private String unescapeJsonString(String input) {
		if (input == null) {
			return null;
		}
		return input.replace("\\n", "\n")
					.replace("\\r", "\r")
					.replace("\\t", "\t")
					.replace("\\\\", "\\")
					.replace("\\\"", "\"");
	}
	
	//loadJson内のみ使用
	private String escape2(String input){	//key,value内の\と"を一時退避
		if(input==null)return null;
		
		input=input.replace("\\\\","<y>");
		input=input.replace("\\\"","<d>");
		
		return input;
	}
	
	private String unescape2(String input){
		if(input==null)return null;
		
		input=input.replace("<y>","\\\\");
		input=input.replace("<d>","\\\"");
		
		return input;
	}
	
	public static void deleteFileInFolder(String dirPath) throws Exception{ //指定フォルダのファイルを全削除。サブフォルダは再帰検索しない。
		File rootDir=new File(dirPath);
		File[] fileList=rootDir.listFiles();
		for(File curFile:fileList)curFile.delete();
	}
}
