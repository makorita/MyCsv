import java.util.*;
import java.io.*;
import java.nio.file.*;
import java.util.regex.*;

public class MyJson{
	String value;
	LinkedHashMap<String,MyJson> childMap;
	static LinkedHashMap<String,MyJson> uniqMap=new LinkedHashMap<String,MyJson>();
	
	public MyJson(){
		childMap=new LinkedHashMap<String,MyJson>();
	}
	
	public String getValue(){
		return value;
	}
	
	public void setValue(String value){
		this.value=value;
		childMap.clear();
	}
	
	public void putUniqMap(String name){	//uniqMapに登録
		uniqMap.put(name,this);
	}
	
	public LinkedHashMap<String,MyJson> getChildMap(){
		return childMap;
	}
	
	public boolean containsKey(String keyStr){
		return childMap.containsKey(keyStr);
	}
	
	public MyJson getChild(String key){
		return childMap.get(key);
	}
	
	public void put(String key,MyJson childJson){
		value=null;
		childMap.put(key,childJson);
	}
	
	public Iterator<String> childKeyIterator(){
		return childMap.keySet().iterator();
	}
	
	public boolean isJson(){
		if(childMap.size()>0)return true;
		else return false;
	}
	
	public void loadJson(String srcPath) throws Exception{	//loadは順序を保持できない
		Path file = Paths.get(srcPath);
		String text = Files.readString(file);
		
		parseObject(text,this);
	}
	
	private String parseObject(String curStr,MyJson curJson){
		Pattern strP = Pattern.compile("\"(.*?)\"", Pattern.DOTALL);
		Matcher m = null;
		
		String editStr=curStr;
		editStr=editStr.trim();
		
		//オブジェクトの先頭かっこ除去
		if(editStr.charAt(0)=='{'){
			editStr=editStr.replaceFirst("\\{","");
			editStr=editStr.trim();
		}else throw new IllegalArgumentException("想定外の文字列："+editStr);
		
		while(true){
			//キー取得
			String key=null;
			if(editStr.charAt(0)=='"'){
				m=strP.matcher(editStr);
				m.find();
				key=m.group(1);
				editStr=editStr.replaceFirst("\"(.*?)\"","");
				editStr=editStr.trim();
			}else throw new IllegalArgumentException("想定外のキー："+editStr);
			MyJson childJson=new MyJson();
			curJson.put(key,childJson);
			
			//:除去
			editStr=editStr.replaceFirst(" *: *","");
			editStr=editStr.trim();
			
			//値箇所の取得
			if(editStr.charAt(0)=='{'){
				editStr=parseObject(editStr,childJson);
			}else if(editStr.charAt(0)=='"'){
				m=strP.matcher(editStr);
				m.find();
				String value=m.group(1);
				childJson.setValue(value);
				editStr=editStr.replaceFirst("\"(.*?)\"","");
				editStr=editStr.trim();
			}else throw new IllegalArgumentException("想定外の値："+editStr);
			
			if(editStr.charAt(0)=='}'){
				editStr=editStr.replaceFirst("\\}","");
				editStr=editStr.trim();
				break;
			}else if(editStr.charAt(0)==','){
				editStr=editStr.replaceFirst(",","");
				editStr=editStr.trim();
				continue;
			}else throw new IllegalArgumentException("想定外の区切り："+editStr);
			
		}
		
		return editStr;
	}
	
	public void saveJson(String dstPath) throws Exception{
		PrintWriter wr=new PrintWriter(new FileWriter(dstPath));
		wr.print("{");
		if(isJson()){
			recursiveWrite(this,wr);
		}else{
			wr.print("\n"+getValue());
		}
		wr.print("\n}\n");	
		wr.close();
	}
	
	private void recursiveWrite(MyJson curJson,PrintWriter wr) throws Exception{
		boolean firstCheck=false;
		for (String key : curJson.getChildMap().keySet()) {
			MyJson childJson=curJson.getChildMap().get(key);
			
			if(firstCheck){
				if(childJson.isJson()){
					wr.print(",\n\""+key+"\" : {");
					recursiveWrite(childJson,wr);
					wr.print("\n}");
				}else{
					wr.print(",\n\""+key+"\" : \""+childJson.getValue()+"\"");
				}
			}else{
				if(childJson.isJson()){
					wr.print("\n\""+key+"\" : {");
					recursiveWrite(childJson,wr);
					wr.print("\n}");
				}else{
					wr.print("\n\""+key+"\" : \""+childJson.getValue()+"\"");
				}
				
				firstCheck=true;
			}
		}
	}
}
