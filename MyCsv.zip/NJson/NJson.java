import java.util.*;

public class NJson{
	private String value;
	private LinkedHashMap<String,NJson> childMap;
	public static final String SEP_STR="##";
	
	public NJson(){
		childMap=new LinkedHashMap<String,NJson>();
	}
	
	public String getValue(){
		return value;
	}
	
	public void setValue(String value){
		this.value=value;
		childMap.clear();
	}
	
	public int childSize(){
		return childMap.size();
	}
	
	public boolean containsChild(String childStr){
		return childMap.containsKey(childStr);
	}
	
	public Iterator<String> childKeyIterator(){
		return childMap.keySet().iterator();
	}
	
	public Iterator<NJson> childIterator(){
		return childMap.values().iterator();
	}
	
	public NJson getChild(String key){
		return childMap.get(key);
	}
	
	public void put(String key,String value){
		NJson childJson=new NJson();
		childJson.setValue(value);
		put(key,childJson);
	}
	
	public void put(String key,NJson childJson){
		value=null;
		childMap.put(key,childJson);
	}
	
	public NJson getPathChild(String pathStr){
		String[] word=pathStr.split(SEP_STR);
		
		if(!containsChild(word[0]))return null;
		if(word.length==1)return getChild(word[0]);
		
		pathStr=pathStr.replaceFirst(word[0]+SEP_STR,"");
		return getChild(word[0]).getPathChild(pathStr);
	}
	
	public void addPathChild(String pathStr,String value){
		String[] word=pathStr.split(SEP_STR);
		
		NJson childJson=null;
		if(!containsChild(word[0])){
			childJson=new NJson();
			put(word[0],childJson);
		}else childJson=getChild(word[0]);
		
		if(word.length==1)childJson.setValue(value);
		else{
			pathStr=pathStr.replaceFirst(word[0]+SEP_STR,"");
			childJson.addPathChild(pathStr,value);
		}
	}
	
	public List<NJson> getChildList(){
		List<NJson> returnList=new ArrayList<NJson>();
		
		for(NJson childJson:childMap.values())returnList.add(childJson);
		
		return returnList;
	}
	
	public void indexAdd(NJson childJson){
		int maxInt=-1;
		for(String curKey:childMap.keySet()){
			int curInt=Integer.parseInt(curKey);
			if(curInt>maxInt)maxInt=curInt;
		}
		
		childMap.put(String.valueOf(maxInt+1),childJson);
	}
	
	public void indexAddList(List<NJson> srcList){
		for(int index=0;index<srcList.size();index++){
			put(String.valueOf(index),srcList.get(index));
		}
	}
	
	public String toPrettyJsonString(){
		return toPrettyJsonString(0);
	}
	
	private String toPrettyJsonString(int indent){
		StringBuilder sb=new StringBuilder();
		String ind="  ".repeat(indent);
		
		if(value!=null){
			sb.append("\"").append(escapeJson(value)).append("\"");
		}else{
			sb.append("{\n");
			Iterator<Map.Entry<String,NJson>> it=childMap.entrySet().iterator();
			while(it.hasNext()){
				Map.Entry<String,NJson> e=it.next();
				sb.append(ind).append("  ");
				sb.append("\"").append(escapeJson(e.getKey())).append("\":");
				sb.append(e.getValue().toPrettyJsonString(indent+1));
				if(it.hasNext())sb.append(",");
				sb.append("\n");
			}
			sb.append(ind).append("}");
		}
		
		return sb.toString();
	}
	
	private static String escapeJson(String s){
		if(s==null)return "";
		StringBuilder sb=new StringBuilder();
		for(char c:s.toCharArray()){
			switch(c){
				case '"':sb.append("\\\"");break;
				case '\\':sb.append("\\\\");break;
				case '\n':sb.append("\\n");break;
				case '\r':sb.append("\\r");break;
				case '\t':sb.append("\\t");break;
				default:
					if(c<0x20){
						sb.append(String.format("\\u%04x",(int)c));
					}else{
						sb.append(c);
					}
			}
		}
		return sb.toString();
	}
}
