import java.io.*;
import java.util.*;
import java.util.regex.*;

import java.nio.file.*;
import java.nio.charset.*;

import org.apache.poi.*;
import org.apache.poi.ss.formula.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.openxml4j.exceptions.*;
import org.apache.poi.xssf.usermodel.*;

public class MyCsv{
	//escap関連の実装が完璧ではない。accessメソッドを絞る必要がある。
	//→getContent,getRow,getHeaderをなくすしか無い。getSizeと指定indexの文字列returnメソッド実装。
	//→setContent,addRow,setHeaderなど後足しできないようにする
	//変換の時にunescapeする
	
	public static final String OUTPUT_COLNAME="出力名";
	public static final String COL_DEFNAME="col#";
	
	private ArrayList<String> header;
	private ArrayList<HashMap<String,String>> content;
	
	public MyCsv(){
		clear();
	}
	
	//↓↓↓getter,setter
	/*
	private ArrayList<String> getHeader(){ //ヘッダ取得。private
		return header;
	}
	*/
	
	public String getHeader(int index){	//指定位置のヘッダ取得
		return header.get(index);
	}
	
	public int getHeaderSize(){	//ヘッダサイズ取得
		return header.size();
	}
	
	public boolean containsHeader(String colName){	//ヘッダに指定値があるか
		return header.contains(colName);
	}
	
	public void addHeader(String colName){ //ヘッダ追加
		colName=escapeString(colName);
		if(header.contains(colName))return;
		header.add(colName);
	}
	
	public void removeHeader(String colName){ //指定ヘッダ削除
		header.remove(header.indexOf(colName));
		for(HashMap<String,String> curMap:content){
			if(curMap.containsKey(colName))curMap.remove(colName);
		}
	}
	
	public void setHeader(ArrayList<String> tmpHeader){ //ヘッダセット
		clear();
		for(int i=0;i<tmpHeader.size();i++)header.add(escapeString(tmpHeader.get(i)));
	}
	
	public String getValue(int index,String colName){ //値を取得
		if(index>content.size()-1)return null;
		if(!content.get(index).containsKey(colName))return null;
		
		return content.get(index).get(colName);
	}
	
	public boolean containsKey(int index,String colName){	//指定行にキーバリューがあるか
		return content.get(index).containsKey(colName);
	}
	
	public void setValue(int index,String colName,String value){ //指定の値をセット
		colName=escapeString(colName);
		value=escapeString(value);
		
		if(index>content.size()-1)return;
		addHeader(colName);
		
		content.get(index).put(colName,value);
	}
	
	public void setAllValue(String colName,String value){ //指定列の値をすべてセットする
		colName=escapeString(colName);
		value=escapeString(value);
		
		addHeader(colName);
		
		for(HashMap<String,String> curMap:content){
			curMap.put(colName,value);
		}
	}
	
	public void removeColValue(int index,String colName){ //指定値を削除
		if(index>content.size()-1)return;
		
		content.get(index).remove(colName);
	}
	
	public void replaceValue(String colName,String befStr,String aftStr){ //指定列の文字列をreplace
		aftStr=escapeString(aftStr);
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(colName))continue;
			
			curMap.put(colName,curMap.get(colName).replaceAll(befStr,aftStr));
		}
	}
	
	public void renameColName(String befCol,String aftCol){ //列名変更
		aftCol=escapeString(aftCol);
		
		int index=header.indexOf(befCol);
		header.set(index,aftCol);
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(befCol))continue;
			String tmpValue=curMap.get(befCol);
			curMap.remove(befCol);
			curMap.put(aftCol,tmpValue);
		}
	}
	
	public void setDefaultValue(String colName,String defaultValue){ //指定列のnull値にデフォルト値を入れる
		defaultValue=escapeString(defaultValue);
		
		for(HashMap<String,String> curMap:content){
			if(curMap.containsKey(colName))continue;
			
			curMap.put(colName,defaultValue);
		}
	}
	
	/*
	private HashMap<String,String> getRow(int index){ //行取得。private
		if(index>content.size()-1)return null;
		
		return content.get(index);
	}
	*/
	
	public Iterator<String> rowkeyIterator(int index){	//行のキーiteratorを返す
		if(index>content.size()-1)return null;
		
		return content.get(index).keySet().iterator();
	}
	
	public void addRow(HashMap<String,String> curMap){ //行追加
		HashMap<String,String> tmpMap=new HashMap<String,String>();
		
		for(String key:curMap.keySet()){
			String value=curMap.get(key);
			key=escapeString(key);
			value=escapeString(value);
			
			addHeader(key);
			tmpMap.put(key,value);
		}
		
		content.add(tmpMap);
	}
	
	/*
	private ArrayList<HashMap<String,String>> getContent(){ //content取得
		return content;
	}
	*/
	
	public int getContentSize(){ //contentサイズ取得
		return content.size();
	}
	
	public void setContent(ArrayList<HashMap<String,String>> curContent){ //contentセット
		clear();
		
		for(HashMap<String,String> curMap:curContent){
			HashMap<String,String> tmpMap=new HashMap<String,String>();
			content.add(tmpMap);
			for(String key:curMap.keySet()){
				String value=curMap.get(key);
				key=escapeString(key);
				value=escapeString(value);
				
				addHeader(key);
				tmpMap.put(key,value);
			}
		}
	}
	
	public void addContent(ArrayList<HashMap<String,String>> srcContent){ //content追加
		for(HashMap<String,String> curMap:srcContent){
			addRow(curMap);
		}
	}
	
	public void clear(){
		header=new ArrayList<String>();
		content=new ArrayList<HashMap<String,String>>();
	}
	
	//↓↓↓loader,saver,outputer
	public void loadDataCsv(ArrayList<String> rowStrList){ //カンマ区切りの文字列Listを読み込む。列名がない場合は自動生成。
		for(String curStr:rowStrList){
			String[] word=curStr.split(",");
			HashMap<String,String> curMap=new HashMap<String,String>();
			for(int i=0;i<word.length;i++){
				if(i>header.size()-1)header.add(i,COL_DEFNAME+i);
				if(word[i].length()>0)curMap.put(header.get(i),word[i]);
			}
			addRow(curMap);
		}
	}
	
	public void loadCsv(File srcFile) throws Exception{ //csvロード
		clear();
		
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(srcFile), "SHIFT-JIS"));
		String tmpStr=br.readLine();
		String[] word=tmpStr.split(",");
		setHeader(new ArrayList<String>(Arrays.asList(word)));
		
		String line;
		ArrayList<String> rowStrList=new ArrayList<String>();
		while ((line = br.readLine()) != null) {
			rowStrList.add(line);
		}
		br.close();
		
		loadDataCsv(rowStrList);
	}
	
	public void loadCsv(String srcPath) throws Exception{ //csvロード
		File tmpFile=new File(srcPath);
		loadCsv(tmpFile);
	}
	
	public void loadTabFile(File srcFile,boolean headerFlag) throws Exception{ //タブ区切りテキストロード
		clear();
		
		BufferedReader br = new BufferedReader(new FileReader(srcFile));
		if(headerFlag){
			String tmpStr=br.readLine();
			String[] word=tmpStr.split("\t");
			setHeader(new ArrayList<String>(Arrays.asList(word)));
		}
		
		String line;
		ArrayList<String> rowStrList=new ArrayList<String>();
		while ((line = br.readLine()) != null) {
			rowStrList.add(line.replaceAll("\t",","));
		}
		
		br.close();
		
		loadDataCsv(rowStrList);
	}
	
	public void loadTabFile(String srcPath,boolean headerFlag) throws Exception{ //タブ区切りテキストロード
		File tmpFile=new File(srcPath);
		loadTabFile(tmpFile,headerFlag);
	}
	
	public void loadExcel(File srcFile,String sheetName) throws Exception{ //excelロード
		clear();
		
		Workbook wb=null;
		Sheet sheet=null;
		wb=WorkbookFactory.create(new FileInputStream(srcFile));
		sheet=wb.getSheet(sheetName);
		for(int rowIndex=0;rowIndex<=sheet.getLastRowNum();rowIndex++){
			Row row=sheet.getRow(rowIndex);
			if(rowIndex==0 && row==null)break;
			if(row==null)continue;
			
			if(rowIndex==0 && row.getZeroHeight())break;
			if(row.getZeroHeight())continue;
			
			if(rowIndex==0){
				ArrayList<String> tmpList=new ArrayList<String>();
				for(int cellIndex=0;cellIndex<row.getLastCellNum();cellIndex++){
					Cell cell=row.getCell(cellIndex);
					String tmpStr=cell.getStringCellValue();
					tmpList.add(tmpStr);
				}
				setHeader(tmpList);
				continue;
			}
			
			HashMap<String,String> tmpMap=new HashMap<String,String>();
			for(int cellIndex=0;cellIndex<row.getLastCellNum();cellIndex++){
				Cell cell=row.getCell(cellIndex);
				if(cell==null)continue;
				String curCellStr=null;
				try{
					curCellStr=cell.getStringCellValue();
				}catch(IllegalStateException e){
					curCellStr=String.format("%.0f",cell.getNumericCellValue());
				}
				tmpMap.put(header.get(cellIndex),curCellStr);
			}
			addRow(tmpMap);
		}
		
		wb.close();
	}
	
	public void loadExcel(String srcPath,String sheetName) throws Exception{ //excelロード
		File tmpFile=new File(srcPath);
		loadExcel(tmpFile,sheetName);
	}
	
	public void loadMyJson(MyJson rootJson){	//MYJsonのロード
		ArrayList<String> pathList=new ArrayList<String>();
		recursiveLoadMyJson(pathList,rootJson);
		header.add("値");
	}
	
	private void recursiveLoadMyJson(ArrayList<String> pathList,MyJson curJson){
		if(curJson.isJson()){
			Iterator<String> it=curJson.childKeyIterator();
			while(it.hasNext()){
				String key=it.next();
				MyJson childJson=curJson.getChild(key);
				ArrayList<String> childPathList=(ArrayList<String>)pathList.clone();
				childPathList.add(key);
				recursiveLoadMyJson(childPathList,childJson);
			}
		}else{
			HashMap<String,String> curMap=new HashMap<String,String>();
			for(int i=0;i<pathList.size();i++){
				String colStr=COL_DEFNAME+i;
				if(!header.contains(colStr))header.add(colStr);
				curMap.put(colStr,pathList.get(i));
			}
			String tmpStr=curJson.getValue();
			curMap.put("値",tmpStr);
			addRow(curMap);
		}
	}
	
	public void saveCsv(String dstPath) throws Exception{ //csv保存
		PrintWriter wr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(dstPath),"Shift-JIS")));
		
		for(int i=0;i<header.size();i++){
			if(i==0)wr.print(header.get(i));
			else wr.print(","+header.get(i));
		}
		wr.println();
		
		for(HashMap<String,String> curRow:content){
			for(int i=0;i<header.size();i++){
				if(i==0){
					if(curRow.containsKey(header.get(i)))wr.print(curRow.get(header.get(i)));
				}else{
					if(curRow.containsKey(header.get(i)))wr.print(","+curRow.get(header.get(i)));
					else wr.print(",");
				}
			}
			wr.println();
		}
		
		wr.close();
	}
	
	public void outputGroupreplace(String templatePath,String dstDir) throws Exception{ //雛形を読み込み、<>括りの列名をその値に置換し、指定フォルダの出力名ファイルに出力する。
		List<String> lines=null;
		Path path=Paths.get(templatePath);
		lines=Files.readAllLines(path,StandardCharsets.UTF_8);
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(OUTPUT_COLNAME))continue;
			File curFile=new File(dstDir+"/"+curMap.get(OUTPUT_COLNAME));
			PrintWriter wr=null;
			if(curFile.exists())wr=new PrintWriter(new FileWriter(curFile,true));
			else wr=new PrintWriter(new FileWriter(curFile));
			
			for(String curStr:lines){
				for(String headerStr:header){
					if(curMap.containsKey(headerStr)){
						curStr=curStr.replace("<"+headerStr+">",curMap.get(headerStr));
						curStr=unescapeString(curStr);
					}else curStr=curStr.replace("<"+headerStr+">","");
				}
				wr.println(curStr);
			}
			
			wr.close();
		}
	}
	
	public void outputExcelReplace(String templatePath,String dstDir) throws Exception{	//雛形を読み込み、<>くくりの列名をその値に置換し、指定フォルダの出力名ファイルに出力する。Excel版。シートは最初のもの。スタイルコピーは未実施。
		Workbook templateWb=WorkbookFactory.create(new FileInputStream(templatePath));
		Sheet templateSheet=templateWb.getSheetAt(0);
		
		Workbook dstWb=null;
		Sheet dstSheet=null;
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(OUTPUT_COLNAME))continue;
			File curFile=new File(dstDir+"/"+curMap.get(OUTPUT_COLNAME));
			int dstRowIndex=0;
			if(curFile.exists()){
				dstWb=WorkbookFactory.create(new FileInputStream(curFile));
				dstSheet=dstWb.getSheetAt(0);
				dstRowIndex=dstSheet.getLastRowNum()+1;
				
			}else{
				dstWb=new XSSFWorkbook();
				dstSheet=dstWb.createSheet();
			}
			
			for(int rowIndex=0;rowIndex<=templateSheet.getLastRowNum();rowIndex++){
				Row row=templateSheet.getRow(rowIndex);
				Row dstRow=dstSheet.createRow(dstRowIndex++);
				if(row==null)continue;
				for(int cellIndex=0;cellIndex<row.getLastCellNum();cellIndex++){
					Cell cell=row.getCell(cellIndex);
					Cell dstCell=dstRow.createCell(cellIndex);
					if(cell==null)continue;
					if(cell.getCellType()==CellType.NUMERIC){
						dstCell.setCellValue(cell.getNumericCellValue());
						continue;
					}else if(cell.getCellType()!=CellType.STRING)continue;
					
					String curStr=cell.getStringCellValue();
					for(String headerStr:header){
						if(curMap.containsKey(headerStr)){
							curStr=curStr.replace("<"+headerStr+">",curMap.get(headerStr));
							curStr=unescapeString(curStr);
						}else curStr=curStr.replace("<"+headerStr+">","");
					}
					dstCell.setCellValue(curStr);
				}
			}
			
			//dstWbの出力
			FileOutputStream out=new FileOutputStream(dstDir+"/"+curMap.get(OUTPUT_COLNAME));
			dstWb.write(out);
			out.close();
			dstWb.close();
		}
		
		templateWb.close();
	}
	
	public MyJson getMyJson(String keyStr){	//keyStrの列を名前とするMyJson型に変換して返す
		MyJson returnJson=new MyJson();
		
		for(int i=0;i<getContentSize();i++){
			MyJson curParentJson=new MyJson();
			for(int j=0;j<header.size();j++){
				MyJson curChildJson=new MyJson();
				curChildJson.setValue(unescapeString(getValue(i,header.get(j))));
				curParentJson.put(header.get(j),curChildJson);
				
				if(header.get(j).equals(keyStr)){
					returnJson.put(unescapeString(getValue(i,header.get(j))),curParentJson);
				}
			}
		}
		
		return returnJson;
	}
	
	//↓↓↓transformer
	public ArrayList<String> getCol(String colName){ //指定列をListにして返す
		ArrayList<String> returnList=new ArrayList<String>();
		for(HashMap<String,String> curMap:content){
			if(curMap.containsKey(colName))returnList.add(curMap.get(colName));
			else returnList.add(null);
		}
		
		return returnList;
	}
	
	public HashMap<String,String> getMapping(String keyCol,String valueCol){ //key列とvalue列をMapにして返す
		HashMap<String,String> returnMap=new HashMap<String,String>();
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(keyCol))continue;
			if(!curMap.containsKey(valueCol))continue;
			if(returnMap.containsKey(curMap.get(keyCol)))continue;
			
			returnMap.put(curMap.get(keyCol),curMap.get(valueCol));
		}
		
		return returnMap;
	}
	
	public MyCsv mapMerge(String keyCol,String valueCol,HashMap<String,String> srcMap){ //key列の値にマッピングしてvalue列に値を追加する
		MyCsv returnCsv=new MyCsv();
		
		ArrayList<String> tmpHeader=new ArrayList<String>(header);
		tmpHeader.add(valueCol);
		returnCsv.setHeader(tmpHeader);
		
		for(HashMap<String,String> curMap:content){
			HashMap<String,String> tmpMap=new HashMap<String,String>(curMap);
			returnCsv.addRow(tmpMap);
			
			if(!tmpMap.containsKey(keyCol))continue;
			if(!srcMap.containsKey(tmpMap.get(keyCol)))continue;
			
			tmpMap.put(valueCol,srcMap.get(tmpMap.get(keyCol)));
		}
		
		return returnCsv;
	}
	
	public static MyCsv csvMerge(File rootDir) throws Exception{ //指定フォルダにあるcsvファイルを結合する
		MyCsv returnCsv=null;
		
		File[] fileList=rootDir.listFiles();
		for(File curFile:fileList){
			MyCsv curCsv=new MyCsv();
			curCsv.loadCsv(curFile);
			
			if(returnCsv==null)returnCsv=curCsv;
			else{
				for(int i=0;i<curCsv.getContentSize();i++){
					HashMap<String,String> curMap=new HashMap<String,String>();
					Iterator<String> it=curCsv.rowkeyIterator(i);
					while(it.hasNext()){
						String curKey=it.next();
						String curValue=curCsv.getValue(i,curKey);
						curMap.put(curKey,curValue);
					}
					returnCsv.addRow(curMap);
				}
			}
		}
		
		return returnCsv;
	}
	
	public MyCsv listReplace(String keyCol,String value,ArrayList<String> replaceList){ //指定列に指定値があった場合、List分だけ行を増やしながらvalueをList値に置換する
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(header));
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(keyCol))continue;
			
			if(curMap.get(keyCol).equals(value)){
				for(String curStr:replaceList){
					HashMap<String,String> tmpMap=new HashMap<String,String>(curMap);
					tmpMap.put(keyCol,curStr);
					returnCsv.addRow(tmpMap);
				}
			}else returnCsv.addRow(curMap);
		}
		
		return returnCsv;
	}
	
	/*
	public MyCsv sort(String keyCol,boolean ascendFlag){ //指定キーでソート
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(header));
		
		for(HashMap<String,String> curMap:content){
			returnCsv.addRow(curMap);
		}
		
		Collections.sort(returnCsv.getContent(), new Comparator<HashMap<String, String>>() {
			@Override
			public int compare(HashMap<String, String> map1, HashMap<String, String> map2) {
				String value1 = map1.get(keyCol);
				String value2 = map2.get(keyCol);
				if(ascendFlag)return value1.compareTo(value2);
				else return value2.compareTo(value1);
			}
		});
		
		return returnCsv;
	}
	*/
	
	//↓↓↓filter
	public MyCsv clone(){ //クローンを返す
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(header));
		
		for(HashMap<String,String> curMap:content){
			HashMap<String,String> tmpMap=new HashMap<String,String>(curMap);
			returnCsv.addRow(tmpMap);
		}
		
		return returnCsv;
	}
	
	public MyCsv equalFilter(String keyCol,String checkStr,boolean matchFlag){ //同値確認
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(header));
		
		for(HashMap<String,String> curMap:content){
			if(matchFlag){
				if(!curMap.containsKey(keyCol)){
					if(checkStr==null)returnCsv.addRow(curMap);
					continue;
				}
				
				if(checkStr==null)continue;
				if(checkStr.equals(curMap.get(keyCol)))returnCsv.addRow(curMap);
			}else{
				if(!curMap.containsKey(keyCol)){
					if(checkStr!=null)returnCsv.addRow(curMap);
					continue;
				}
				
				if(checkStr==null){
					returnCsv.addRow(curMap);
					continue;
				}
				if(!checkStr.equals(curMap.get(keyCol)))returnCsv.addRow(curMap);
			}
		}
		
		return returnCsv;
	}
	
	public MyCsv reFilter(String keyCol,String reStr,boolean matchFlag){ //引数の正規表現を含むか確認
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(header));
		
		for(HashMap<String,String> curMap:content){
			if(matchFlag){
				if(!curMap.containsKey(keyCol)){
					if(reStr==null)returnCsv.addRow(curMap);
					continue;
				}
				if(reStr==null)continue;
				
				Pattern p=Pattern.compile(reStr);
				Matcher m=p.matcher(curMap.get(keyCol));
				if(m.find())returnCsv.addRow(curMap);
			}else{
				if(!curMap.containsKey(keyCol)){
					if(reStr!=null)returnCsv.addRow(curMap);
					continue;
				}
				if(reStr==null){
					returnCsv.addRow(curMap);
					continue;
				}
				
				Pattern p=Pattern.compile(reStr);
				Matcher m=p.matcher(curMap.get(keyCol));
				if(!m.find())returnCsv.addRow(curMap);
			}
		}
		
		return returnCsv;
	}
	
	public MyCsv containsIpFilter(String keyCol,String checkedStr,boolean matchFlag) throws Exception{ //引数のIPが範囲内に含まれるか確認
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(header));
		
		for(HashMap<String,String> curMap:content){
			if(matchFlag){
				if(!curMap.containsKey(keyCol)){
					if(checkedStr==null)returnCsv.addRow(curMap);
					continue;
				}
				if(!Address.isLegalIP(curMap.get(keyCol)))continue;
				if(checkedStr==null)continue;
				
				Address checkedAddr=new Address(checkedStr);
				Address checkAddr=new Address(curMap.get(keyCol));
				if(checkAddr.containsAddress(checkedAddr))returnCsv.addRow(curMap);
				
			}else{
				if(!curMap.containsKey(keyCol)){
					if(checkedStr!=null)returnCsv.addRow(curMap);
					continue;
				}
				if(!Address.isLegalIP(curMap.get(keyCol))){
					returnCsv.addRow(curMap);
					continue;
				}
				if(checkedStr==null){
					returnCsv.addRow(curMap);
					continue;
				}
				
				Address checkedAddr=new Address(checkedStr);
				Address checkAddr=new Address(curMap.get(keyCol));
				if(!checkAddr.containsAddress(checkedAddr))returnCsv.addRow(curMap);
				
			}
		}
		
		return returnCsv;
	}
	
	public MyCsv containedIpFilter(String keyCol,String checkStr,boolean matchFlag) throws Exception{ //引数範囲のセグメントに含まれるか確認
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(header));
		
		for(HashMap<String,String> curMap:content){
			if(matchFlag){
				if(!curMap.containsKey(keyCol)){
					if(checkStr==null)returnCsv.addRow(curMap);
					continue;
				}
				if(!Address.isLegalIP(curMap.get(keyCol)))continue;
				if(checkStr==null)continue;
				
				Address checkedAddr=new Address(curMap.get(keyCol));
				Address checkAddr=new Address(checkStr);
				if(checkAddr.containsAddress(checkedAddr))returnCsv.addRow(curMap);
				
			}else{
				if(!curMap.containsKey(keyCol)){
					if(checkStr!=null)returnCsv.addRow(curMap);
					continue;
				}
				if(!Address.isLegalIP(curMap.get(keyCol))){
					returnCsv.addRow(curMap);
					continue;
				}
				if(checkStr==null){
					returnCsv.addRow(curMap);
					continue;
				}
				
				Address checkedAddr=new Address(curMap.get(keyCol));
				Address checkAddr=new Address(checkStr);
				if(!checkAddr.containsAddress(checkedAddr))returnCsv.addRow(curMap);
				
			}
		}
		
		return returnCsv;
	}
	
	public MyCsv nullBlankFilter(String colName){ //値なしを除外
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(header));
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(colName))continue;
			if(curMap.get(colName).length()==0)continue;
			
			returnCsv.addRow(curMap);
		}
		
		return returnCsv;
	}
	
	public MyCsv doubleCompareFilter(String keyCol,String checkStr,boolean upDownFlag){ //引数との数値大小を比較してフィルタ。フラグtrueが引数より大きい場合マッチ。
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(header));
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(keyCol)){
				if(checkStr==null)returnCsv.addRow(curMap);
				continue;
			}
			if(checkStr==null)continue;
			
			double checkedDouble=Double.parseDouble(curMap.get(keyCol));
			double checkDouble=Double.parseDouble(checkStr);
			if(upDownFlag && checkedDouble>=checkDouble)returnCsv.addRow(curMap);
			else if(!upDownFlag && checkedDouble<=checkDouble)returnCsv.addRow(curMap);
			
		}
		
		return returnCsv;
	}
	
	public MyCsv doubleRangeFilter(String keyCol,String befStr,String aftStr,boolean matchFlag){ //引数の範囲内か判定してフィルタ。フラグtrueが範囲内。
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(header));
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(keyCol)){
				if(!matchFlag)returnCsv.addRow(curMap);
				continue;
			}
			
			double checkedDouble=Double.parseDouble(curMap.get(keyCol));
			double befDouble=Double.parseDouble(befStr);
			double aftDouble=Double.parseDouble(aftStr);
			if(matchFlag && checkedDouble>=befDouble && checkedDouble<=aftDouble)returnCsv.addRow(curMap);
			else if(!matchFlag && checkedDouble<befDouble && checkedDouble>aftDouble)returnCsv.addRow(curMap);
			
		}
		
		return returnCsv;
	}
	
	public MyCsv intCompareFilter(String keyCol,String checkedStr){ //引数数値(int)を比較判定してフィルタする。※valueが無いときはオールマイティ扱い。
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(header));
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(keyCol)){
				if(checkedStr==null)returnCsv.addRow(curMap);
				continue;
			}
			if(checkedStr==null)continue;
			
			String tmpCheckStr=curMap.get(keyCol);
			if(tmpCheckStr.matches("\\d+")){	//数値 123
				int checkInt=Integer.parseInt(tmpCheckStr);
				int checkedInt=Integer.parseInt(checkedStr);
				if(checkedInt==checkInt)returnCsv.addRow(curMap);
				
			}else if(tmpCheckStr.matches("\\d+ \\d+")){	//範囲 123 456
				String[] word=tmpCheckStr.split(" ");
				int befInt=Integer.parseInt(word[0]);
				int aftInt=Integer.parseInt(word[1]);
				int checkedInt=Integer.parseInt(checkedStr);
				
				if(checkedInt>=befInt && checkedInt<=aftInt)returnCsv.addRow(curMap);
				
			}else if(tmpCheckStr.matches("\\d+<")){	//大小 123<
				tmpCheckStr=tmpCheckStr.replace("<","");
				int checkInt=Integer.parseInt(tmpCheckStr);
				int checkedInt=Integer.parseInt(checkedStr);
				
				if(checkedInt>checkedInt)returnCsv.addRow(curMap);
				
			}else if(tmpCheckStr.matches("\\d+<=")){	//大小 123<=
				tmpCheckStr=tmpCheckStr.replace("<=","");
				int checkInt=Integer.parseInt(tmpCheckStr);
				int checkedInt=Integer.parseInt(checkedStr);
				
				if(checkedInt>=checkedInt)returnCsv.addRow(curMap);
				
			}else if(tmpCheckStr.matches("\\d+>")){	//大小 123>
				tmpCheckStr=tmpCheckStr.replace(">","");
				int checkInt=Integer.parseInt(tmpCheckStr);
				int checkedInt=Integer.parseInt(checkedStr);
				
				if(checkedInt<checkedInt)returnCsv.addRow(curMap);
				
			}else if(tmpCheckStr.matches("\\d+>=")){	//大小 123>=
				tmpCheckStr=tmpCheckStr.replace(">=","");
				int checkInt=Integer.parseInt(tmpCheckStr);
				int checkedInt=Integer.parseInt(checkedStr);
				
				if(checkedInt<=checkedInt)returnCsv.addRow(curMap);
				
			}else{
				
			}
		}
		
		return returnCsv;
	}
	
	//↓↓↓utility
	private String escapeString(String input) {
		if (input == null) {
			return null;
		}
		return input.replace("\\", "<y>")
					.replace("\"", "<d>")
					.replace(",", "<c>")
					.replace("\n", "<n>")
					.replace("\r", "<r>")
					.replace("\t", "<t>");
	}
	
	private String unescapeString(String input) {
		if (input == null) {
			return null;
		}
		return input.replace("<y>", "\"")
					.replace("<d>", "\\")
					.replace("<c>", ",")
					.replace("<n>", "\n")
					.replace("<r>", "\r")
					.replace("<t>", "\t");
	}
	
	public void showAll(){ //内容表示
		for(String curStr:header){
			System.out.print(curStr+",");
		}
		
		System.out.println();
		for(HashMap<String,String> curMap:content){
			for(String curStr:header){
				System.out.print(curMap.get(curStr)+",");
			}
			System.out.println();
		}
	}
	
	public static void deleteFileInFolder(String dirPath) throws Exception{ //指定フォルダのファイルを全削除。サブフォルダは再帰検索しない。
		File rootDir=new File(dirPath);
		File[] fileList=rootDir.listFiles();
		for(File curFile:fileList)curFile.delete();
	}
}
