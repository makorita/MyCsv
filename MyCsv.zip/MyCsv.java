import java.io.*;
import java.util.*;
import java.util.regex.*;

import java.nio.file.*;
import java.nio.charset.*;

import org.apache.poi.*;
import org.apache.poi.ss.formula.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.openxml4j.exceptions.*;
import org.apache.poi.xssf.usermodel.*;

public class MyCsv{
	public static final String OUTPUT_COLNAME="出力名";
	public static final String COL_DEFNAME="col#";
	
	private ArrayList<String> header;
	private ArrayList<HashMap<String,String>> content;
	
	public MyCsv(){
		header=new ArrayList<String>();
		content=new ArrayList<HashMap<String,String>>();
	}
	
	//↓↓↓getter,setter
	public ArrayList<String> getHeader(){ //ヘッダ取得
		return header;
	}
	
	public void setHeader(ArrayList<String> header){ //ヘッダセット
		this.header=header;
	}
	
	public void addHeader(String colName){ //ヘッダ追加
		header.add(colName);
	}
	
	public void removeHeader(String colName){ //指定ヘッダ削除
		header.remove(header.indexOf(colName));
	}
	
	public ArrayList<HashMap<String,String>> getContent(){ //content取得
		return content;
	}
	
	public int getContentSize(){ //contentサイズ取得
		return content.size();
	}
	
	public void setContent(ArrayList<HashMap<String,String>> content){ //contentセット
		this.content=content;
	}
	
	public void addContent(ArrayList<HashMap<String,String>> srcContent){ //content追加
		for(HashMap<String,String> curMap:srcContent){
			content.add(curMap);
		}
	}
	
	public HashMap<String,String> getRow(int index){ //行取得
		if(content.size()<=index)return null;
		
		return content.get(index);
	}
	
	public void addRow(HashMap<String,String> curRow){ //行追加
		content.add(curRow);
	}
	
	public String getValue(int rowIndex,String colName){ //値を取得
		if(rowIndex>content.size()-1)return null;
		if(!content.get(rowIndex).containsKey(colName))return null;
		
		return content.get(rowIndex).get(colName);
	}
	
	public boolean containsKey(int index,String colName){
		return content.get(index).containsKey(colName);
	}
	
	public void setValue(int rowIndex,String colName,String value){ //指定の値をセット
		if(rowIndex>content.size()-1)return;
		if(!header.contains(colName))header.add(colName);
		
		content.get(rowIndex).put(colName,value);
	}
	
	public void setAllValue(String colName,String value){ //指定列の値をすべてセットする
		if(!header.contains(colName))header.add(colName);
		
		for(HashMap<String,String> curMap:content){
			curMap.put(colName,value);
		}
	}
	
	public void removeColValue(int rowIndex,String colName){ //指定値を削除
		if(rowIndex>content.size()-1)return;
		
		content.get(rowIndex).remove(colName);
	}
	
	public void replaceValue(String colName,String befStr,String aftStr){ //指定列の文字列をreplace
		for(HashMap<String,String> curMap:content){
			if(curMap.get(colName)==null)continue;
			curMap.put(colName,curMap.get(colName).replaceAll(befStr,aftStr));
		}
	}
	
	public void renameColName(String befCol,String aftCol){ //列名変更
		int index=header.indexOf(befCol);
		header.set(index,aftCol);
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(befCol))continue;
			String tmpValue=curMap.get(befCol);
			curMap.remove(befCol);
			curMap.put(aftCol,tmpValue);
		}
	}
	
	public void setDefaultValue(String colName,String defaultValue){ //指定列のnull値にデフォルト値を入れる
		for(HashMap<String,String> curMap:content){
			if(curMap.containsKey(colName))continue;
			
			curMap.put(colName,defaultValue);
		}
	}
	
	//↓↓↓loader,saver,outputer
	public void loadDataCsv(ArrayList<String> rowStrList){ //カンマ区切りの文字列Listを読み込む。列名がない場合は自動生成。
		for(String curStr:rowStrList){
			String[] word=curStr.split(",");
			HashMap<String,String> curMap=new HashMap<String,String>();
			content.add(curMap);
			for(int i=0;i<word.length;i++){
				if(i>header.size()-1)header.add(i,COL_DEFNAME+i);
				if(word[i].length()>0)curMap.put(header.get(i),word[i]);
			}
		}
	}
	
	public void loadCsv(File srcFile) throws Exception{ //csvロード
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(srcFile), "SHIFT-JIS"));
		String tmpStr=br.readLine();
		String[] word=tmpStr.split(",");
		setHeader(new ArrayList<String>(Arrays.asList(word)));
		
		String line;
		ArrayList<String> rowStrList=new ArrayList<String>();
		while ((line = br.readLine()) != null) {
			rowStrList.add(line);
		}
		br.close();
		
		loadDataCsv(rowStrList);
	}
	
	public void loadCsv(String srcPath) throws Exception{ //csvロード
		File tmpFile=new File(srcPath);
		loadCsv(tmpFile);
	}
	
	public void loadTabFile(File srcFile,boolean headerFlag) throws Exception{ //タブ区切りテキストロード
		BufferedReader br = new BufferedReader(new FileReader(srcFile));
		if(headerFlag){
			String tmpStr=br.readLine();
			String[] word=tmpStr.split("\t");
			setHeader(new ArrayList<String>(Arrays.asList(word)));
		}
		
		String line;
		ArrayList<String> rowStrList=new ArrayList<String>();
		while ((line = br.readLine()) != null) {
			rowStrList.add(line.replaceAll("\t",","));
		}
		
		br.close();
		
		loadDataCsv(rowStrList);
	}
	
	public void loadTabFile(String srcPath,boolean headerFlag) throws Exception{ //タブ区切りテキストロード
		File tmpFile=new File(srcPath);
		loadTabFile(tmpFile,headerFlag);
	}
	
	public void loadExcel(File srcFile,String sheetName) throws Exception{ //excelロード
		Workbook wb=null;
		Sheet sheet=null;
		wb=WorkbookFactory.create(new FileInputStream(srcFile));
		sheet=wb.getSheet(sheetName);
		for(int rowIndex=0;rowIndex<=sheet.getLastRowNum();rowIndex++){
			Row row=sheet.getRow(rowIndex);
			if(rowIndex==0 && row==null)break;
			if(row==null)continue;
			
			if(rowIndex==0 && row.getZeroHeight())break;
			if(row.getZeroHeight())continue;
			
			if(rowIndex==0){
				ArrayList<String> tmpList=new ArrayList<String>();
				for(int cellIndex=0;cellIndex<row.getLastCellNum();cellIndex++){
					Cell cell=row.getCell(cellIndex);
					String tmpStr=cell.getStringCellValue();
					tmpList.add(tmpStr);
				}
				setHeader(tmpList);
				continue;
			}
			
			HashMap<String,String> tmpMap=new HashMap<String,String>();
			addRow(tmpMap);
			for(int cellIndex=0;cellIndex<row.getLastCellNum();cellIndex++){
				Cell cell=row.getCell(cellIndex);
				if(cell==null)continue;
				String curCellStr=null;
				try{
					curCellStr=cell.getStringCellValue();
				}catch(IllegalStateException e){
					curCellStr=String.format("%.0f",cell.getNumericCellValue());
				}
				tmpMap.put(getHeader().get(cellIndex),curCellStr);
			}
		}
		
		wb.close();
	}
	
	public void loadExcel(String srcPath,String sheetName) throws Exception{ //excelロード
		File tmpFile=new File(srcPath);
		loadExcel(tmpFile,sheetName);
	}
	
	public void saveCsv(String dstPath) throws Exception{ //csv保存
		PrintWriter wr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(dstPath),"Shift-JIS")));
		
		for(int i=0;i<header.size();i++){
			if(i==0)wr.print(header.get(i));
			else wr.print(","+header.get(i));
		}
		wr.println();
		
		for(HashMap<String,String> curRow:content){
			for(int i=0;i<header.size();i++){
				if(i==0){
					if(curRow.containsKey(header.get(i)))wr.print(curRow.get(header.get(i)));
				}else{
					if(curRow.containsKey(header.get(i)))wr.print(","+curRow.get(header.get(i)));
					else wr.print(",");
				}
			}
			wr.println();
		}
		
		wr.close();
	}
	
	public void outputGroupreplace(String templatePath,String dstDir) throws Exception{ //雛形を読み込み、<>括りの列名をその値に置換し、指定フォルダの出力名ファイルに出力する。
		List<String> lines=null;
		Path path=Paths.get(templatePath);
		lines=Files.readAllLines(path,StandardCharsets.UTF_8);
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(OUTPUT_COLNAME))continue;
			File curFile=new File(dstDir+"/"+curMap.get(OUTPUT_COLNAME));
			PrintWriter wr=null;
			if(curFile.exists())wr=new PrintWriter(new FileWriter(curFile,true));
			else wr=new PrintWriter(new FileWriter(curFile));
			
			for(String curStr:lines){
				for(String headerStr:header){
					if(curMap.containsKey(headerStr)){
						curStr=curStr.replace("<"+headerStr+">",curMap.get(headerStr));
						curStr=curStr.replace("<c>",",");
					}else curStr=curStr.replace("<"+headerStr+">","");
				}
				wr.println(curStr);
			}
			
			wr.close();
		}
	}
	
	//↓↓↓transformer
	public ArrayList<String> getCol(String colName){ //指定列をListにして返す
		ArrayList<String> returnList=new ArrayList<String>();
		for(HashMap<String,String> curMap:content){
			if(curMap.containsKey(colName))returnList.add(curMap.get(colName));
			else returnList.add(null);
		}
		
		return returnList;
	}
	
	public HashMap<String,String> getMapping(String keyCol,String valueCol){ //key列とvalue列をMapにして返す
		HashMap<String,String> returnMap=new HashMap<String,String>();
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(keyCol))continue;
			if(!curMap.containsKey(valueCol))continue;
			if(returnMap.containsKey(curMap.get(keyCol)))continue;
			
			returnMap.put(curMap.get(keyCol),curMap.get(valueCol));
		}
		
		return returnMap;
	}
	
	public MyCsv mapMerge(String keyCol,String valueCol,HashMap<String,String> srcMap){ //key列の値にマッピングしてvalue列に値を追加する
		MyCsv returnCsv=new MyCsv();
		
		ArrayList<String> tmpHeader=new ArrayList<String>(getHeader());
		tmpHeader.add(valueCol);
		returnCsv.setHeader(tmpHeader);
		
		for(HashMap<String,String> curMap:content){
			HashMap<String,String> tmpMap=new HashMap<String,String>(curMap);
			returnCsv.addRow(tmpMap);
			
			if(!tmpMap.containsKey(keyCol))continue;
			if(!srcMap.containsKey(tmpMap.get(keyCol)))continue;
			
			tmpMap.put(valueCol,srcMap.get(tmpMap.get(keyCol)));
		}
		
		return returnCsv;
	}
	
	public static MyCsv csvMerge(File rootDir) throws Exception{ //指定フォルダにあるcsvファイルを結合する
		MyCsv returnCsv=null;
		
		File[] fileList=rootDir.listFiles();
		for(File curFile:fileList){
			MyCsv curCsv=new MyCsv();
			curCsv.loadCsv(curFile);
			
			if(returnCsv==null)returnCsv=curCsv;
			else{
				returnCsv.addContent(curCsv.getContent());
			}
		}
		
		return returnCsv;
	}
	
	public MyCsv listReplace(String keyCol,String value,ArrayList<String> replaceList){ //指定列に指定値があった場合、List分だけ行を増やしながらvalueをList値に置換する
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(getHeader()));
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(keyCol))continue;
			
			if(curMap.get(keyCol).equals(value)){
				for(String curStr:replaceList){
					HashMap<String,String> tmpMap=new HashMap<String,String>(curMap);
					tmpMap.put(keyCol,curStr);
					returnCsv.addRow(tmpMap);
				}
			}else returnCsv.addRow(curMap);
		}
		
		return returnCsv;
	}
	
	public MyCsv sort(String keyCol,boolean ascendFlag){ //指定キーでソート
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(getHeader()));
		
		for(HashMap<String,String> curMap:content){
			returnCsv.addRow(curMap);
		}
		
		Collections.sort(returnCsv.getContent(), new Comparator<HashMap<String, String>>() {
			@Override
			public int compare(HashMap<String, String> map1, HashMap<String, String> map2) {
				String value1 = map1.get(keyCol);
				String value2 = map2.get(keyCol);
				if(ascendFlag)return value1.compareTo(value2);
				else return value2.compareTo(value1);
			}
		});
		
		return returnCsv;
	}
	
	//↓↓↓filter
	public MyCsv clone(){ //クローンを返す
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(getHeader()));
		
		for(HashMap<String,String> curMap:content){
			HashMap<String,String> tmpMap=new HashMap<String,String>(curMap);
			returnCsv.addRow(tmpMap);
		}
		
		return returnCsv;
	}
	
	public MyCsv equalFilter(String keyCol,String checkStr,boolean matchFlag){ //同値確認
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(getHeader()));
		
		for(HashMap<String,String> curMap:content){
			if(matchFlag){
				if(!curMap.containsKey(keyCol)){
					if(checkStr==null)returnCsv.addRow(curMap);
					continue;
				}
				
				if(checkStr==null)continue;
				if(checkStr.equals(curMap.get(keyCol)))returnCsv.addRow(curMap);
			}else{
				if(!curMap.containsKey(keyCol)){
					if(checkStr!=null)returnCsv.addRow(curMap);
					continue;
				}
				
				if(checkStr==null){
					returnCsv.addRow(curMap);
					continue;
				}
				if(!checkStr.equals(curMap.get(keyCol)))returnCsv.addRow(curMap);
			}
		}
		
		return returnCsv;
	}
	
	public MyCsv reFilter(String keyCol,String reStr,boolean matchFlag){ //引数の正規表現を含むか確認
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(getHeader()));
		
		for(HashMap<String,String> curMap:content){
			if(matchFlag){
				if(!curMap.containsKey(keyCol)){
					if(reStr==null)returnCsv.addRow(curMap);
					continue;
				}
				if(reStr==null)continue;
				
				Pattern p=Pattern.compile(reStr);
				Matcher m=p.matcher(curMap.get(keyCol));
				if(m.find())returnCsv.addRow(curMap);
			}else{
				if(!curMap.containsKey(keyCol)){
					if(reStr!=null)returnCsv.addRow(curMap);
					continue;
				}
				if(reStr==null){
					returnCsv.addRow(curMap);
					continue;
				}
				
				Pattern p=Pattern.compile(reStr);
				Matcher m=p.matcher(curMap.get(keyCol));
				if(!m.find())returnCsv.addRow(curMap);
			}
		}
		
		return returnCsv;
	}
	
	public MyCsv containsIpFilter(String keyCol,String checkedStr,boolean matchFlag) throws Exception{ //引数のIPが範囲内に含まれるか確認
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(getHeader()));
		
		for(HashMap<String,String> curMap:content){
			if(matchFlag){
				if(!curMap.containsKey(keyCol)){
					if(checkedStr==null)returnCsv.addRow(curMap);
					continue;
				}
				if(!Address.isLegalIP(curMap.get(keyCol)))continue;
				if(checkedStr==null)continue;
				
				Address checkedAddr=new Address(checkedStr);
				Address checkAddr=new Address(curMap.get(keyCol));
				if(checkAddr.containsAddress(checkedAddr))returnCsv.addRow(curMap);
				
			}else{
				if(!curMap.containsKey(keyCol)){
					if(checkedStr!=null)returnCsv.addRow(curMap);
					continue;
				}
				if(!Address.isLegalIP(curMap.get(keyCol))){
					returnCsv.addRow(curMap);
					continue;
				}
				if(checkedStr==null){
					returnCsv.addRow(curMap);
					continue;
				}
				
				Address checkedAddr=new Address(checkedStr);
				Address checkAddr=new Address(curMap.get(keyCol));
				if(!checkAddr.containsAddress(checkedAddr))returnCsv.addRow(curMap);
				
			}
		}
		
		return returnCsv;
	}
	
	public MyCsv containedIpFilter(String keyCol,String checkStr,boolean matchFlag) throws Exception{ //引数範囲のセグメントに含まれるか確認
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(getHeader()));
		
		for(HashMap<String,String> curMap:content){
			if(matchFlag){
				if(!curMap.containsKey(keyCol)){
					if(checkStr==null)returnCsv.addRow(curMap);
					continue;
				}
				if(!Address.isLegalIP(curMap.get(keyCol)))continue;
				if(checkStr==null)continue;
				
				Address checkedAddr=new Address(curMap.get(keyCol));
				Address checkAddr=new Address(checkStr);
				if(checkAddr.containsAddress(checkedAddr))returnCsv.addRow(curMap);
				
			}else{
				if(!curMap.containsKey(keyCol)){
					if(checkStr!=null)returnCsv.addRow(curMap);
					continue;
				}
				if(!Address.isLegalIP(curMap.get(keyCol))){
					returnCsv.addRow(curMap);
					continue;
				}
				if(checkStr==null){
					returnCsv.addRow(curMap);
					continue;
				}
				
				Address checkedAddr=new Address(curMap.get(keyCol));
				Address checkAddr=new Address(checkStr);
				if(!checkAddr.containsAddress(checkedAddr))returnCsv.addRow(curMap);
				
			}
		}
		
		return returnCsv;
	}
	
	public MyCsv nullBlankFilter(String colName){ //値なしを除外
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(getHeader()));
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(colName))continue;
			if(curMap.get(colName).length()==0)continue;
			
			returnCsv.addRow(curMap);
		}
		
		return returnCsv;
	}
	
	public MyCsv doubleCompareFilter(String keyCol,String checkStr,boolean upDownFlag){ //引数との数値大小を比較してフィルタ。フラグtrueが引数より大きい場合マッチ。
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(getHeader()));
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(keyCol)){
				if(checkStr==null)returnCsv.addRow(curMap);
				continue;
			}
			if(checkStr==null)continue;
			
			double checkedDouble=Double.parseDouble(curMap.get(keyCol));
			double checkDouble=Double.parseDouble(checkStr);
			if(upDownFlag && checkedDouble>=checkDouble)returnCsv.addRow(curMap);
			else if(!upDownFlag && checkedDouble<=checkDouble)returnCsv.addRow(curMap);
			
		}
		
		return returnCsv;
	}
	
	public MyCsv doubleRangeFilter(String keyCol,String befStr,String aftStr,boolean matchFlag){ //引数の範囲内か判定してフィルタ。フラグtrueが範囲内。
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(getHeader()));
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(keyCol)){
				if(!matchFlag)returnCsv.addRow(curMap);
				continue;
			}
			
			double checkedDouble=Double.parseDouble(curMap.get(keyCol));
			double befDouble=Double.parseDouble(befStr);
			double aftDouble=Double.parseDouble(aftStr);
			if(matchFlag && checkedDouble>=befDouble && checkedDouble<=aftDouble)returnCsv.addRow(curMap);
			else if(!matchFlag && checkedDouble<befDouble && checkedDouble>aftDouble)returnCsv.addRow(curMap);
			
		}
		
		return returnCsv;
	}
	
	public MyCsv intCompareFilter(String keyCol,String checkedStr){ //引数数値(int)を比較判定してフィルタする。※valueが無いときはオールマイティ扱い。
		MyCsv returnCsv=new MyCsv();
		returnCsv.setHeader(new ArrayList<String>(getHeader()));
		
		for(HashMap<String,String> curMap:content){
			if(!curMap.containsKey(keyCol)){
				if(checkedStr==null)returnCsv.addRow(curMap);
				continue;
			}
			if(checkedStr==null)continue;
			
			String tmpCheckStr=curMap.get(keyCol);
			if(tmpCheckStr.matches("\\d+")){	//数値 123
				int checkInt=Integer.parseInt(tmpCheckStr);
				int checkedInt=Integer.parseInt(checkedStr);
				if(checkedInt==checkInt)returnCsv.addRow(curMap);
				
			}else if(tmpCheckStr.matches("\\d+ \\d+")){	//範囲 123 456
				String[] word=tmpCheckStr.split(" ");
				int befInt=Integer.parseInt(word[0]);
				int aftInt=Integer.parseInt(word[1]);
				int checkedInt=Integer.parseInt(checkedStr);
				
				if(checkedInt>=befInt && checkedInt<=aftInt)returnCsv.addRow(curMap);
				
			}else if(tmpCheckStr.matches("\\d+<")){	//大小 123<
				tmpCheckStr=tmpCheckStr.replace("<","");
				int checkInt=Integer.parseInt(tmpCheckStr);
				int checkedInt=Integer.parseInt(checkedStr);
				
				if(checkedInt>checkedInt)returnCsv.addRow(curMap);
				
			}else if(tmpCheckStr.matches("\\d+<=")){	//大小 123<=
				tmpCheckStr=tmpCheckStr.replace("<=","");
				int checkInt=Integer.parseInt(tmpCheckStr);
				int checkedInt=Integer.parseInt(checkedStr);
				
				if(checkedInt>=checkedInt)returnCsv.addRow(curMap);
				
			}else if(tmpCheckStr.matches("\\d+>")){	//大小 123>
				tmpCheckStr=tmpCheckStr.replace(">","");
				int checkInt=Integer.parseInt(tmpCheckStr);
				int checkedInt=Integer.parseInt(checkedStr);
				
				if(checkedInt<checkedInt)returnCsv.addRow(curMap);
				
			}else if(tmpCheckStr.matches("\\d+>=")){	//大小 123>=
				tmpCheckStr=tmpCheckStr.replace(">=","");
				int checkInt=Integer.parseInt(tmpCheckStr);
				int checkedInt=Integer.parseInt(checkedStr);
				
				if(checkedInt<=checkedInt)returnCsv.addRow(curMap);
				
			}else{	//想定外はmatch判定
				returnCsv.addRow(curMap);
			}
		}
		
		return returnCsv;
	}
	
	//↓↓↓utility
	public void showAll(){ //内容表示
		for(String curStr:header){
			System.out.print(curStr+",");
		}
		
		System.out.println();
		for(HashMap<String,String> curMap:content){
			for(String curStr:header){
				System.out.print(curMap.get(curStr)+",");
			}
			System.out.println();
		}
	}
	
	public static void deleteFileInFolder(String dirPath) throws Exception{ //指定フォルダのファイルを全削除。サブフォルダは再帰検索しない。
		File rootDir=new File(dirPath);
		File[] fileList=rootDir.listFiles();
		for(File curFile:fileList)curFile.delete();
	}
}
