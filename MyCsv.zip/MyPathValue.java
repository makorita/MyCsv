import java.util.*;
import java.io.*;
import java.nio.file.*;
import java.util.regex.*;

public class MyPathValue implements Serializable{
	private static final long serialVersionUID=1L;
	
	static final String SEP_STR="#SEP#";
	
	LinkedHashMap<String,String> pathValueMap;
	
	public MyPathValue(){
		pathValueMap=new LinkedHashMap<String,String>();
	}
	
	public String getValue(String pathStr){
		return pathValueMap.get(pathStr);
	}
	
	public String getValue(ArrayList<String> pathList){
		String pathStr=getPathStr(pathList);
		
		return getValue(pathStr);
	}
	
	public void put(String pathStr,String value){
		pathValueMap.put(pathStr,value);
	}
	
	public void put(ArrayList<String> pathList,String value){
		String pathStr=getPathStr(pathList);
		
		put(pathStr,value);
	}
	
	/*
	private String escapeJsonString(String input) {
		if (input == null) {
			return null;
		}
		
		input=input.replace("\n","<n>");
		
		return input;
	}
	*/
	
	//↓↓↓Exchange
	public MyJson getMyJson(){	//MyJsonに変換
		MyJson returnJson=new MyJson();
		
		for(String pathStr:pathValueMap.keySet()){
			MyJson tmpJson=returnJson.pathGet(pathStr);
			tmpJson.setValue(pathValueMap.get(pathStr));
		}
		
		return returnJson;
	}
	
	public MyCsv getMyCsv(){	//回し階層無しのMyCsv変換
		MyCsv returnCsv=new MyCsv();
		
		HashMap<String,String> curMap=new HashMap<String,String>();
		for(String pathStr:pathValueMap.keySet()){
			curMap.put(getKeyStr(pathStr),pathValueMap.get(pathStr));
		}
		returnCsv.addRow(curMap);
		
		return returnCsv;
	}
	
	public MyCsv getMyCsv(int[] levelList){	//levelintで指定された階層で回して、最終キーを列にしてvalueを値にして行追加する形でcsvに変換
		MyCsv returnCsv=new MyCsv();
		
		//指定列のキーセット取得
		LinkedHashSet<String> keySet=new LinkedHashSet<String>();
		for(String pathStr:pathValueMap.keySet()){
			String partialPathStr=getPartialPathStr(pathStr,levelList);
			if(partialPathStr!=null){
				keySet.add(partialPathStr);
			}
		}
		
		for(String curKey:keySet){
			HashMap<String,String> curMap=new HashMap<String,String>();
			for(String pathStr:pathValueMap.keySet()){
				if(containsKeyStr(curKey,pathStr,levelList)){
					returnCsv.addHeader(getKeyStr(pathStr));
					curMap.put(getKeyStr(pathStr),pathValueMap.get(pathStr));
				}
			}
			returnCsv.addRow(curMap);
		}
		
		return returnCsv;
	}
	
	public static MyPathValue loadSerialze(String srcPath) throws Exception{
		MyPathValue returnPV=null;
		
		try{
			ObjectInputStream ois=new ObjectInputStream(new FileInputStream(srcPath));
			
			returnPV=(MyPathValue)ois.readObject();
			
			ois.close();
			
		}catch(IOException | ClassNotFoundException e){
			System.out.println(e);
			if(true)System.exit(0);
		}
		
		return returnPV;
	}
	
	public void saveSerialize(String dstPath) throws Exception{	//シリアライズ化
		FileOutputStream fileOutputStream=new FileOutputStream(dstPath);
		ObjectOutputStream objectOutputStream=new ObjectOutputStream(fileOutputStream);
		objectOutputStream.writeObject(this);
		objectOutputStream.flush();

		objectOutputStream.close();
	}
	
	//↓↓↓other
	public static String getKeyStr(String pathStr){
		ArrayList<String> pathList=getPathList(pathStr);
		return pathList.get(pathList.size()-1);
	}
	
	public static boolean containsKeyStr(String curKey,String pathStr,int[] levelList){
		String matchStr=null;
		
		ArrayList<String> pathList=getPathList(pathStr);
		for(int curInt:levelList){
			if(curInt>pathList.size()-1){
				if(matchStr==null)matchStr=".*";
				else matchStr+=SEP_STR+".*";
				continue;
			}
			
			if(matchStr==null)matchStr=pathList.get(curInt);
			else matchStr+=SEP_STR+pathList.get(curInt);
		}
		
		if(curKey.matches(matchStr))return true;
		else return false;
	}
	
	public static String getPartialPathStr(String pathStr,int[] levelList){
		String returnStr=null;
		
		ArrayList<String> pathList=getPathList(pathStr);
		for(int curInt:levelList){
			if(curInt>pathList.size()-1)return null;
			
			if(returnStr==null)returnStr=pathList.get(curInt);
			else returnStr+=SEP_STR+pathList.get(curInt);
		}
		
		return returnStr;
	}
	
	public static ArrayList<String> getPathList(String pathStr){
		String[] word=pathStr.split(SEP_STR);
		return new ArrayList<String>(Arrays.asList(word));
	}
	
	public static String getPathStr(ArrayList<String> pathList){
		String returnStr=null;
		
		for(String curStr:pathList){
			if(returnStr==null)returnStr=curStr;
			else returnStr+=SEP_STR+curStr;
		}
		
		return returnStr;
	}
}
