import java.util.*;
import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;

public class MikanManager{
	static final String LIST_PATH="みかんリスト/system/list.txt";
	
	List<String> taskList;
	
	public MikanManager(){
	}
	
	public void startMikan() throws Exception{	//みかんリストを起動
		ProcessBuilder builder = new ProcessBuilder("みかんリスト/mikan.exe");
		Process process = builder.start();
	}
	
	public void closeMikan() throws Exception{	//みかんリストを終了
		ProcessBuilder builder = new ProcessBuilder(Arrays.asList("AutoIt3.exe","CloseMikan.au3"));
		Process process = builder.start();
		Thread.sleep(1000);
	}
	
	public void loadMikanList() throws Exception{
		Path file = Paths.get(LIST_PATH);
		taskList =  Files.readAllLines(file, Charset.forName("SHIFT_JIS"));
	}
	
	public void saveMikanList() throws Exception{
		PrintWriter wr = new PrintWriter(LIST_PATH, Charset.forName("Shift-JIS"));
		
		for(String curStr:taskList)wr.println(curStr);
		
		wr.close();
	}
	
	public int getIndex(String checkStr){	//文字列と一致する先頭のタスクの行を取得
		for(int i=0;i<taskList.size();i++){
			String editStr=taskList.get(i);
			if(!editStr.matches("\t*□.*"))continue;
			
			editStr=editStr.replaceAll("^\t*□","");
			if(editStr.equals(checkStr))return i;
		}
		
		return -1;
	}
	
	public void check(String checkStr){	//指定タスクをチェック
		for(int i=0;i<taskList.size();i++){
			String editStr=taskList.get(i);
			if(!editStr.matches("\t*□.*"))continue;
			
			editStr=editStr.replaceAll("^\t*□","");
			if(editStr.equals(checkStr)){
				taskList.set(i,taskList.get(i).replaceFirst("□","■"));
				return;
			}
		}
	}
	
	public String getTopTask(){	//次回実行されるタスクを返す
		String topStr=null;
		int topLevel=-1;
		for(int i=0;i<taskList.size();i++){
			String tmpStr=taskList.get(i);
			if(topStr!=null && tmpStr.length()==0)break;	//カテゴリ移動で終了
			if(!tmpStr.matches("^\t*□.*"))continue;	//タスク外スキップ
			if(tmpStr.matches("^\t*□\\-+"))continue;	//セパレータスキップ
			
			if(topStr==null){
				topLevel=getTabCount(tmpStr);
				topStr=tmpStr.replaceAll("^\t*□","");
			}else{
				int tmpLevel=getTabCount(tmpStr);
				if(tmpLevel<=topLevel)break;
				topStr=tmpStr.replaceAll("^\t*□","");
				topLevel=tmpLevel;
			}
		}
		
		return topStr;
	}
	
	public int getTabCount(String checkStr){
		return checkStr.length()-checkStr.replaceAll("\t","").length();
	}
	
	public String getLevelTask(int startPos,int checkLevel){	//startPosより上にある直近のcheckLevelのタスクを返す
		for(int i=startPos;i>=0;i--){
			String editStr=taskList.get(i);
			if(editStr.matches("^\t*□\\-+"))continue;	//セパレータスキップ
			if(getTabCount(editStr)==checkLevel)return editStr.replaceAll("^\t*□","");
		}
		
		return null;
	}
	
	public String getCategory(int startPos){	//startPosより上にある直近のカテゴリを返す
		for(int i=startPos;i>=0;i--){
			String editStr=taskList.get(i);
			if(editStr.length()>0 && !editStr.matches("^\t*(□|■).*"))return editStr;
		}
		
		return null;
	}
	
	public String getFullpath(String checkStr){	//タスクのフルパスを返す
		if(checkStr==null)return null;
		int taskPos=getIndex(checkStr);
		if(taskPos==-1)return null;
		int taskLevel=getTabCount(taskList.get(taskPos));
		String returnStr="/"+taskList.get(taskPos).replaceAll("^\t*□","");
		for(int i=taskLevel-1;i>=0;i--){
			String tmpStr=getLevelTask(taskPos-1,i);
			if(tmpStr!=null)returnStr="/"+tmpStr.replaceAll("^\t*□","")+returnStr;
		}
		returnStr="/"+getCategory(taskPos-1)+returnStr;
		
		return returnStr;
	}
	
	public void resetTask() {
		for(int i=0;i<taskList.size();i++){
			taskList.set(i,taskList.get(i).replaceFirst("■","□"));
		}
	}
}
