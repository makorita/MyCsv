import java.io.*;
import java.nio.charset.Charset;
import java.util.*;

public class Jikkou01_MikanCheck{
/*
javac -cp "./;../_myLibrary\poi-bin-5.2.3/*" Jikkou01_MikanCheck.java
java -cp "./;../_myLibrary\poi-bin-5.2.3/*" Jikkou01_MikanCheck
*/
	public static void main(String[] args) throws Exception{
		//みかん終了
		{
			ProcessBuilder builder = new ProcessBuilder(Arrays.asList("AutoIt3.exe","CloseMikan.au3"));
			Process process = builder.start();
			Thread.sleep(1000);
		}
		
		//セット準備
		HashSet<String> removeSet=new HashSet<String>();
		removeSet.add("最優先");
		HashSet<String> ignoreSet=new HashSet<String>();
		ignoreSet.add("Weekly");
		ignoreSet.add("Monthly");
		
		//リスト読み込み
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("みかんリスト/system/list.txt"), "Shift-JIS"));
		
		String line;
		ArrayList<String> lineList=new ArrayList<String>();
		String mode="NONE";
		while ((line = br.readLine()) != null) {
			if(mode.equals("NONE")){
				if(line.matches("\t*□.*")){
					lineList.add(line);
				}else if(line.matches("\t*■.*")){
					line=line.replaceFirst("■","□");
					lineList.add(line);
				}else if(line.length()==0){
					lineList.add(line);
				}else if(removeSet.contains(line)){
					mode="REMOVE";
					lineList.add(line);
				}else if(ignoreSet.contains(line)){
					mode="IGNORE";
					lineList.add(line);
				}else{
					lineList.add(line);
				}
				
			}else if(mode.equals("REMOVE")){
				if(line.matches("\t*□.*")){
					lineList.add(line);
				}else if(line.matches("\t*■.*")){
				}else if(line.length()==0){
					mode="NONE";
					lineList.add(line);
				}else{
					System.out.println("想定外:"+line);
					if(true)System.exit(0);
				}
			}else if(mode.equals("IGNORE")){
				if(line.matches("\t*□.*")){
					lineList.add(line);
				}else if(line.matches("\t*■.*")){
					lineList.add(line);
				}else if(line.length()==0){
					mode="NONE";
					lineList.add(line);
				}else{
					System.out.println("想定外:"+line);
					if(true)System.exit(0);
				}
			}
		}
		
		br.close();
		
		//書き込み
		PrintWriter wr = new PrintWriter("みかんリスト/system/list.txt", Charset.forName("Shift-JIS"));
		
		for(String curStr:lineList){
			wr.println(curStr);
		}
		
		wr.close();
		
		//みかん開始
		{
			ProcessBuilder builder = new ProcessBuilder("みかんリスト/mikan.exe");
			Process process = builder.start();
		}
	}
}
