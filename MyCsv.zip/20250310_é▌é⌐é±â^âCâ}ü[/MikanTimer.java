import java.io.*;
import java.nio.channels.*;
import java.util.*;
import java.text.*;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;

import org.apache.poi.*;
import org.apache.poi.ss.formula.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.openxml4j.exceptions.*;
import org.apache.poi.xssf.usermodel.*;

public class MikanTimer extends JFrame implements ActionListener{
/*
javac -cp "./;../_myLibrary\poi-bin-5.2.3/*" MikanTimer.java
java -cp "./;../_myLibrary\poi-bin-5.2.3/*" MikanTimer
*/
	private static FileLock lock;
	
	JEditorPane taskText;
	JLabel timerLabel;
	javax.swing.Timer timer;
	
	String taskName;
	int poolTime;
	int startTime;
	int maxTime;
	String mode;
	
	HashMap<String,String> configMap;
	HashMap<String,Integer> maxMap;;
	
	MikanManager mManager;
	
	public MikanTimer(String title) throws Exception{
		super(title);
		
		//コンフィグ読み込み
		configMap=new HashMap<String,String>();
		{
			BufferedReader br = new BufferedReader(new FileReader("MikanTimer.ini"));
			String line;
			while ((line = br.readLine()) != null) {
				if(!line.matches(".*=.*"))continue;
				
				String[] word=line.split("=");
				configMap.put(word[0],word[1]);
			}
			br.close();
		}
		
		//位置サイズ決め
		int xPos=Integer.parseInt(configMap.get("xPos"));
		int yPos=Integer.parseInt(configMap.get("yPos"));
		setBounds(xPos, yPos, 200, 160);
		
		//クローズボタン定義
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				int result = JOptionPane.showConfirmDialog(
					MikanTimer.this,
					"本当に終了しますか？",
					"終了確認",
					JOptionPane.YES_NO_OPTION,
					JOptionPane.WARNING_MESSAGE
				);
				if (result == JOptionPane.YES_OPTION) {
					dispose(); // ウィンドウを閉じる
					System.exit(0); // アプリ終了
				}
			}
		});
		
		//タスク名
		taskText = new JEditorPane("text/html","");
		taskText.setEditable(false);
		taskText.setOpaque(false);
		DefaultCaret caret = (DefaultCaret) taskText.getCaret();
		caret.setUpdatePolicy(DefaultCaret.NEVER_UPDATE);
		caret.setVisible(false);
		getContentPane().add(taskText, BorderLayout.NORTH);
		
		//時刻表示
		timerLabel=new JLabel();
		timerLabel.setHorizontalAlignment(JLabel.CENTER);
		timerLabel.setFont(new java.awt.Font(java.awt.Font.SANS_SERIF, java.awt.Font.PLAIN, 40));
		getContentPane().add(timerLabel, BorderLayout.CENTER);
		
		//ボタン
		JPanel buttonPanel = new JPanel();
		int bWidth=55;
		int bHeight=25;
		JButton doneButton = new JButton("Done");
		doneButton.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 12));
		doneButton.setMargin(new Insets(0, 0, 0, 0));
		doneButton.setPreferredSize(new Dimension(bWidth,bHeight));
		doneButton.addActionListener(this);
		doneButton.setActionCommand("done");
		JButton changeButton = new JButton("Change");
		changeButton.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 12));
		changeButton.setMargin(new Insets(0, 0, 0, 0));
		changeButton.setPreferredSize(new Dimension(bWidth,bHeight)); 
		changeButton.addActionListener(this);
		changeButton.setActionCommand("change");
		JButton restButton = new JButton("Rest");
		restButton.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 12));
		restButton.setMargin(new Insets(0, 0, 0, 0));
		restButton.setPreferredSize(new Dimension(bWidth,bHeight));
		restButton.addActionListener(this);
		restButton.setActionCommand("rest");
		buttonPanel.add(doneButton);
		buttonPanel.add(changeButton);
		buttonPanel.add(restButton);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		
		//タイマー
		timer=new javax.swing.Timer(1000 , this);
		timer.setActionCommand("timer");
		
		//モード
		mode="TASK";
		poolTime=0;
		
		//みかんマネージャー
		mManager=new MikanManager();
		mManager.loadMikanList();
		
		//その他オプション
		setVisible(true);
		setAlwaysOnTop(true);
		setResizable(false);
	}
	
	public void start(){
		try{
			if(timer.isRunning())timer.stop();
			mManager.closeMikan();
			mManager.loadMikanList();
			
			//新タスクセット
			if(mode.equals("TASK")){
				taskName=mManager.getTopTask();
				if(taskName.equals("睡眠"))mode="SLEEP";
			}else if(mode.equals("SLEEP")){
				taskName="睡眠";
			}
			
			//最大時間セット
			loadMaxMap();
			if(maxMap.containsKey(taskName))maxTime=maxMap.get(taskName)*60;
			else maxTime=30*60;
			
			//タスク名セット
			taskText.setText(getTaskText(taskName+"<br>予定時間("+getTimeStr(maxTime)+")"));
			
			startTime=(int)System.currentTimeMillis()/1000;
			timer.start();
			
			mManager.startMikan();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void done(){
		try{
			timer.stop();
			
			mManager.closeMikan();
			mManager.loadMikanList();
			
			
			String fullPath=mManager.getFullpath(taskName);
			if(fullPath==null){	//途中でチェックが付いたケース。終了処理しない。
				mode="TASK";
				poolTime=0;
				return;
			}
			
			int curTime=(int)System.currentTimeMillis()/1000;
			int diffTime=poolTime+curTime-startTime;
			
			//ログ出力
			writeLog(fullPath,diffTime);
			
			//休憩追加
			addRest();
			
			//結果表示
			showResult(taskName);
			
			//チェック
			mManager.check(taskName);
			mManager.saveMikanList();
			
			mode="TASK";
			poolTime=0;
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void rest(){
		try{
			if(timer.isRunning())timer.stop();
			
			//新タスクセット
			taskName="休憩";
			
			//最大時間セット
			int restTime=getRestTime();
			if(restTime<600)maxTime=600;
			else maxTime=1800;
			
			//タスク名セット
			taskText.setText(getTaskText(taskName+"<br>残り("+getTimeStr(restTime)+")"));
			
			startTime=(int)System.currentTimeMillis()/1000;
			timer.start();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void restDone(){
		try{
			timer.stop();
			
			int curTime=(int)System.currentTimeMillis()/1000;
			int diffTime=curTime-startTime;
			
			//休憩追加
			reduceRest(diffTime);
			
			mode="TASK";
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void loadMaxMap() throws Exception{
		maxMap=new HashMap<String,Integer>();
		
		BufferedReader br = new BufferedReader(new FileReader("タスク上限時間.txt"));
		String line;
		while ((line = br.readLine()) != null) {
			if(!line.matches(".+\t\\d+"))continue;
			String[] word=line.split("\t");
			maxMap.put(word[0],Integer.parseInt(word[1]));
		}
		br.close();
		
		//睡眠減算処理
		if(mode.equals("SLEEP")){
			SimpleDateFormat form=new SimpleDateFormat("yyyy/MM/dd");
			form.setTimeZone(TimeZone.getTimeZone("UTC"));
			Calendar cal=Calendar.getInstance(TimeZone.getTimeZone("UTC"));
			cal.setTimeInMillis(System.currentTimeMillis());
			String dateStr=form.format(cal.getTime());
			String sleepKey=dateStr+"#SEP#/Daily/睡眠";
		
			TreeMap<String,Integer> curMap=loadLog();
			int sleepTime=0;
			if(curMap.containsKey(sleepKey))sleepTime=curMap.get(sleepKey);
			maxMap.put("睡眠",maxMap.get("睡眠")-sleepTime);
		}
	}
	
	public void playMusic(){
		if(!configMap.get("playFlag").equals("true"))return;
		
		try{
			ProcessBuilder builder = new ProcessBuilder(Arrays.asList("AutoIt3.exe","音楽再生.au3"));
			Process process = builder.start();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public int getRestTime(){
		int returnInt=-1;
		
		try{
			BufferedReader br = new BufferedReader(new FileReader("休憩.txt"));
			returnInt=Integer.parseInt(br.readLine());
			br.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return returnInt;
	}
	
	public void addRest(){
		int curRest=getRestTime();
		try{
			PrintWriter wr=new PrintWriter(new FileWriter("休憩.txt"));
			wr.println(String.valueOf(curRest+Integer.parseInt(configMap.get("restZoubun"))));
			wr.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void reduceRest(int reduceTime){
		int curRest=getRestTime();
		try{
			PrintWriter wr=new PrintWriter(new FileWriter("休憩.txt"));
			curRest-=reduceTime;
			if(curRest<0)curRest=0;
			wr.println(String.valueOf(curRest));
			wr.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public Object[] getResult(String taskName){
		Object[] returnObj=new Object[6];
		
		try{
			String fullPath=mManager.getFullpath(taskName);
			
			SimpleDateFormat form=new SimpleDateFormat("yyyy/MM/dd");
			form.setTimeZone(TimeZone.getTimeZone("UTC"));
			Calendar cal=Calendar.getInstance(TimeZone.getTimeZone("UTC"));
			cal.setTimeInMillis(System.currentTimeMillis());
			String dateStr=form.format(cal.getTime());
			
			//順位取得
			int pos=1;
			int num=1;
			TreeMap<String,Integer> curMap=loadLog();
			String curKey=dateStr+"#SEP#"+fullPath;
			int curTime=curMap.get(curKey);
			for(String key:curMap.keySet()){
				if(!key.matches(".*"+taskName))continue;
				if(key.matches(dateStr+".*")){	//自分のログ時
					returnObj[2]=curTime;
					continue;
				}
				
				int taisyouTime=curMap.get(key);
				num++;
				if(taisyouTime<curTime)pos++;
			}
			
			returnObj[0]=pos;
			returnObj[1]=num;
			
			//完了タスク数
			TreeMap<String,Integer> dayTaskNumMap=new TreeMap<String,Integer>();
			for(String key:curMap.keySet()){
				String[] word=key.split("#SEP#");
				if(dayTaskNumMap.containsKey(word[0])){
					int tmpCount=dayTaskNumMap.get(word[0]);
					tmpCount++;
					dayTaskNumMap.put(word[0],tmpCount);
				}else dayTaskNumMap.put(word[0],1);
			}
			int taskNum=dayTaskNumMap.get(dateStr);
			int todayPos=1;
			for(String key:dayTaskNumMap.keySet()){
				if(key.matches(dateStr+".*"))continue;
				
				int taisyouTaskNum=dayTaskNumMap.get(key);
				if(taisyouTaskNum>taskNum)todayPos++;
			}
			returnObj[3]=taskNum;
			returnObj[4]=todayPos;
			returnObj[5]=dayTaskNumMap.size();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return returnObj;
	}
	
	public void showResult(String taskName){
		Object[] resultObj=getResult(taskName);
		
		String messageStr="<html>";
		messageStr+="タスク名称："+taskName+"<br>";
		messageStr+="タスク時間：合計"+getTimeStr((int)resultObj[2])+"<br>";
		messageStr+="タスク順位："+resultObj[0]+"位("+resultObj[1]+"タスク中)<br>";
		messageStr+="タスク完了："+resultObj[3]+"個目("+resultObj[4]+"/"+resultObj[5]+")<br>";
		messageStr+="</html>";
		JOptionPane optionPane = new JOptionPane(messageStr, JOptionPane.INFORMATION_MESSAGE);
		JDialog dialog = optionPane.createDialog(this, "結果");
		dialog.setModal(false);
		dialog.setLocation(Integer.parseInt(configMap.get("dialogXPos")), Integer.parseInt(configMap.get("dialogYPos")));
		dialog.setVisible(true);
	}
	
	public static void main(String[] args) throws Exception{	//-------------------------------------------------------
		lock();	//二重起動禁止
		
		MikanTimer mikanTimer = new MikanTimer("MikanTimer");
		mikanTimer.start();
		
	}
	
	public static void lock() throws Exception{
		File file = new File("timer.lock");
		FileChannel channel = new FileOutputStream(file).getChannel();
		lock = channel.tryLock();
		
		if (lock == null) {
			System.out.println("アプリは既に実行中です。");
			System.exit(1); // 二重起動を防ぐ
		}
	}
	
	public static String getTaskText(String befStr){
		String returnStr="<html><body style='text-align:center;width:100%; color:red;'>"+befStr+"</body></html>";
		
		return returnStr;
	}
	
	public static String getTimerStr(int timerInt){
		int hour=timerInt/(60*60);
		int min=(timerInt%(60*60))/60;
		int sec=timerInt%60;
		
		return String.format("%02d",hour)+":"+String.format("%02d",min)+":"+String.format("%02d",sec);
	}
	
	public static String getTimeStr(int timerInt){
		int hour=timerInt/(60*60);
		int min=(timerInt%(60*60))/60;
		int sec=timerInt%60;
		
		String returnStr=String.format("%02d",sec)+"秒";
		if(min>0 || hour>0)returnStr=String.format("%02d",min)+"分"+returnStr;
		if(hour>0)returnStr=String.format("%02d",hour)+"時間"+returnStr;
		
		return returnStr;
	}
	
	public static void writeLog(String taskName,int timeDiff) throws Exception{
		TreeMap<String,Integer> resultMap=loadLog();
		
		SimpleDateFormat form=new SimpleDateFormat("yyyy/MM/dd");
		form.setTimeZone(TimeZone.getTimeZone("UTC"));
		Calendar cal=Calendar.getInstance(TimeZone.getTimeZone("UTC"));
		cal.setTimeInMillis(System.currentTimeMillis());
		String dateStr=form.format(cal.getTime());
		if(resultMap.containsKey(dateStr+"#SEP#"+taskName)){
			int curTime=resultMap.get(dateStr+"#SEP#"+taskName);
			curTime+=timeDiff;
			resultMap.put(dateStr+"#SEP#"+taskName,curTime);
		}else resultMap.put(dateStr+"#SEP#"+taskName,timeDiff);
		
		writeLog(resultMap);
	}
	
	public static void writeLog(TreeMap<String,Integer> curMap) throws Exception{
		Workbook wb = WorkbookFactory.create(new FileInputStream("MikanLog_template.xlsx"));
		Sheet sheet=wb.getSheet("MikanLog");
		
		//セルの日付フォーマット
		SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd");
		
		//セルの日付スタイル定義
		CreationHelper createHelper = wb.getCreationHelper();
		CellStyle cellStyle = wb.createCellStyle();
		short style = createHelper.createDataFormat().getFormat("yyyy/MM/dd");
		cellStyle.setDataFormat(style);
		
		int rowIndex=1;
		for(String key:curMap.keySet()){
			int curTime=curMap.get(key);
			String[] word=key.split("#SEP#");
			Row row=sheet.getRow(rowIndex);
			if(row==null)row=sheet.createRow(rowIndex);
			rowIndex++;
			
			Cell dateCell=row.getCell(0);
			if(dateCell==null)dateCell=row.createCell(0);
			Date date = df.parse(word[0]);
			dateCell.setCellValue(date);
			dateCell.setCellStyle(cellStyle);
			Cell taskNameCell=row.getCell(1);
			if(taskNameCell==null)taskNameCell=row.createCell(1);
			taskNameCell.setCellValue(word[1]);
			Cell diffTimeCell=row.getCell(2);
			if(diffTimeCell==null)diffTimeCell=row.createCell(2);
			diffTimeCell.setCellValue(curTime);
			Cell diffTimeMinuteCell=row.getCell(3);
			if(diffTimeMinuteCell==null)diffTimeMinuteCell=row.createCell(3);
			diffTimeMinuteCell.setCellValue((double)curTime/60.0);
			Cell diffTimeHourCell=row.getCell(4);
			if(diffTimeHourCell==null)diffTimeHourCell=row.createCell(4);
			diffTimeHourCell.setCellValue((double)curTime/3600.0);
			
		}
		
		FileOutputStream out = new FileOutputStream("MikanLog.xlsx");
		wb.write(out);
		out.close();
			
		wb.close();
	}
	
	public static TreeMap<String,Integer> loadLog() throws Exception{
		TreeMap<String,Integer> resultMap=new TreeMap<String,Integer>();
		
		Workbook wb = WorkbookFactory.create(new FileInputStream("MikanLog.xlsx"));
		Sheet sheet=wb.getSheet("MikanLog");
		SimpleDateFormat form=new SimpleDateFormat("yyyy/MM/dd");
		for(int rowIndex=1;rowIndex<=sheet.getLastRowNum();rowIndex++){
			Row row=sheet.getRow(rowIndex);
			if(row==null)continue;
			if(row.getCell(0)==null)continue;
			if(row.getCell(0).getCellType()!=CellType.NUMERIC)continue;
			
			String dateStr=form.format(row.getCell(0).getDateCellValue());
			String taskName=row.getCell(1).getStringCellValue();
			int taskTime=(int)row.getCell(2).getNumericCellValue();
			
			resultMap.put(dateStr+"#SEP#"+taskName,taskTime);
		}
		
		wb.close();
		
		return resultMap;
	}
	
	@Override
	public void actionPerformed(ActionEvent e){
		if(e.getActionCommand().equals("timer")){	//タイマーイベント
			if(!mode.equals("REST")){
				int curTime=(int)System.currentTimeMillis()/1000;
				int diffTime=poolTime+curTime-startTime;
				timerLabel.setText(getTimerStr(diffTime));
				
				if(diffTime>maxTime){
					playMusic();
					maxTime=diffTime+10*60;	//10分追加
				}
				
				//睡眠移行
				//maxMapのロードは負荷がかかるからやらない⇒タスク実行中のmaxTime変更不可
				if(mode.equals("TASK") && configMap.get("sleepFlag").equals("true")){
					int compareTime=60*60;
					if(maxMap.containsKey(taskName))compareTime=maxMap.get(taskName)*60+30*60;
					if(diffTime>compareTime){
						mode="SLEEP";
						poolTime=30*60;
						start();
					}
				}
				
			}else if(mode.equals("REST")){
				int curTime=(int)System.currentTimeMillis()/1000;
				int diffTime=curTime-startTime;
				timerLabel.setText(getTimerStr(diffTime));
				
				if(diffTime>maxTime){
					playMusic();
					maxTime+=10*60;	//10分追加
				}
			}
			
		}else if(e.getActionCommand().equals("done")){	//Doneボタンイベント
			if(!mode.equals("REST")){
				done();
				start();
			}else if(mode.equals("REST")){
				restDone();
				start();
			}
			
		}else if(e.getActionCommand().equals("change")){	//Cancelボタンイベント
			if(!mode.equals("REST")){
				start();
			}
		}else if(e.getActionCommand().equals("rest")){	//RESTボタンイベント
			if(!mode.equals("REST")){
				int curTime=(int)System.currentTimeMillis()/1000;
				poolTime=poolTime+curTime-startTime;
				mode="REST";
				rest();
			}
		}
	}
}
