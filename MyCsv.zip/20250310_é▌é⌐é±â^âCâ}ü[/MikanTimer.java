import java.io.*;
import java.nio.channels.*;
import java.util.*;
import java.text.*;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;

import org.apache.poi.*;
import org.apache.poi.ss.formula.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.openxml4j.exceptions.*;
import org.apache.poi.xssf.usermodel.*;

public class MikanTimer extends JFrame implements ActionListener{
/*
javac -cp "./;../_myLibrary\poi-bin-5.2.3/*" MikanTimer.java
java -cp "./;../_myLibrary\poi-bin-5.2.3/*" MikanTimer
*/
	private static FileLock lock;
	
	JEditorPane taskText;
	JLabel timerLabel;
	javax.swing.Timer timer;
	
	String taskName;
	long startTime;
	long maxTime;
	
	HashMap<String,String> configMap;
	MikanManager mManager;
	
	public MikanTimer(String title) throws Exception{
		super(title);
		
		//コンフィグ読み込み
		configMap=new HashMap<String,String>();
		BufferedReader br = new BufferedReader(new FileReader("MikanTimer.ini"));
		String line;
		while ((line = br.readLine()) != null) {
			if(!line.matches(".*=.*"))continue;
			
			String[] word=line.split("=");
			configMap.put(word[0],word[1]);
		}
		br.close();
		
		int xPos=Integer.parseInt(configMap.get("xPos"));
		int yPos=Integer.parseInt(configMap.get("yPos"));
		setBounds(xPos, yPos, 200, 160);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//タスク名
		taskText = new JEditorPane("text/html","");
		taskText.setText(getTaskText("-"));
		taskText.setEditable(false);
		taskText.setOpaque(false);
		DefaultCaret caret = (DefaultCaret) taskText.getCaret();
		caret.setUpdatePolicy(DefaultCaret.NEVER_UPDATE);
		caret.setVisible(false);
		getContentPane().add(taskText, BorderLayout.NORTH);
		
		//時刻表示
		startTime=System.currentTimeMillis();
		timerLabel=new JLabel(getTimerStr());
		timerLabel.setHorizontalAlignment(JLabel.CENTER);
		timerLabel.setFont(new java.awt.Font(java.awt.Font.SANS_SERIF, java.awt.Font.PLAIN, 40));
		getContentPane().add(timerLabel, BorderLayout.CENTER);
		
		//ボタン
		JPanel buttonPanel = new JPanel();
		int bWidth=80;
		int bHeight=25;
		JButton doneButton = new JButton("Done");
		doneButton.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 14));
		doneButton.setMargin(new Insets(0, 0, 0, 0));
		doneButton.setPreferredSize(new Dimension(bWidth,bHeight));
		doneButton.addActionListener(this);
		doneButton.setActionCommand("done");
		JButton cancelButton = new JButton("Cancel");
		cancelButton.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 14));
		cancelButton.setMargin(new Insets(0, 0, 0, 0));
		cancelButton.setPreferredSize(new Dimension(bWidth,bHeight)); 
		cancelButton.addActionListener(this);
		cancelButton.setActionCommand("cancel");
		buttonPanel.add(doneButton);
		buttonPanel.add(cancelButton);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		
		//タイマー
		timer=new javax.swing.Timer(1000 , this);
		timer.setActionCommand("timer");
		
		//みかんリストマネージャー
		mManager=new MikanManager();
	}
	
	@Override
	public void actionPerformed(ActionEvent e){
		if(e.getActionCommand().equals("timer")){	//タイマーイベント
			timerLabel.setText(getTimerStr());
			//アラーム処理
			if(configMap.get("alarmFlag").equals("true")){
				long curTime=System.currentTimeMillis();
				long diffTime=curTime-startTime;
				if(diffTime>maxTime){
					playMusic();
					maxTime+=10*60*1000;	//10分追加
				}
			}
				
		}else if(e.getActionCommand().equals("done")){	//Doneボタンイベント
			done(true);
		}else if(e.getActionCommand().equals("cancel")){	//Cancelボタンイベント
			done(false);
		}
	}
	
	public void timerStart(){
		timer.start();
	}
	
	public void timerStop(){
		timer.stop();
	}
	
	public String getTimerStr(){
		long curTime=System.currentTimeMillis();
		long diffTime=curTime-startTime;
		long hour=diffTime/(1000*60*60);
		long min=(diffTime%(1000*60*60))/(60*1000);
		long sec=(diffTime%(1000*60))/1000;
		
		return String.format("%02d",hour)+":"+String.format("%02d",min)+":"+String.format("%02d",sec);
	}
	
	public void done(boolean doneFlag){
		try{
			timerStop();
			mManager.closeMikan();
			Thread.sleep(1000);
			mManager.loadMikanList();
			
			//終了処理
			if(doneFlag && taskName!=null){
				long curTime=System.currentTimeMillis();
				long diffTime=curTime-startTime;
				int diffTimeInt=(int)(diffTime/1000);	//ミリ秒から秒になおす
				
				//ランキング更新
				int juni=-1;
				if(configMap.get("rankingFlag").equals("true")){
					killRanking();
					Thread.sleep(1000);
					String fullPath=mManager.getFullpath(taskName);
					juni=writeRanking(fullPath,diffTimeInt);
					
				}
				
				//ログ出力
				if(configMap.get("logFlag").equals("true")){
					logWrite(mManager.getFullpath(taskName),diffTimeInt);
				}
				
				//結果表示
				showResult(taskName,diffTimeInt,juni+1);
				
				//チェック
				mManager.check(taskName);
			}
			
			//新タスクセット
			taskName=mManager.getTopTask();
			taskText.setText(getTaskText(taskName));
			setMaxTime(taskName);
			
			mManager.saveMikanList();
			Thread.sleep(1000);
			mManager.startMikan();
			
			startTime=System.currentTimeMillis();
			timerStart();
			
		}catch(Exception e){
			System.out.println(e);
		}
	}
	
	public void showResult(String taskName,int diffTime,int juni){
		String messageStr="<html>";
		messageStr+="タスク名称："+taskName+"<br>";
		messageStr+="タスク時間："+getTimeStr(diffTime)+"<br>";
		if(juni>-1)messageStr+="タスク順位："+String.valueOf(juni)+"位<br>";
		messageStr+="</html>";
		JOptionPane optionPane = new JOptionPane(messageStr, JOptionPane.INFORMATION_MESSAGE);
		JDialog dialog = optionPane.createDialog(this, "結果");
		dialog.setModal(false);
		dialog.setLocation(Integer.parseInt(configMap.get("dialogXPos")), Integer.parseInt(configMap.get("dialogYPos")));
		dialog.setVisible(true);
	}
	
	public void setMaxTime(String taskName) throws Exception{
		maxTime=30*60*1000;	//デフォルト30分
		
		BufferedReader br = new BufferedReader(new FileReader("タスク上限時間.txt"));
		String line;
		while ((line = br.readLine()) != null) {
			if(!line.matches(".+\t\\d+"))continue;
			String[] word=line.split("\t");
			if(!word[0].equals(taskName))continue;
			
			maxTime=Long.parseLong(word[1])*1000*60;
		}
		br.close();
	}
	
	//-------------------------------------------------------
	public static void main(String[] args) throws Exception{
		lock();	//二重起動禁止
		
		MikanTimer mikanTimer = new MikanTimer("MikanTimer");
		mikanTimer.setVisible(true);
		mikanTimer.setAlwaysOnTop(true);
		mikanTimer.setResizable(false);
		
		mikanTimer.done(true);
		
	}
	
	public static void lock() throws Exception{
		File file = new File("mikan.lock");
		FileChannel channel = new FileOutputStream(file).getChannel();
		lock = channel.tryLock();
		
		if (lock == null) {
			System.out.println("アプリは既に実行中です。");
			System.exit(1); // 二重起動を防ぐ
		}
	}
	
	public static String getTaskText(String befStr){
		String returnStr="<html><body style='text-align:center;width:100%; color:red;'>"+befStr+"</body></html>";
		
		return returnStr;
	}
	
	public static void playMusic(){
		try{
			ProcessBuilder builder = new ProcessBuilder(Arrays.asList("AutoIt3.exe","音楽再生.au3"));
			Process process = builder.start();
		}catch(Exception e){
			System.out.println(e);
		}
	}
	
	public static void killRanking() throws Exception{
		ProcessBuilder builder = new ProcessBuilder(Arrays.asList("AutoIt3.exe","KillRanking.au3"));
		Process process = builder.start();
	}
	
	public static int writeRanking(String taskName,int taskTime) throws Exception{	//なんでもランキング更新
		int returnInt=-1;
		
		Workbook wb = WorkbookFactory.create(new FileInputStream("Ranking.xlsx"));
		Sheet sheet=wb.getSheet("ランキング");
		boolean kisyutuFlag=false;
		for(int rowIndex=0;rowIndex<=sheet.getLastRowNum();rowIndex++){
			Row row=sheet.getRow(rowIndex);
			if(row==null)continue;
			Cell koumokuCell=row.getCell(0);
			if(koumokuCell.getStringCellValue().equals(taskName)){
				returnInt=setRow(row,taskTime);
				kisyutuFlag=true;
			}
		}
		if(!kisyutuFlag){
			Row row=sheet.createRow(sheet.getLastRowNum()+1);
			Cell koumokuCell=row.createCell(0);
			koumokuCell.setCellValue(taskName);
			returnInt=setRow(row,taskTime);
		}
		
		FileOutputStream out = new FileOutputStream("Ranking.xlsx");
		wb.write(out);
		out.close();
		
		wb.close();
		
		return returnInt;
	}
	
	public static int setRow(Row row,int taskTime) throws Exception{
		int returnInt=-1;
		
		LinkedList<Integer> timeList=new LinkedList<Integer>();
		for(int cellIndex=1;cellIndex<row.getLastCellNum();cellIndex++){
			Cell cell=row.getCell(cellIndex);
			if(cell==null)break;
			if(cell.getCellType()==CellType.BLANK)break;
			
			if(cell.getCellType()==CellType.NUMERIC){
				Date curDate=cell.getDateCellValue();
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(curDate);
				
				int hour=calendar.get(Calendar.HOUR);
				int minute=calendar.get(Calendar.MINUTE);
				int second=calendar.get(Calendar.SECOND	);
				timeList.add(3600*hour+60*minute+second);
			}
		}
		
		boolean checkFlag=false;
		for(int i=0;i<timeList.size();i++){
			int curTime=timeList.get(i);
			if(curTime>taskTime){
				timeList.add(i,taskTime);
				returnInt=i;
				checkFlag=true;
				break;
			}
		}
		if(!checkFlag){
			returnInt=timeList.size();
			timeList.add(taskTime);
		}
		
		for(int i=0;i<timeList.size();i++){
			if(i>19)break;
			
			int curInt=timeList.get(i);
			int hour=curInt/3600;
			int minute=(curInt%3600)/60;
			int second=curInt%60;
			String timeStr=hour+":"+minute+":"+second;
			Cell cell=row.getCell(i+1);
			if(cell==null)cell=row.createCell(i+1);
			cell.setCellValue(DateUtil.convertTime(timeStr));
		}
		
		return returnInt;
	}
	
	public static String getTimeStr(int timeInt){
		int hour=timeInt/3600;
		int minute=(timeInt%3600)/60;
		int second=timeInt%60;
		
		String returnStr=String.format("%02d",second)+"秒";
		if(minute>0 || hour>0)returnStr=String.format("%02d",minute)+"分"+returnStr;
		if(hour>0)returnStr=String.format("%02d",hour)+"時間"+returnStr;
		
		return returnStr;
	}
	
	public static void logWrite(String taskName,int timeDiff) throws Exception{
		boolean existFlag=false;
		File tmpFile=new File("MikanLog.csv");
		if(tmpFile.exists())existFlag=true;
		
		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("MikanLog.csv", true), "Shift-JIS"));
		if(!existFlag)writer.write("日付,タスク名,タスク時間(秒)\n");
		
		SimpleDateFormat form=new SimpleDateFormat("yyyy/MM/dd");
		Calendar cal=Calendar.getInstance(Locale.JAPAN);
		String nitijiStr=form.format(cal.getTime());
		
		writer.write(nitijiStr+","+taskName+","+timeDiff+"\n");
		writer.flush();
		writer.close();
	}
}
