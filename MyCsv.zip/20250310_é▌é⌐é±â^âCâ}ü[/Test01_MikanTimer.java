import java.io.*;
import java.util.*;

public class Test01_MikanTimer{
	public static void main(String[] args) throws Exception{
		MikanTimer.closeMikan();
		Thread.sleep(1000);
		MikanManager mm=new MikanManager();
		mm.loadMikanList();
		mm.saveMikanList();
		Thread.sleep(1000);
		MikanTimer.startMikan();
	}
}
