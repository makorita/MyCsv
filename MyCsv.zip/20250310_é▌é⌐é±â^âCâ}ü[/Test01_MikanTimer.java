import java.io.*;
import java.util.*;

public class Test01_MikanTimer{
/*
javac -cp "./;../_myLibrary\poi-bin-5.2.3/*" Test01_MikanTimer.java
java -cp "./;../_myLibrary\poi-bin-5.2.3/*" Test01_MikanTimer
*/
	public static void main(String[] args) throws Exception{
		if(false){
			TreeMap<String,Integer> curMap=MikanTimer.loadLog();
			MikanTimer.writeLog("test04",10);
		}
		
		if(true){
			Object[] returnObj=MikanTimer.getPosition("test01");
			System.out.println(returnObj[0]+","+returnObj[1]+","+returnObj[2]);
		}
	}
}
