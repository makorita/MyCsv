import java.io.*;
import java.util.*;

public class Test02_MikanManager{
	public static void main(String[] args) throws Exception{
		if(true){
			MikanManager mm=new MikanManager();
			mm.loadMikanList();
			String taskName=mm.getTopTask();
			System.out.println(taskName);
		}
	}
}
