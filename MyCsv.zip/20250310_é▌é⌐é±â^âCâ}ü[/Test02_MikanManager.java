import java.io.*;
import java.util.*;

public class Test02_MikanManager{
	public static void main(String[] args) throws Exception{
		if(false){
			MikanManager.closeMikan();
			Thread.sleep(1000);
			MikanManager mm=new MikanManager();
			mm.loadMikanList();
			mm.saveMikanList();
			Thread.sleep(1000);
			MikanManager.startMikan();
		}
		
		if(false){
			int tabCount=MikanManager.getTabCount("			テスト");
			System.out.println(tabCount);
		}
		
		if(false){
			MikanManager.closeMikan();
			Thread.sleep(1000);
			MikanManager mm=new MikanManager();
			mm.loadMikanList();
			int pos=mm.getIndex("優先タスク処理");
			System.out.println(pos);
			MikanManager.startMikan();
		}
		
		if(false){
			MikanManager.closeMikan();
			Thread.sleep(1000);
			MikanManager mm=new MikanManager();
			mm.loadMikanList();
			mm.check("タブ処理");
			mm.saveMikanList();
			Thread.sleep(1000);
			MikanManager.startMikan();
		}
		
		if(false){
			MikanManager.closeMikan();
			Thread.sleep(1000);
			MikanManager mm=new MikanManager();
			mm.loadMikanList();
			String topTask=mm.getTopTask();
			System.out.println(topTask);
			MikanManager.startMikan();
		}
		
		if(true){
			MikanManager.closeMikan();
			Thread.sleep(1000);
			MikanManager mm=new MikanManager();
			mm.loadMikanList();
			String fullPath=mm.getFullpath("test2");
			System.out.println(fullPath);
			MikanManager.startMikan();
		}
	}
}
