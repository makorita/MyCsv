import java.io.*;
import java.util.*;

public class Test01_MyCsv{
	//javac -cp "./;E:/program/_myLibrary/poi-bin-5.1.0/*" Test01_MyCsv.java
	//java -cp "./;E:/program/_myLibrary/poi-bin-5.1.0/*" Test01_MyCsv
	
	public static void main(String[] args) throws Exception{
		MyCsv curCsv=new MyCsv();
		
//		List<String> curHeader=new LinkedList<String>();
//		curHeader.add("aaa");
//		curHeader.add("bbb");
//		curHeader.add("ccc");
//		curCsv.setHeader(curHeader);
//		
//		//List<String> tmpHeader=curCsv.getHeader();
//		//for(String curStr:tmpHeader)System.out.println(curStr);
//		
//		curCsv.addHeader("ddd");
//		curCsv.removeHeader("bbb");
//		
//		Map<String,String> map1=new HashMap<String,String>();
//		map1.put("aaa","qqq");
//		map1.put("ccc","rrr");
//		map1.put("ddd","sss");
//		
//		Map<String,String> map2=new HashMap<String,String>();
//		map2.put("aaa","ttt");
//		map2.put("ccc","yyy");
//		
//		List<Map<String,String>> tmpContent1=new LinkedList<Map<String,String>>();
//		tmpContent1.add(map1);
//		tmpContent1.add(map2);
//		curCsv.setContent(tmpContent1);
//		
//		Map<String,String> map3=new HashMap<String,String>();
//		map3.put("aaa","---");
//		map3.put("ccc","###");
//		map3.put("ddd","$$$");
//		
//		List<Map<String,String>> tmpContent2=new LinkedList<Map<String,String>>();
//		tmpContent2.add(map3);
//		curCsv.addContent(tmpContent2);
//		
//		/*
//		Map<String,String> rMap1=curCsv.getRow(1);
//		for (String key : rMap1.keySet()) {
//			System.out.println(key+","+rMap1.get(key));
//		}
//		*/
//		
//		Map<String,String> map4=new HashMap<String,String>();
//		map4.put("aaa","AAA");
//		map4.put("ccc","CCC");
//		map4.put("ddd","DDD");
//		curCsv.addRow(map4);
//		curCsv.setValue(3,"ddd","EEE");
//		//System.out.println(curCsv.getValue(2,"aaa"));
//		
//		
//		File tmpFile=new File("test.csv");
//		curCsv.loadCsv(tmpFile);
//		
//		curCsv.loadCsv("test.csv");
//		
//		curCsv.loadTabFile("test_tab.txt",false);
//		curCsv.loadTabFile("test_tab.txt",true);
		
		curCsv.loadExcel("test.xlsx","test");
		
		//curCsv.saveCsv("output.csv");
		
		//curCsv.outputGroupreplace("雛形.txt");
		
		/*
		List<String> valueList=curCsv.getCol("bbb");
		for(String curStr:valueList){
			System.out.println(curStr);
		}
		*/
		
		/*
		Map<String,String> map=curCsv.getMapping("ccc","bbb");
		for (String key : map.keySet()) {
			System.out.println(key+","+map.get(key));
		}
		*/
		
		Map<String,String> map=new HashMap<String,String>();
		map.put("BBB","10.0.0.1/24");
		map.put("456","192.168.0.1/24");
		MyCsv returnCsv=curCsv.mapMerge("bbb","試験列",map);
		
		List<String> replaceList=new LinkedList<String>();
		replaceList.add("MMMM");
		replaceList.add("NNNN");
		replaceList.add("OOOO");
		replaceList.add("PPPP");
		returnCsv=returnCsv.listReplace("bbb","BBB",replaceList);
		returnCsv=returnCsv.sort("bbb",false);
		//returnCsv=returnCsv.reFilter("bbb","PP",false);
		//returnCsv=returnCsv.containsIpFilter("試験列","10.0.0.1",false);
		returnCsv=returnCsv.containedIpFilter("試験列","10.0.0.1",false);
		
		//curCsv.showAll();
		returnCsv.showAll();
	}
}
