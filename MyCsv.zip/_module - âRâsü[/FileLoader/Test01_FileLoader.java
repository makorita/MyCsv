import java.io.*;
import java.util.*;

public class Test01_FileLoader{
	public static void main(String[] args) throws Exception{
		if(true){
			ArrayList<File> fileList=FileLoader.loadFileList("E:\\music\\04_サザンオールスターズ","contain.txt","jogai.txt",null);
			fileList=FileLoader.loadFileList("E:\\music\\04_TUBE","contain.txt",null,fileList);
			
			for(File curFile:fileList)System.out.println(curFile.getName());
		}
	}
}
