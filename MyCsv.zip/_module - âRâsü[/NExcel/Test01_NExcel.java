import java.io.*;
import java.util.*;

public class Test01_NExcel{
/*
javac -cp "./;lib/*" Test01_NExcel.java
java -cp "./;lib/*" Test01_NExcel
*/	
	public static void main(String[] args) throws Exception{
		if(false){
			NExcel curExl=new NExcel();
			ArrayList<String> headerList=new ArrayList<String>();
			headerList.add("test01");
			headerList.add("test02");
			headerList.add("test03");
			curExl.setHeader(headerList);
			System.out.println(curExl);
			
			System.out.println(curExl.getHeader(1));
			System.out.println(curExl.getHeaderSize());
			System.out.println(curExl.containsHeader("test02"));
			curExl.addHeader("test04");
			System.out.println(curExl);
			curExl.removeColumn("test02");
			System.out.println(curExl);
		}
		
		if(false){
			NExcel curExl=new NExcel();
			HashMap<String,String> tmpMap=new HashMap<String,String>();
			tmpMap.put("head01","value01");
			tmpMap.put("head02","value02");
			tmpMap.put("head03","value03");
			curExl.addRow(tmpMap);
			System.out.println(curExl);
			curExl.removeRow(0);
			System.out.println(curExl);
		}
		
		if(false){
			NExcel curExl=new NExcel();
			HashMap<String,String> tmpMap=new HashMap<String,String>();
			tmpMap.put("head01","value01");
			tmpMap.put("head02","value02");
			tmpMap.put("head03","value03");
			curExl.addRow(tmpMap);
			System.out.println(curExl.getValue(0,"head02"));
			System.out.println(curExl.containsKey(0,"head03"));
			System.out.println(curExl.containsKey(0,"head04"));
			curExl.setValue(0,"head04","value04");
			System.out.println(curExl);
			curExl.removeColValue(0,"head01");
			System.out.println(curExl);
		}
	}
}
