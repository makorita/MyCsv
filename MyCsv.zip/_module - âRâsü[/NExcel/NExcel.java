import java.util.*;

public class NExcel{
	private ArrayList<String> header;
	private ArrayList<HashMap<String,String>> content;
	
	public NExcel(){
		clear();
	}
	
	public void clear(){	//ヘッダ、コンテントの初期化
		header=new ArrayList<String>();
		content=new ArrayList<HashMap<String,String>>();
	}
	
	public int getHeaderSize(){	//ヘッダサイズ取得
		return header.size();
	}
	
	public boolean containsHeader(String colName){	//ヘッダに指定値があるか
		return header.contains(colName);
	}
	
	public String getHeader(int index){	//指定位置のヘッダ取得
		return header.get(index);
	}
	
	public void addHeader(String colName){	//ヘッダ追加
		if(header.contains(colName))return;
		header.add(colName);
	}
	
	public void setHeader(ArrayList<String> tmpHeader){	//ヘッダセット
		clear();
		for(String curStr:tmpHeader)addHeader(curStr);
	}
	
	public int getContentSize(){	//contentサイズ取得
		return content.size();
	}
	
	public void addRow(HashMap<String,String> curMap){	//行追加
		HashMap<String,String> tmpMap=new HashMap<String,String>();
		
		for(String key:curMap.keySet()){
			String value=curMap.get(key);
			
			addHeader(key);
			tmpMap.put(key,value);
		}
		
		content.add(tmpMap);
	}
	
	public void removeRow(int index){
		content.remove(index);
	}
	
	public void removeColumn(String colName){	//指定ヘッダ削除
		header.remove(header.indexOf(colName));
		for(HashMap<String,String> curMap:content){
			if(curMap.containsKey(colName))curMap.remove(colName);
		}
	}
	
	public String getValue(int index,String colName){	//値を取得
		if(index>content.size()-1)return null;
		if(!content.get(index).containsKey(colName))return null;
		
		return content.get(index).get(colName);
	}
	
	public boolean containsKey(int index,String colName){	//指定行にキーバリューがあるか
		return content.get(index).containsKey(colName);
	}
	
	public void setValue(int index,String colName,String value){	//指定の値をセット
		if(index>content.size()-1)return;
		addHeader(colName);
		
		content.get(index).put(colName,value);
	}
	
	public void removeColValue(int index,String colName){	//指定値を削除
		if(index>content.size()-1)return;
		
		content.get(index).remove(colName);
	}
	
	public int getValueIndex(String colName,String value){	//指定列に指定値があれば最初の位置を返す。なければ-1を返す。
		for(int i=0;i<getContentSize();i++){
			if(getValue(i,colName)!=null && getValue(i,colName).equals(value))return i;
		}
		
		return -1;
	}
	
	public String toString(){	//内容表示
		String returnStr=null;
		
		for(int i=0;i<header.size();i++){
			if(i==0)returnStr=header.get(i);
			else returnStr+=","+header.get(i);
		}
		
		returnStr+="\n";
		for(HashMap<String,String> curMap:content){
			for(int i=0;i<header.size();i++){
				if(i==0){
					if(curMap.containsKey(header.get(i))){
						returnStr+=curMap.get(header.get(i));
					}else{
					}
				}else{
					if(curMap.containsKey(header.get(i))){
						returnStr+=","+curMap.get(header.get(i));
					}else{
						returnStr+=",";
					}
				}
			}
			returnStr+="\n";
		}
		
		return returnStr;
	}
}
