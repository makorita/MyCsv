import java.io.*;
import java.util.*;

import org.apache.poi.*;
import org.apache.poi.ss.formula.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.openxml4j.exceptions.*;
import org.apache.poi.xssf.usermodel.*;

public class NExcelIO{
	/*
	public static ArrayList<NExcel> loadExcel(String srcPath) throws Exception{	//Excelロード
		Workbook wb=WorkbookFactory.create(new FileInputStream(srcPath));
		
	}
	*/
	
	public static NExcel loadExcel(String srcPath,String sheetName) throws Exception{	//Excel単シートロード
		NExcel returnExl=new NExcel();
		
		FileInputStream in=new FileInputStream(srcPath)
		Workbook wb = WorkbookFactory.create(in);
		Sheet sheet=wb.getSheet(sheetName);
		
		ArrayList<String> header=new ArrayList<String>();
		Row headerRow=sheet.getRow(0);
		if(headerRow==null)return;
		for(int cellIndex=0;cellIndex<row.getLastCellNum();cellIndex++){
			Cell cell=row.getCell(cellIndex);
			if(cell==null)return;
			if(cell.getCellType()==CellType.BLANK || CellType.ERROR)return;
			
			String tmpHeaderStr=null;
			if(cell.getCellType()==CellType.STRING)tmpHeaderStr=cell.getStringCellValue();
			else if(cell.getCellType()==CellType.NUMERIC)tmpHeaderStr=String.format("%.2f",cell.getNumericCellValue());
			else if(cell.getCellType()==CellType.BOOLEAN)tmpHeaderStr=cell.getBooleanCellValue();
			header.add(tmpHeaderStr);
		}
		returnExl.setHeader(header);

		for(int rowIndex=1;rowIndex<=sheet.getLastRowNum();rowIndex++){	//rowの最大値は最大index
			Row row=sheet.getRow(rowIndex);
			if(row==null)continue;
			HashMap<String,String> curRow=new HashMap<String,String>();
			for(int cellIndex=0;cellIndex<row.getLastCellNum();cellIndex++){
				Cell cell=row.getCell(cellIndex);
				if(cell==null)continue;
				if(cell.getCellType()==CellType.BLANK || CellType.ERROR)continue;
				
				if(cell.getCellType()==CellType.STRING)System.out.println(cell.getStringCellValue());
			}
		}
		
		wb.close();
		in.close();
		
		return returnExl;
	}
}
