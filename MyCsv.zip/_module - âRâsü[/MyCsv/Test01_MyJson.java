import java.io.*;
import java.util.*;

public class Test01_MyJson{
/*
javac -cp "./;E:/program/_myLibrary/json-20240303.jar" Test01_MyJson.java
java -cp "./;E:/program/_myLibrary/json-20240303.jar" Test01_MyJson
*/	
	public static void main(String[] args) throws Exception{
		/*
		MyJson curJson=new MyJson();
		MyJson child1=new MyJson();
		child1.setValue("テスト");
		curJson.put("test",child1);
		
		MyJson child2=new MyJson();
		child2.setValue("テスト2");
		curJson.put("test2",child2);
		
		MyJson child3=new MyJson();
		child3.setValue("テスト3");
		curJson.put("test3",child3);
		
		MyJson rootJson=new MyJson();
		rootJson.put("child",curJson);
		
		rootJson.saveJson("test.json");
		*/
		MyJson curJson=new MyJson();
		curJson.loadJson("test.json");
		//curJson.saveJson("test3.json");
		curJson.saveSerialize("test.db");
		
		curJson=MyJson.loadSerialze("test.db");
		curJson.saveJson("test4.json");
	}
}
