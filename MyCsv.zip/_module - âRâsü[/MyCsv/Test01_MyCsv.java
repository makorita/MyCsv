import java.io.*;
import java.util.*;

public class Test01_MyCsv{
/*
javac -cp "./;E:/program/_myLibrary/poi-bin-5.2.3/*" Test01_MyCsv.java
java -cp "./;E:/program/_myLibrary/poi-bin-5.2.3/*" Test01_MyCsv
*/	
	public static void main(String[] args) throws Exception{
		if(false){
			MyCsv curCsv=new MyCsv();
			curCsv.loadExcel("test.xlsx","test");
			String rowStr=curCsv.getRowStr(0);
			System.out.println(rowStr);
		}
		
		if(false){
			MyCsv curCsv=new MyCsv();
			curCsv.addRow("aaa:::AAA,bbb:::BBB,ccc:::CCC,ddd:::DDD,出力名:::test1.xlsx");
			curCsv.showAll();
		}
		
		if(false){
			MyCsv curCsv=new MyCsv();
			curCsv.loadExcel("test.xlsx","test");
			MyCsv returnCsv=curCsv.removeDuplicate();
			returnCsv.showAll();
		}
		
		if(true){
			MyCsv curCsv=new MyCsv();
			curCsv.loadExcel("test.xlsx","test");
			MyCsv returnCsv=curCsv.extractSequence("ddd");
			returnCsv.showAll();
		}
		
	}
}
