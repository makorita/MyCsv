import java.io.*;
import java.util.*;

public class Test01_BCL{
/*
javac -cp "./;lib/*" Test01_BCL.java
java -cp "./;lib/*" Test01_BCL
*/	
	public static void main(String[] args) throws Exception{
		if(true){
			double upper = BetaConfidenceLimit.upperConfidenceLimit(4.0, 6, 0.95);
			System.out.println(upper);
			upper = BetaConfidenceLimit.upperConfidenceLimit(4.0, 4, 0.95);
			System.out.println(upper);
			upper = BetaConfidenceLimit.upperConfidenceLimit(0, 0, 0.95);
			System.out.println(upper);
		}
	}
}
