import org.apache.commons.math3.distribution.BetaDistribution;

public class BetaConfidenceLimit{
	/**
	 * Clopper-Pearson法（近似）による信頼区間の上限値を求める
	 * 引き分けを0.5勝として扱います。
	 *
	 * @param pseudoWins 勝ち＋引き分け×0.5（例：3勝2引き分け→4.0）
	 * @param trials 試行回数（整数）
	 * @param confidenceLevel 信頼係数（例: 0.95 → 95%信頼区間）
	 * @return 真の勝率の信頼区間上限（0～1）
	 */
	public static double upperConfidenceLimit(double pseudoWins, double trials, double confidenceLevel) {
		if (trials <= 0){
			throw new IllegalArgumentException("1回以上の試行回数である必要があります。");
		}
		if (pseudoWins < 0 || pseudoWins > trials) {
			throw new IllegalArgumentException("勝ちの数は0以上試行回数以下である必要があります。");
		}
		
		if (pseudoWins == trials)return 1.0;
		
		double alpha = 1 - confidenceLevel;
		BetaDistribution beta = new BetaDistribution(pseudoWins + 1, trials - pseudoWins);
		return beta.inverseCumulativeProbability(1 - alpha / 2);
	}
}
