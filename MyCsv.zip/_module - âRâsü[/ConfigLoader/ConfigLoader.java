import java.io.*;
import java.util.*;

public class ConfigLoader{
/*
コンフィグファイル(=区切り)を読み込み、HashMapにキーと値を入れて返す
;はコメント
*/
	public static HashMap<String,String> loadConfig(String srcPath) throws Exception{	//コンフィグロード
		HashMap<String,String> returnMap=new HashMap<String,String>();
		
		BufferedReader br = new BufferedReader(new FileReader(srcPath));
		String line;
		while ((line = br.readLine()) != null) {
			if(line.matches(";.*"))continue;
			if(!line.matches(".+=.+"))continue;
			
			String[] word=line.split("=");
			returnMap.put(word[0],word[1]);
		}
		br.close();
		
		return returnMap;
	}
}
