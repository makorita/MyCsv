import java.io.*;
import java.util.*;

public class Test01_ConfigLoader{
	public static void main(String[] args) throws Exception{
		if(true){
			HashMap<String,String> curMap=ConfigLoader.loadConfig("config.txt");
			for(String key:curMap.keySet()){
				String value=curMap.get(key);
				System.out.println(key+","+value);
			}
		}
	}
}
