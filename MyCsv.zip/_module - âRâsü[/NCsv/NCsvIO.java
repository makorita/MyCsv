import java.io.*;
import java.util.*;

public class NCsvIO{
	public static NCsv loadCsv(String srcPath) throws Exception{	//csvロード
		NCsv returnCsv=new NCsv();
		
		BufferedReader br = new BufferedReader(new FileReader(srcPath));
		String tmpStr=br.readLine();
		String[] word=tmpStr.split(",");
		returnCsv.setHeader(new ArrayList<String>(Arrays.asList(word)));
		
		String line;
		while ((line = br.readLine()) != null) {
			HashMap curMap=new HashMap<String,String>();
			String[] word2=line.split(",");
			for(int i=0;i<word2.length;i++){
				if(word2[i].length()>0)curMap.put(word[i],word2[i]);
			}
			returnCsv.addRow(curMap);
		}
		br.close();
		
		return returnCsv;
	}
	
	public static void saveCsv(NCsv curCsv,String dstPath) throws Exception{	//csv保存
		PrintWriter wr=new PrintWriter(new FileWriter(dstPath));
		
		for(int i=0;i<curCsv.getHeaderSize();i++){
			if(i==0)wr.print(curCsv.getHeader(i));
			else wr.print(","+curCsv.getHeader(i));
		}
		wr.println();
		
		for(int i=0;i<curCsv.getContentSize();i++){
			for(int j=0;j<curCsv.getHeaderSize();j++){
				if(j==0){
					if(curCsv.containsKey(i,curCsv.getHeader(j)))wr.print(curCsv.getValue(i,curCsv.getHeader(j)));
				}else{
					if(curCsv.containsKey(i,curCsv.getHeader(j)))wr.print(","+curCsv.getValue(i,curCsv.getHeader(j)));
					else wr.print(",");
				}
			}
			wr.println();
		}
		
		wr.close();
	}
}
