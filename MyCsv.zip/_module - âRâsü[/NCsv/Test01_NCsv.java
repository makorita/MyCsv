import java.io.*;
import java.util.*;

public class Test01_NCsv{
/*
javac Test01_NCsv.java
java Test01_NCsv
*/	
	public static void main(String[] args) throws Exception{
		if(false){
			NCsv curCsv=new NCsv();
			ArrayList<String> headerList=new ArrayList<String>();
			headerList.add("test01");
			headerList.add("test02");
			headerList.add("test03");
			curCsv.setHeader(headerList);
			System.out.println(curCsv);
			
			System.out.println(curCsv.getHeader(1));
			System.out.println(curCsv.getHeaderSize());
			System.out.println(curCsv.containsHeader("test02"));
			curCsv.addHeader("test04");
			System.out.println(curCsv);
			curCsv.removeHeader("test02");
			System.out.println(curCsv);
		}
		
		if(false){
			NCsv curCsv=new NCsv();
			HashMap<String,String> tmpMap=new HashMap<String,String>();
			tmpMap.put("head01","value01");
			tmpMap.put("head02","value02");
			tmpMap.put("head03","value03");
			curCsv.addRow(tmpMap);
			System.out.println(curCsv);
			curCsv.removeRow(0);
			System.out.println(curCsv);
		}
		
		if(false){
			NCsv curCsv=new NCsv();
			HashMap<String,String> tmpMap=new HashMap<String,String>();
			tmpMap.put("head01","value01");
			tmpMap.put("head02","value02");
			tmpMap.put("head03","value03");
			curCsv.addRow(tmpMap);
			System.out.println(curCsv.getValue(0,"head02"));
			System.out.println(curCsv.containsKey(0,"head03"));
			System.out.println(curCsv.containsKey(0,"head04"));
			curCsv.setValue(0,"head04","value04");
			System.out.println(curCsv);
			curCsv.removeColValue(0,"head01");
			System.out.println(curCsv);
		}
		
		if(true){
			NCsv curCsv=new NCsv();
			HashMap<String,String> tmpMap=new HashMap<String,String>();
			tmpMap.put("head01","value01");
			tmpMap.put("head02","value02");
			tmpMap.put("head03","value03");
			curCsv.addRow(tmpMap);
			tmpMap.put("head01","value04");
			tmpMap.put("head02","value05");
			tmpMap.put("head03","value06");
			curCsv.addRow(tmpMap);
			System.out.println(curCsv);
			NDBIO.saveCsv(curCsv,"test01.csv");
			curCsv=NDBIO.loadCsv("test01.csv");
			System.out.println(curCsv);
		}
	}
}
