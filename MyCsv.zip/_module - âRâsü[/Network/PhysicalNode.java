import java.io.*;
import java.util.*;

public class PhysicalNode extends Node{
	String kikimei;
	String serialNum;
	String sisanNum;
	String product;
	String kubun;
	Address telnetAddr;
	String location;
	
	public PhysicalNode(){
	}
	
	public String getKikimei(){
		return kikimei;
	}
	
	public void setKikimei(String kikimei){
		this.kikimei=kikimei;
	}
	
	public String getSerialNum(){
		return serialNum;
	}
	
	public void setSerialNum(String serialNum){
		this.serialNum=serialNum;
	}
	
	public String getSisanNum(){
		return sisanNum;
	}
	
	public void setSisanNum(String sisanNum){
		this.sisanNum=sisanNum;
	}
	
	public String getProduct(){
		return product;
	}
	
	public void setProduct(String product){
		this.product=product;
	}
	
	public String getKubun(){
		return kubun;
	}
	
	public void setKubun(String kubun){
		this.kubun=kubun;
	}
	
	public Address getTelnetAddr(){
		return telnetAddr;
	}
	
	public void setTelnetAddr(Address telnetAddr){
		this.telnetAddr=telnetAddr;
	}
	
	public String getLocation(){
		return location;
	}
	
	public void setLocation(String location){
		this.location=location;
	}
	
	public void showAll(){
		if(getHostname()!=null)System.out.println(getHostname());
		if(getKikimei()!=null)System.out.println(getKikimei());
		if(getSerialNum()!=null)System.out.println(getSerialNum());
		if(getSisanNum()!=null)System.out.println(getSisanNum());
		if(getProduct()!=null)System.out.println(getProduct());
		if(telnetAddr!=null)telnetAddr.showAll();
		if(getLocation()!=null)System.out.println(getLocation());
		System.out.println();
	}
}
