import java.io.*;
import java.util.*;

public class Balancer implements Serializable{
	private String name;
	private Address vip;
	private Port port;
	private String poolName;	//�I�u�W�F�N�g�̓����o�[�Ɏ����Ȃ�
	private String iRuleName;	//�I�u�W�F�N�g�̓����o�[�Ɏ����Ȃ�
	private String snatName;
	
	public Balancer(String name,Address vip,Port port,String poolName,String iRuleName,String snatName){
		this.name=name;
		this.vip=vip;
		this.port=port;
		this.poolName=poolName;
		this.iRuleName=iRuleName;
		this.snatName=snatName;
	}
	
	public String getName(){
		return name;
	}
	
	public Address getVip(){
		return vip;
	}
	
	public Port getPort(){
		return port;
	}
	
	public String getPoolName(){
		return poolName;
	}
	
	public String getIRuleName(){
		return iRuleName;
	}
	
	public String getSnatName(){
		return snatName;
	}
	
	public void showAll(){
		System.out.println("name:"+name);
		System.out.print("vip:");
		vip.showAll();
		System.out.print("port:");
		port.showAll();
		System.out.println("poolName:"+poolName);
		System.out.println("iRuleName:"+iRuleName);
		System.out.println("snatName:"+snatName);
		System.out.println();
	}
}
