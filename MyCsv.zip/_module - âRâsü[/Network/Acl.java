import java.io.*;
import java.util.*;

public class Acl implements Serializable{
	private String name;
	private LinkedList<AclLine> aclList;
	
	public Acl(String name){
		this.name=name;
		aclList=new LinkedList<AclLine>();
	}
	
	public void addAclLine(AclLine aclLine){
		aclList.add(aclLine);
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name=name;
	}
	
	public LinkedList<AclLine> getAclList(){
		return aclList;
	}
	
	public AclLine matchSingleLayer(Address srcAddr,Address dstAddr){
		for(AclLine curAclLine:aclList){
			if(curAclLine.matchSingleLayer(srcAddr,dstAddr))return curAclLine;
		}
		
		return null;
	}
	
	public void showAll(){
		System.out.println("###AccessListName:"+getName());
		for(AclLine curAclLine:getAclList())curAclLine.showAll();
	}
}
