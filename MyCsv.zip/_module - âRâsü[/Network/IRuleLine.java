import java.io.*;
import java.util.*;

public class IRuleLine implements Serializable{
	String jouken;
	String action;
	
	public IRuleLine(String jouken,String action){
		this.jouken=jouken;
		this.action=action;
	}
	
	public String getJouken(){
		return jouken;
	}
	
	public String getAction(){
		return action;
	}
	
	public void showAll(){
		System.out.println("����:");
		System.out.println(jouken);
		System.out.println("Action:");
		System.out.println(action);
	}
}
