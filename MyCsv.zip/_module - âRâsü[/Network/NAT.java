import java.io.*;
import java.util.*;

public class NAT implements Serializable{
	Address originalIP;
	Address changedIP;
	String in_out;
	String src_dst;
	boolean addRoute;
	String configLine;
	
	public NAT(){
		setAddRoute(false);
	}
	
	public Address getOriginalIP(){
		return originalIP;
	}
	
	public void setOriginalIP(Address originalIP){
		this.originalIP=originalIP;
	}
	
	public Address getChangedIP(){
		return changedIP;
	}
	
	public void setChangedIP(Address changedIP){
		this.changedIP=changedIP;
	}
	
	public String getIn_out(){
		return in_out;
	}
	
	public void setIn_out(String in_out){
		this.in_out=in_out;
	}
	
	public String getSrc_dst(){
		return src_dst;
	}
	
	public void setSrc_dst(String src_dst){
		this.src_dst=src_dst;
	}
	
	public boolean getAddRoute(){
		return addRoute;
	}
	
	public void setAddRoute(boolean addRoute){
		this.addRoute=addRoute;
	}
	
	public String getConfigLine(){
		return configLine;
	}
	
	public void setConfigLine(String configLine){
		this.configLine=configLine;
	}
	
	public void showAll(){
		if(getIn_out()!=null)System.out.println(getIn_out());
		if(getSrc_dst()!=null)System.out.println(getSrc_dst());
		if(getOriginalIP()!=null)originalIP.showAll();
		if(getChangedIP()!=null)changedIP.showAll();
		if(getAddRoute())System.out.println("add-route:true");
		if(getConfigLine()!=null)System.out.println(getConfigLine());
	}
}
