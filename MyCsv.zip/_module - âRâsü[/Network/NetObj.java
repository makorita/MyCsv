import java.io.*;
import java.util.*;

public class NetObj implements Serializable{
	String name;
	LinkedList<Address> addrList;
	LinkedList<Port> portList;
	LinkedList<NetObj> childList;
	
	public NetObj(){
		addrList=new LinkedList<Address>();
		portList=new LinkedList<Port>();
		childList=new LinkedList<NetObj>();
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name=name;
	}
	
	public LinkedList<Address> getAddrList(){
		return addrList;
	}
	
	public void addAddress(Address curAddr){
		addrList.add(curAddr);
	}
	
	public void setAddrList(LinkedList<Address> addrList){
		this.addrList=addrList;
	}
	
	public LinkedList<Port> getPortList(){
		return portList;
	}
	
	public void addPort(Port curPort){
		portList.add(curPort);
	}
	
	public void setPortList(LinkedList<Port> portList){
		this.portList=portList;
	}
	
	public LinkedList<NetObj> getChildList(){
		return childList;
	}
	
	public void addChild(NetObj curChild){
		childList.add(curChild);
	}
	
	public void setChildList(LinkedList<NetObj> childList){
		this.childList=childList;
	}
	
	public void showAll(){
		if(name!=null)System.out.println(name);
		for(Address curAddr:addrList){
			curAddr.showAll();
		}
		for(Port curPort:portList){
			curPort.showAll();
		}
		for(NetObj curChild:childList){
			//�z�|���̂Ŗ��O�����ɂ��Ă���
			System.out.println(curChild.getName());
		}
	}
}
