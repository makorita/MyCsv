public class TestAddress{
	public static void main(String[] args){
		//staticメソッド
		{
//			System.out.println("1:"+Address.isLegalAddrStr("0.0.0.0/0"));
//			System.out.println("2:"+Address.isLegalAddrStr("0.0.0.0"));
//			System.out.println("3:"+Address.isLegalAddrStr("192.168.0.1"));
//			System.out.println("4:"+Address.isLegalAddrStr("192.168.0.1/24"));
//			System.out.println("5:"+Address.isLegalAddrStr("192.168.0.999/24"));
//			System.out.println("6:"+Address.isLegalAddrStr("0.0.0"));
//			System.out.println("7:"+Address.isLegalAddrStr("0.0.0.0/32"));
//			System.out.println("8:"+Address.isLegalAddrStr("0.0.0.0/33"));

//			System.out.println("1:"+Long.toBinaryString(Address.getBit("255.255.255.0/0")));
//			System.out.println("2:"+Long.toBinaryString(Address.getBit("255.255.255.0")));
//			System.out.println("3:"+Long.toBinaryString(Address.getBit("255.255.0.0")));
//			System.out.println("4:"+Long.toBinaryString(Address.getBit("0.255.255.255")));
//			System.out.println("5:"+Long.toBinaryString(Address.getBit("192.168.0.1/24")));

//			System.out.println("1:"+Long.toBinaryString(Address.getBit(0)));
//			System.out.println("2:"+Long.toBinaryString(Address.getBit(8)));
//			System.out.println("3:"+Long.toBinaryString(Address.getBit(24)));
//			System.out.println("4:"+Long.toBinaryString(Address.getBit(33)));

//			String bin=null;
//			long tmpLong;
//			bin="11111111111111111111111111111111";
//			tmpLong=Long.parseLong(bin, 2);
//			System.out.println("1:"+Address.getStrExp(tmpLong));
//			bin="10000000000000000000000000000001";
//			tmpLong=Long.parseLong(bin, 2);
//			System.out.println("2:"+Address.getStrExp(tmpLong));
//			tmpLong=0;
//			System.out.println("3:"+Address.getStrExp(tmpLong));

//			System.out.println("1:"+Address.isLegalMask(Address.getBit("0.0.0.0")));
//			System.out.println("2:"+Address.isLegalMask(Address.getBit("255.255.255.255")));
//			System.out.println("3:"+Address.isLegalMask(Address.getBit("255.255.255.0")));
//			System.out.println("4:"+Address.isLegalMask(Address.getBit("0.0.0.255")));
//			System.out.println("5:"+Address.isLegalMask(Address.getBit("192.168.0.1")));
//			System.out.println("6:"+Address.isLegalMask(-1));
//			System.out.println("7:"+Address.isLegalMask(Long.parseLong("111111111111111111111111111111111",2)));	//33ビット

//			System.out.println("1:"+Address.isLegalMask("0.0.0.0"));
//			System.out.println("2:"+Address.isLegalMask("255.255.255.255"));
//			System.out.println("3:"+Address.isLegalMask("255.255.255.0"));
//			System.out.println("4:"+Address.isLegalMask("0.0.0.255"));
//			System.out.println("5:"+Address.isLegalMask("192.168.0.1"));

//			System.out.println("1:"+Address.getMaskLength(Address.getBit("0.0.0.0")));
//			System.out.println("2:"+Address.getMaskLength(Address.getBit("255.255.255.255")));
//			System.out.println("3:"+Address.getMaskLength(Address.getBit("255.255.255.0")));
//			System.out.println("4:"+Address.getMaskLength(Address.getBit("255.255.255.192")));
//			System.out.println("5:"+Address.getMaskLength(Address.getBit("0.0.0.255")));
//			System.out.println("6:"+Address.getMaskLength(Address.getBit("192.168.0.1")));

//			System.out.println("1:"+Address.getMaskLength("0.0.0.0"));
//			System.out.println("2:"+Address.getMaskLength("255.255.255.255"));
//			System.out.println("3:"+Address.getMaskLength("255.255.255.0"));
//			System.out.println("4:"+Address.getMaskLength("255.255.255.192"));
//			System.out.println("5:"+Address.getMaskLength("0.0.0.255"));

//			System.out.println("1:"+Address.getStrExp(Address.getBit("10.1.1.1"),Address.getBit("255.255.255.128")));

//			System.out.println("1:"+Address.getMaskStr(8));
//			System.out.println("2:"+Address.getMaskStr(24));
//			System.out.println("3:"+Address.getMaskStr(28));
//			System.out.println("4:"+Address.getMaskStr(32));

//			System.out.println("1:"+Address.mask2wild("255.255.255.0"));
//			System.out.println("2:"+Address.mask2wild("0.0.0.255"));
		}
		
		//インスタンス
		{
//			Address curAddr=null;
//			curAddr=new Address("192.168.10.1");
//			System.out.println("1:"+Address.getStrExp(curAddr.getAddress())+","+Address.getStrExp(curAddr.getMask()));
//			curAddr=new Address("172.128.120.1/24");
//			System.out.println("2:"+Address.getStrExp(curAddr.getAddress())+","+Address.getStrExp(curAddr.getMask()));
//			curAddr=new Address("any");
//			System.out.println("3:"+Address.getStrExp(curAddr.getAddress())+","+Address.getStrExp(curAddr.getMask()));
//			//curAddr=new Address("10.172.128.120.1/24");
//			//System.out.println("4:"+Address.getStrExp(curAddr.getAddress())+","+Address.getStrExp(curAddr.getMask()));
//			curAddr=new Address("192.168.10.1",26);
//			System.out.println("4:"+Address.getStrExp(curAddr.getAddress())+","+Address.getStrExp(curAddr.getMask()));
//			curAddr=new Address("192.168.10.1","255.255.255.128");
//			System.out.println("5:"+Address.getStrExp(curAddr.getAddress())+","+Address.getStrExp(curAddr.getMask()));
//			System.out.println("6:"+Address.getStrExp(curAddr.getAddress())+","+curAddr.getMaskLength());
//			//curAddr=new Address("192.168.10.1","0.0.0.255");
//			//System.out.println("6:"+Address.getStrExp(curAddr.getAddress())+","+Address.getStrExp(curAddr.getMask()));
//			System.out.println("7:"+curAddr.getSimpleStrExp()+","+curAddr.getStrExp()+","+curAddr);
//			curAddr.showAll();

//			Address curAddr=null;
//			curAddr=new Address("192.168.10.1/26");
//			System.out.println("1:"+Address.getStrExp(curAddr.getWild()));
//			System.out.println("2:"+Address.getStrExp(curAddr.getNetwork())+","+Address.getStrExp(curAddr.getBroadcast()));

			Address addr1=new Address("192.168.10.1/26");
			Address addr2=new Address("192.168.10.1/24");
			System.out.println("1:"+addr1.equals(addr2)+","+addr1.exactlyEquals(addr2));
			System.out.println("2:"+addr1.contains(addr2)+","+addr2.contains(addr1));
		}
	}
}