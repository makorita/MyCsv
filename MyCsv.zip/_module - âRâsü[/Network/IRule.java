import java.io.*;
import java.util.*;

public class IRule implements Serializable{
	String name;
	LinkedList<IRuleLine> iRuleLineList;
	
	public IRule(String name){
		this.name=name;
		iRuleLineList=new LinkedList<IRuleLine>();
	}
	
	public String getName(){
		return name;
	}
	
	public void addIRuleLine(IRuleLine iRuleLine){
		iRuleLineList.add(iRuleLine);
	}
	
	public LinkedList<IRuleLine> getIRuleLineList(){
		return iRuleLineList;
	}
	
	public void showAll(){
		System.out.println("iRule����:"+name);
		for(IRuleLine curIRuleLine:iRuleLineList){
			curIRuleLine.showAll();
			System.out.println("----------");
		}
		System.out.println("��������������������");
	}
}
