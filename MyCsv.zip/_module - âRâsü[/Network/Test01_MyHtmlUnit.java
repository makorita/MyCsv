public class Test01_MyHtmlUnit{
	public static void main(String[] args){
		MyHtmlUnit myUnit=new MyHtmlUnit();
		myUnit.movePage("https://www.google.co.jp/");
		myUnit.writeTmpHTML();
	}
}