import java.io.*;
import java.util.*;

public class Port implements Serializable{
	//����|�[�g
	static final int ANY=-1;
	static final int OTHER=0;
	
	String protocol;
	int portNum;
	String range;
	public Port(String protocol,int portNum){
		if(!protocoLegalCheck(protocol)){
			System.out.println("Illegal protocolStr:"+protocol);
			System.exit(0);
		}
		this.protocol=protocol;
		this.portNum=portNum;
	}
	
	public Port(String protocol,String port){
		protocol=protocol.toUpperCase();
		if(!protocoLegalCheck(protocol)){
			System.out.println("Illegal protocolStr:"+protocol);
			System.exit(0);
		}
		this.protocol=protocol;
		portStr2portNum(port);
	}
	
	public Port(String protocol,String rangeBegin,String rangeEnd){
		protocol=protocol.toUpperCase();
		if(!protocoLegalCheck(protocol)){
			System.out.println("Illegal protocolStr:"+protocol);
			System.exit(0);
		}
		this.protocol=protocol;
		if(rangeBegin.equals("gt"))range="gt "+portStr2portNum(rangeEnd);
		else range=portStr2portNum(rangeBegin)+" "+portStr2portNum(rangeEnd);
	}
	
	public boolean protocoLegalCheck(String protocolStr){
		if(protocolStr.equals("IP"))return true;
		if(protocolStr.equals("TCP"))return true;
		if(protocolStr.equals("UDP"))return true;
		if(protocolStr.equals("ICMP"))return true;
		if(protocolStr.equals("AH"))return true;
		if(protocolStr.equals("ESP"))return true;
		if(protocolStr.equals("ANY"))return true;
		
		return false;
	}
	
	public String getProtocol(){
		return protocol;
	}
	
	public int getPortNum(){
		return portNum;
	}
	
	public boolean equals(Port taisyouPort){
		if(getProtocol().equals(taisyouPort.getProtocol()) && getPortNum()==taisyouPort.getPortNum())return true;
		else return false;
	}
	
	public String toString(){
		return getProtocol()+"/"+portNum;
	}
	
	public String getRange(){
		return range;
	}
	
	public void setRange(String range){
		this.range=range;
	}
	
	public void showAll(){
		if(getRange()==null)System.out.println(protocol+":"+portNum);
		else System.out.println(protocol+":"+getRange());
	}
	
	public static int portStr2portNum(String portStr){
		if(portStr.matches("\\d+"))return Integer.parseInt(portStr);
		portStr=portStr.toUpperCase();
		if(portStr.equals("DISCARD"))return 9;
		if(portStr.equals("FTP-DATA"))return 20;
		if(portStr.equals("FTP"))return 21;
		if(portStr.equals("SSH"))return 22;
		if(portStr.equals("TELNET"))return 23;
		if(portStr.equals("SMTP"))return 25;
		if(portStr.equals("DNS"))return 53;
		if(portStr.equals("BOOTPS"))return 67;
		if(portStr.equals("BOOTPC"))return 68;
		if(portStr.equals("TFTP"))return 69;
		if(portStr.equals("HTTP"))return 80;
		if(portStr.equals("WWW"))return 80;
		if(portStr.equals("SUNRPC"))return 111;
		if(portStr.equals("NTP"))return 123;
		if(portStr.equals("NETBIOS-NS"))return 137;
		if(portStr.equals("NETBIOS-DGM"))return 138;
		if(portStr.equals("NETBIOS-SS"))return 139;
		if(portStr.equals("SNMP"))return 161;
		if(portStr.equals("SNMPTRAP"))return 162;
		if(portStr.equals("XDMCP"))return 177;
		if(portStr.equals("HTTPS"))return 443;
		if(portStr.equals("ISAKMP"))return 500;
		if(portStr.equals("EXEC"))return 512;
		if(portStr.equals("LOGIN"))return 513;
		if(portStr.equals("SYSLOG"))return 514;
		if(portStr.equals("CMD"))return 514;
		if(portStr.equals("ANY"))return ANY;
		else{
			System.out.println("Illegal PortStr:"+portStr);
			System.exit(0);
		}
		
		return 0;
	}
}
