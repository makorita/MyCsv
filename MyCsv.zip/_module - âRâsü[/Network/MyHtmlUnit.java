import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.*;

import org.apache.commons.logging.*;

import com.gargoylesoftware.htmlunit.BrowserVersion.BrowserVersionBuilder;
import com.gargoylesoftware.htmlunit.*;
import com.gargoylesoftware.htmlunit.html.*;

public class MyHtmlUnit {
	WebClient wc;	//Unit�{��
	HtmlPage page;	//�y�[�W

	public MyHtmlUnit() {
		LogFactory.getFactory().setAttribute("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.NoOpLog");
		java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF); 
		java.util.logging.Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.OFF);

		wcInit();
	}

	public void wcInit() {
		BrowserVersionBuilder tmpBVBuilder=new BrowserVersionBuilder(BrowserVersion.INTERNET_EXPLORER);
		tmpBVBuilder.setUserLanguage("ja");
		tmpBVBuilder.setSystemLanguage("ja");
		tmpBVBuilder.setBrowserLanguage("ja");
		
		BrowserVersion tmpBrowserVersion=tmpBVBuilder.build();	//�V���߂�HtmlUnit�ł�BrowserVersion�̐ݒ�̎d��
		//System.out.println(tmpBrowserVersion.getBrowserLanguage());
		
		page=null;
		wc=new WebClient(tmpBrowserVersion);
		
		//�y�[�W�̕��@�������łȂ����߁A��O��f�������悭����B��������B
		wc.getOptions().setThrowExceptionOnFailingStatusCode(false);
		wc.getOptions().setThrowExceptionOnScriptError(false);
	}

	public void movePage(String url){
		try {
			page=(HtmlPage)wc.getPage(url);
			
		} catch (FailingHttpStatusCodeException e) {
			e.printStackTrace();
			if(true)System.exit(0);
		} catch (MalformedURLException e) {
			e.printStackTrace();
			if(true)System.exit(0);
		} catch (IOException e) {
			e.printStackTrace();
			if(true)System.exit(0);
		}
	}

	public void writeTmpHTML() {
		PrintWriter wr;
		try {
			//�����R�[�h�ɖ�肪�o��B���Ԃ�HTML�Ŏw�肳�ꂽText�ł͂Ȃ�ShiftJIS�ŕۑ������
			wr = new PrintWriter("�A�E�g�v�b�g_�ꎞ.html");
			wr.println(page.asXml());
			wr.close();
		} catch (IOException e) {
			e.printStackTrace();
			if(true)System.exit(0);
		}
	}
}
