import java.io.*;
import java.util.*;

public class Address{
	private long address;	//ビット列列
	private long mask;	//ビット列列
	
	public Address(String addrStr){	//アドレス形式。マスク長のないものは/32で生成
		if(addrStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")){
			address=getBit(addrStr);
			String bin = "11111111111111111111111111111111";
			mask = Long.parseLong(bin, 2);
		}else if(addrStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}/\\d{1,2}")){
			String[] word=addrStr.split("/");
			address=Address.getBit(word[0]);
			mask=Address.getBit(Integer.parseInt(word[1]));
		}else if(addrStr.matches("Any|any|ANY")){
			address=Address.getBit("0.0.0.0");
			mask=0;
		}else{
			System.out.println("Illegal AddrStr:"+addrStr);
			System.exit(0);
		}
	}
	
	public Address(String addrStr,int maskLength){	//アドレス形式とマスク長で生成
		address=Address.getBit(addrStr);
		mask=Address.getBit(maskLength);
	}
	
	public Address(String addrStr,String maskStr){	//アドレス形式のアドレス＋マスクで生成
		if(!Address.isLegalMask(maskStr)){
			System.out.println("Illegal Mask:"+maskStr);
			System.exit(0);
		}
		address=getBit(addrStr);
		mask=getBit(maskStr);
	}
	
	public long getAddress(){
		return address;
	}
	
	public long getMask(){
		return mask;
	}
	
	public int getMaskLength(){
		return Address.getMaskLength(getMask());
	}
	
	public long getWild(){
		long returnBit=~mask&Long.parseLong("11111111111111111111111111111111",2);
		return returnBit;
	}
	
	public long getNetwork(){	//ネットワークアドレス
		long returnBit=address&mask;
		return returnBit;
	}
	
	public long getBroadcast(){	//ブロードキャストアドレス
		long returnBit=address|getWild();
		return returnBit;
	}
	
	public boolean exactlyEquals(Address taisyouAddr){
		if(getAddress()==taisyouAddr.getAddress() && getMask()==taisyouAddr.getMask())return true;
		else return false;
	}
	
	public boolean equals(Address taisyouAddr){
		if(getAddress()==taisyouAddr.getAddress())return true;
		else return false;
	}
	
	public boolean contains(Address taisyouAddr){	//対象が自分のレンジに含まれるかどうか
		long thisBegin=getNetwork();
		long thisEnd=getBroadcast();
		long taisyouBegin=taisyouAddr.getNetwork();
		long taisyouEnd=taisyouAddr.getBroadcast();
		
		if(thisBegin<=taisyouBegin && thisEnd>=taisyouEnd)return true;
		else return false;
	}
	
	public String getSimpleStrExp(){
		return getStrExp(getAddress());
	}
	
	public String getStrExp(){
		return Address.getStrExp(getAddress(),getMask());
	}
	
	public String toString(){	//Detail表示
		return getStrExp();
	}
	
	public void showAll(){
		System.out.println(getStrExp());
	}
	
	public static String getStrExp(long tmpAddress){	//ビット列をアドレス形式に変換
		String returnStr=null;
		
		for(int i=0;i<4;i++){
			long tmpOct=tmpAddress&Long.parseLong("11111111", 2);
			//System.out.println(tmpInt);
			if(returnStr==null)returnStr=String.valueOf(tmpOct);
			else returnStr=tmpOct+"."+returnStr;
			
			if(i!=3)tmpAddress=tmpAddress>>>8;
		}
		
		return returnStr;
	}
	
	public static String getStrExp(long tmpAddress,long tmpMask){	//ビット列をアドレス形式に変換。アドレス＋マスク版
		String returnStr=getStrExp(tmpAddress);
		
		returnStr=returnStr+"/"+getMaskLength(tmpMask);
		
		return returnStr;
	}
	
	public static String getMaskStr(int maskLength){	//マスク長からアドレス形式を返す
		long maskLong=0L;
		for(int i=1;i<=32;i++){
			if(i<=maskLength)maskLong=maskLong|1;
			if(i!=32)maskLong=maskLong<<1;
		}
		
		//System.out.println(Long.toBinaryString(maskLong));
		return getStrExp(maskLong);
	}
	
	public static long getBit(String addrStr){	//アドレス形式をビット列に変換
		//リーガルチェック
		if(!isLegalAddrStr(addrStr)){
			System.out.println("Illegal Address:"+addrStr);
			System.exit(0);
		}
		
		long returnBit=0;
		
		String[] word1=addrStr.split("/");
		String[] word2=word1[0].split("\\.");
		for(int i=0;i<word2.length;i++){
			//System.out.println(word[i]);
			returnBit=returnBit|Long.parseLong(word2[i]);
			if(i<word2.length-1)returnBit=returnBit<<8;
		}
		
		return returnBit;
	}
	
	public static long getBit(int maskLength){	//マスク長をビット列に変換
		//リーガルチェック
		if(maskLength<0 || maskLength>32){
			System.out.println("Illegal maskLength:"+maskLength);
			System.exit(0);
		}
		
		long returnBit=0;
		for(int i=0;i<maskLength;i++){
			returnBit=returnBit|1l;
			if(i!=maskLength-1)returnBit=returnBit<<1;
			//System.out.println(Integer.toBinaryString(returnBit));
		}
		for(int i=0;i<32-maskLength;i++){
			returnBit=returnBit<<1;
			//System.out.println(Integer.toBinaryString(returnBit));
		}
		
		return returnBit;
	}
	
	public static int getMaskLength(String maskStr){	//アドレス形式のマスク長を返す
		long maskBit=Address.getBit(maskStr);
		
		return getMaskLength(maskBit);
	}
	
	public static int getMaskLength(long maskBit){	//ビット列のマスク長を返す
		int returnBit=32;
		if(!Address.isLegalMask(maskBit)){
			System.out.println("Illegal Mask:"+maskBit);
			System.exit(0);
		}
		
		for(int i=0;i<32;i++){
			if((maskBit&1)==0)returnBit--;
			else return returnBit;
			maskBit=maskBit>>>1;
		}
		
		return returnBit;
	}
	
	public static String mask2wild(String addrStr){	//マスク形式をワイルドカード形式に変換
		long tmpBit=getBit(addrStr);
		if(!Address.isLegalMask(tmpBit)){
			System.out.println("Illegal Mask:"+tmpBit);
			System.exit(0);
		}
		
		tmpBit=~tmpBit&Long.parseLong("11111111111111111111111111111111",2);
		return getStrExp(tmpBit);
	}
	
	public static boolean isLegalAddrStr(String addrStr){	//アドレス形式をチェック
		if(!addrStr.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}(/\\d{1,2})*"))return false;
		
		String[] word1=addrStr.split("/");
		String[] word2=word1[0].split("\\.");
		for(String curStr:word2){
			if(Integer.parseInt(curStr)<0)return false;
			if(Integer.parseInt(curStr)>255)return false;
		}
		
		if(word1.length>=2){
			if(Integer.parseInt(word1[1])<0)return false;
			if(Integer.parseInt(word1[1])>32)return false;
		}
		
		return true;
	}
	
	public static boolean isLegalMask(String maskStr){	//アドレス形式がマスク形式かチェック
		long maskBit=getBit(maskStr);
		
		return isLegalMask(maskBit);
	}
	
	public static boolean isLegalMask(long maskBit){	//ビット列がマスク形式かチェック
		if(maskBit<0)return false;
		long maxLong=Long.parseLong("11111111111111111111111111111111",2);
		if(maskBit>maxLong)return false;
		
		boolean checkBool=true;
		for(int i=0;i<32;i++){	//ビット列を下から確認。1度ビット列が立った後、0がきたらfalse
			if(checkBool && (maskBit&1)==1){
				checkBool=false;
			}else if(!checkBool && (maskBit&1)==0)return false;
			maskBit=maskBit>>>1;
		}
		
		return true;
	}
}
