import java.io.*;
import java.util.*;

public class Pool implements Serializable{
	//SLB�̐U�蕪����
	String name;
	LinkedList<Socket> realServerList;
	
	public Pool(String name){
		this.name=name;
		realServerList=new LinkedList<Socket>();
	}
	
	public void addRealServer(Socket realServer){
		realServerList.add(realServer);
	}
	
	public String getName(){
		return name;
	}
	
	public LinkedList<Socket> getRealServerList(){
		return realServerList;
	}
	
	//���`�F�b�N
	public boolean contains(Socket taisyouSocket){
		for(Socket mySocket:getRealServerList()){
			if(mySocket.equals(taisyouSocket))return true;
		}
		
		return false;
	}
	
	//���`�F�b�N
	public boolean equals(Pool taisyouPool){
		if(getRealServerList().size()!=taisyouPool.getRealServerList().size())return false;
		for(Socket otherSocket:taisyouPool.getRealServerList()){
			if(!contains(otherSocket))return false;
		}
		
		return true;
	}
	
	public void showAll(){
		System.out.println("poolName:"+name);
		for(Socket curSocket:realServerList){
			curSocket.showAll();
		}
		System.out.println();
	}
}
