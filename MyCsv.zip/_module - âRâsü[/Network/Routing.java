import java.io.*;
import java.util.*;

public class Routing implements Serializable{
	String syubetu;
	Address dstAddr;
	String srcIfName;
	String track;
	Address nexthop;
	int ad;
	String configLine;
	
	public Routing(){
		ad=1;
	}
	
	public String getSyubetu(){
		return syubetu;
	}
	
	public void setSyubetu(String syubetu){
		this.syubetu=syubetu;
	}
	
	public Address getDstAddr(){
		return dstAddr;
	}
	
	public void setDstAddr(Address dstAddr){
		this.dstAddr=dstAddr;
	}
	
	public String getSrcIfName(){
		return srcIfName;
	}
	
	public void setSrcIfName(String srcIfName){
		this.srcIfName=srcIfName;
	}
	
	public String getTrack(){
		return track;
	}
	
	public void setTrack(String track){
		this.track=track;
	}
	
	public Address getNexthop(){
		return nexthop;
	}
	
	public void setNexthop(Address nexthop){
		this.nexthop=nexthop;
	}

	public int getAd(){
		return ad;
	}
	
	public void setAd(int ad){
		this.ad=ad;
	}

	public String getConfigLine(){
		return configLine;
	}
	
	public void setConfigLine(String configLine){
		this.configLine=configLine;
	}
	
	public void showAll(){
		System.out.println("["+syubetu+"]");
		System.out.println("����:");
		dstAddr.showAll();
		if(srcIfName!=null)System.out.println(srcIfName);
		System.out.println("NextHop:");
		if(nexthop!=null)System.out.println(nexthop.getSimpleStrExp());
		if(track!=null)System.out.println("track:"+track);
		if(ad!=1)System.out.println("AD:"+ad);
		if(getConfigLine()!=null)System.out.println(getConfigLine());
	}
}
