import java.io.*;
import java.util.*;

public class I_F implements Serializable{
	private String ifName;
	private Address ip;
	private LinkedList<Address> subIpList;
	private Address vip;
	private String inAclName;
	private String outAclName;
	
	public I_F(){
		subIpList=new LinkedList<Address>();
	}
	
	public String getIfName(){
		return ifName;
	}
	
	public void setIfName(String ifName){
		this.ifName=ifName;
	}
	
	public Address getIp(){
		return ip;
	}
	
	public void setIp(Address ip){
		this.ip=ip;
	}
	
	public LinkedList<Address> getSubIpList(){
		return subIpList;
	}
	
	public void addSubIp(Address subIp){
		subIpList.add(subIp);
	}
	
	public Address getVip(){
		return vip;
	}
	
	public void setVip(Address vip){
		this.vip=vip;
	}
	
	public String getInAclName(){
		return inAclName;
	}
	
	public void setInAclName(String inAclName){
		this.inAclName=inAclName;
	}
	
	public String getOutAclName(){
		return outAclName;
	}
	
	public void setOutAclName(String outAclName){
		this.outAclName=outAclName;
	}
	
	public void showAll(){
		System.out.println(getIfName());
		if(ip!=null){
			System.out.println("ip:");
			ip.showAll();
		}
		if(subIpList.size()>0)System.out.println("subIp:");
		for(Address curAddr:subIpList)curAddr.showAll();
		if(vip!=null){
			System.out.println("vip:");
			vip.showAll();
		}
		if(getInAclName()!=null)System.out.println("InAcl:"+getInAclName());
		if(getOutAclName()!=null)System.out.println("OutAcl:"+getOutAclName());
	}
}
