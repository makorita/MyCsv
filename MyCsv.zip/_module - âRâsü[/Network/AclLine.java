import java.io.*;
import java.util.*;

public class AclLine implements Serializable{
	private String name;
	private String remark;
	private String protocol;
	private NetObj srcAddrObj;
	private NetObj srcPortObj;
	private NetObj dstAddrObj;
	private NetObj dstPortObj;
	private boolean permitFlag;
	private boolean established;
	private boolean logFlag;
	private String configLine;
	
	public AclLine(){
		permitFlag=true;
		established=false;
		logFlag=false;
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name=name;
	}
	
	public String getRemark(){
		return remark;
	}
	
	public void setRemark(String remark){
		this.remark=remark;
	}
	
	public String getProtocol(){
		return protocol;
	}
	
	public void setProtocol(String protocol){
		protocol=protocol.toUpperCase();
		this.protocol=protocol;
	}
	
	public NetObj getSrcAddrObj(){
		return srcAddrObj;
	}
	
	public void addSrcAddr(Address curAddr){
		if(srcAddrObj==null)srcAddrObj=new NetObj();
		srcAddrObj.addAddress(curAddr);
	}
	
	public void setSrcAddrObj(NetObj srcAddrObj){
		this.srcAddrObj=srcAddrObj;
	}
	
	public NetObj getSrcPortObj(){
		return srcPortObj;
	}
	
	public void addSrcPort(Port curPort){
		if(srcPortObj==null)srcPortObj=new NetObj();
		srcPortObj.addPort(curPort);
	}
	
	public void setSrcPortObj(NetObj srcPortObj){
		this.srcPortObj=srcPortObj;
	}
	
	public NetObj getDstAddrObj(){
		return dstAddrObj;
	}
	
	public void addDstAddr(Address curAddr){
		if(dstAddrObj==null)dstAddrObj=new NetObj();
		dstAddrObj.addAddress(curAddr);
	}
	
	public void setDstAddrObj(NetObj dstAddrObj){
		this.dstAddrObj=dstAddrObj;
	}
	
	public NetObj getDstPortObj(){
		return dstPortObj;
	}
	
	public void addDstPort(Port curPort){
		if(dstPortObj==null)dstPortObj=new NetObj();
		dstPortObj.addPort(curPort);
	}
	
	public void setDstPortObj(NetObj dstPortObj){
		this.dstPortObj=dstPortObj;
	}
	
	public boolean getPermitFlag(){
		return permitFlag;
	}
	
	public void setPermitFlag(boolean permitFlag){
		this.permitFlag=permitFlag;
	}
	
	public boolean getEstablished(){
		return established;
	}
	
	public void setEstablished(boolean established){
		this.established=established;
	}
	
	public boolean getLogFlag(){
		return logFlag;
	}
	
	public void setLogFlag(boolean logFlag){
		this.logFlag=logFlag;
	}
	
	public String getConfigLine(){
		return configLine;
	}
	
	public void setConfigLine(String configLine){
		this.configLine=configLine;
	}
	
	public boolean partialMatchSingleLayer(Address srcAddr,Address dstAddr){	//�ꕔ�ł��}�b�`������true��Ԃ��BNetObj���ċA�������Ȃ��B
		if(getRemark()!=null)return false;
		
		boolean srcAddrFlag=false;
		for(Address curAddr:getSrcAddrObj().getAddrList()){
			if(curAddr.containsAddress(srcAddr) && getPermitFlag()){
				/*
				System.out.println("checkAddr:");
				srcAddr.showAll();
				System.out.println("aclAddr:");
				curAddr.showAll();
				*/
				srcAddrFlag=true;
				break;
			}
		}
		if(!srcAddrFlag)return false;
		
		boolean dstAddrFlag=false;
		for(Address curAddr:getDstAddrObj().getAddrList()){
			if(curAddr.containsAddress(dstAddr) && getPermitFlag()){
				/*
				System.out.println("checkAddr:");
				dstAddr.showAll();
				System.out.println("aclAddr:");
				curAddr.showAll();
				*/
				dstAddrFlag=true;
				break;
			}
		}
		if(!dstAddrFlag)return false;
		
		return true;
	}
	
	public boolean matchSingleLayer(Address srcAddr,Address dstAddr){	//Acl�Ɋ܂܂�邩�`�F�b�N�B�ċA�������Ȃ��B�A�h���X�̂݁B
		if(getRemark()!=null)return false;
		
		boolean srcAddrFlag=false;
		for(Address curAddr:getSrcAddrObj().getAddrList()){
			if(curAddr.includeAddress(srcAddr) && getPermitFlag()){
				/*
				System.out.println("checkAddr:");
				srcAddr.showAll();
				System.out.println("aclAddr:");
				curAddr.showAll();
				*/
				srcAddrFlag=true;
				break;
			}
		}
		if(!srcAddrFlag)return false;

		boolean dstAddrFlag=false;
		for(Address curAddr:getDstAddrObj().getAddrList()){
			if(curAddr.includeAddress(dstAddr) && getPermitFlag()){
				/*
				System.out.println("checkAddr:");
				dstAddr.showAll();
				System.out.println("aclAddr:");
				curAddr.showAll();
				*/
				dstAddrFlag=true;
				break;
			}
		}
		if(!dstAddrFlag)return false;
		
		return true;
	}
	
	public void showAll(){
		if(getName()!=null)System.out.println(getName());
		if(getRemark()!=null)System.out.println(getRemark());
		else{
			if(getProtocol()!=null)System.out.println(getProtocol());
			
			if(getSrcAddrObj()!=null){
				System.out.println("SrcAddr:");
				getSrcAddrObj().showAll();
			}
			if(getSrcPortObj()!=null){
				System.out.println("SrcPort:");
				getSrcPortObj().showAll();
			}
			if(getDstAddrObj()!=null){
				System.out.println("DstAddr:");
				getDstAddrObj().showAll();
			}
			if(getDstPortObj()!=null){
				System.out.println("DstPort:");
				getDstPortObj().showAll();
			}

			System.out.println("permit:"+getPermitFlag());
			if(getLogFlag())System.out.println("logFlag:"+getLogFlag());
		}
		if(getConfigLine()!=null)System.out.println(getConfigLine());
		System.out.println();
	}
}
