import java.io.*;
import java.util.*;

import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.openxml4j.exceptions.*;

public abstract class XMLManager{
	Document doc;
	Element rootElement;
	
	public abstract String getUniqueKey(Element curElement);
	
	public boolean isUnique(NodeList nodeList,Element curElement){
		String curKey=getUniqueKey(curElement);
		if(curKey==null)return false;
		
		for(int i=0;i<nodeList.getLength();i++){
			Element tmpElement=(Element)nodeList.item(i);
			String tmpKey=getUniqueKey(tmpElement);
			if(curKey.equals(tmpKey))return false;
		}
		
		return true;
	}
	
	public void createDocument(String rootTagName) throws Exception{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		doc = builder.newDocument();
		
		rootElement=doc.createElement(rootTagName);
		doc.appendChild(rootElement);
	}
	
	public void loadExcel(String dataTag,String srcPath,String sheetName,int startRowNum,int startColumnNum,int endColumnNum) throws Exception{
		Workbook wb = WorkbookFactory.create(new FileInputStream(srcPath));
		Sheet sheet=wb.getSheet(sheetName);
		LinkedList<String> tagList=new LinkedList<String>();
		for(int rowIndex=startRowNum;rowIndex<=sheet.getLastRowNum();rowIndex++){
			Row row=sheet.getRow(rowIndex);
			if(row==null)continue;
			
			Element dataElement=doc.createElement(dataTag);
			for(int cellIndex=startColumnNum;cellIndex<=endColumnNum;cellIndex++){
				Cell curCell=row.getCell(cellIndex);
				if(rowIndex==startRowNum){
					if(curCell==null || curCell.getCellType()==CellType.BLANK){
						System.out.println("Header Exception:"+row);
						System.exit(0);
					}
					
					String curCellStr=null;
					try{
						curCellStr=curCell.getStringCellValue();
					}catch(IllegalStateException e){
						curCellStr=String.format("%.0f",curCell.getNumericCellValue());

					}
					//System.out.println("#"+curCellStr+"#");
					tagList.add(XMLManager.getLegalTagName(curCellStr));
					continue;
				}
				
				if(curCell==null || curCell.getCellType()==CellType.BLANK)continue;
				String curCellStr=null;
				try{
					curCellStr=curCell.getStringCellValue();
				}catch(IllegalStateException e){
					curCellStr=String.format("%.0f",curCell.getNumericCellValue());

				}
				
				//System.out.println("#"+tagList.get(cellIndex-startColumnNum)+"#");
				Element curElement=doc.createElement(tagList.get(cellIndex-startColumnNum));
				dataElement.appendChild(curElement);
				curElement.appendChild(doc.createTextNode(curCellStr));
			}
			
			NodeList dataList=rootElement.getElementsByTagName(dataTag);
			//System.out.println(isUnique(dataList,dataElement));
			if(isUnique(dataList,dataElement))rootElement.appendChild(dataElement);
			
			//if(rowIndex==6)break;
		}
		
		wb.close();
	}
	
	public void loadXML(String srcPath) throws Exception{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		doc = builder.parse(new File(srcPath));
		rootElement=doc.getDocumentElement();
	}
	
	public void saveXML(String dstPath) throws Exception{
		TransformerFactory tfFactory = TransformerFactory.newInstance();
		Transformer tf = tfFactory.newTransformer();
		
		tf.setOutputProperty("indent", "yes");
		tf.setOutputProperty("encoding", "UTF-8");
		
		tf.transform(new DOMSource(doc), new StreamResult(new File(dstPath)));
	}
	
	public static String getLegalTagName(String curStr){
		curStr=curStr.replaceAll("\n","");
		curStr=curStr.replaceAll("\\(","_");
		curStr=curStr.replaceAll("�i","_");
		curStr=curStr.replaceAll("\\)","_");
		curStr=curStr.replaceAll("�j","_");
		curStr=curStr.replaceAll(" ","_");
		curStr=curStr.replaceAll("/","-");
		curStr=curStr.replaceAll("�E","-");
		
		return curStr;
	}
}
