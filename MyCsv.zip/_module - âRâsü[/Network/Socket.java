import java.io.*;
import java.util.*;

public class Socket implements Serializable{
	//Address��Port�̃y�A
	Address address;
	Port port;
	public Socket(Address address,Port port){
		this.address=address;
		this.port=port;
	}
	
	public Address getAddress(){
		return address;
	}
	
	public Port getPort(){
		return port;
	}
	
	public boolean equals(Address taisyouAddr,Port taisyouPort){
		if(getAddress().equals(taisyouAddr) && getPort().equals(taisyouPort))return true;
		else return false;
	}
	
	public boolean equals(Socket otherSocket){
		return equals(otherSocket.getAddress(),otherSocket.getPort());
	}
	
	public String toString(){
		return address.toString()+":"+port.toString();
	}
	
	public void showAll(){
		address.showAll();
		port.showAll();
	}
}
