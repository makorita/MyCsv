import java.util.*;

public class NJson{
	private String value;
	private LinkedHashMap<String,NJson> childMap;
	
	public NJson(){
		childMap=new LinkedHashMap<String,NJson>();
	}
	
	public String getValue(){
		return value;
	}
	
	public void setValue(String value){
		this.value=value;
		childMap.clear();
	}
	
	public int childSize(){
		return childMap.size();
	}
	
	public boolean containsChild(String childStr){
		return childMap.containsKey(childStr);
	}
	
	public NJson getChild(String key){
		return childMap.get(key);
	}
	
	public void put(String key,NJson childJson){
		value=null;
		childMap.put(key,childJson);
	}
	
	public String toPrettyJsonString(){
		return toPrettyJsonString(0);
	}
	
	private String toPrettyJsonString(int indent){
		StringBuilder sb=new StringBuilder();
		String ind="  ".repeat(indent);
		
		if(value!=null){
			sb.append("\"").append(escapeJson(value)).append("\"");
		}else{
			sb.append("{\n");
			Iterator<Map.Entry<String,NJson>> it=childMap.entrySet().iterator();
			while(it.hasNext()){
				Map.Entry<String,NJson> e=it.next();
				sb.append(ind).append("  ");
				sb.append("\"").append(escapeJson(e.getKey())).append("\":");
				sb.append(e.getValue().toPrettyJsonString(indent+1));
				if(it.hasNext())sb.append(",");
				sb.append("\n");
			}
			sb.append(ind).append("}");
		}
		
		return sb.toString();
	}
	
	private static String escapeJson(String s){
		if(s==null)return "";
		StringBuilder sb=new StringBuilder();
		for(char c:s.toCharArray()){
			switch(c){
				case '"':sb.append("\\\"");break;
				case '\\':sb.append("\\\\");break;
				case '\n':sb.append("\\n");break;
				case '\r':sb.append("\\r");break;
				case '\t':sb.append("\\t");break;
				default:
					if(c<0x20){
						sb.append(String.format("\\u%04x",(int)c));
					}else{
						sb.append(c);
					}
			}
		}
		return sb.toString();
	}
}
