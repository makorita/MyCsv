import java.io.*;
import java.util.*;

public class Test01_NJson{
	public static void main(String[] args) throws Exception{
		if(true){
			NJson curJson=NJsonParser.loadJson("test3.json");
			System.out.println(curJson.toPrettyJsonString());
		}
	}
}
