public class UCB{
/*
rewardは0.0～1.0に正規化しないと使用できない。
UCBの目的は「比較」
UCBの絶対値自体には意味がありません。重要なのは：
他のアームと比べてどれが最も有望かを判断するためのスコア
つまり、UCB値は「このアームを選ぶと良さそう」なスコアであって、
「何かの確率」でもなければ「合計が1になるべきもの」でもありません。
*/
	public static double normalizeReward(double reward, double minReward, double maxReward) {
		return (reward - minReward) / (maxReward - minReward);
	}

	public static double calculateNormalizedUCB(double averageReward, double count, double totalPlays) {
		if (count <= 0){
			throw new IllegalArgumentException("1回以上の試行回数である必要があります。");
		}

		double exploration = Math.sqrt(2 * Math.log(totalPlays) / count);
		return averageReward + exploration;
	}
}
