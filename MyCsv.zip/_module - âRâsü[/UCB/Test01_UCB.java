import java.io.*;
import java.util.*;

public class Test01_UCB{
	public static void main(String[] args) throws Exception{
		if(true){
			double upper=0;
			upper = UCB.calculateNormalizedUCB(2554.0/2615.0,2615.0,10000);
			System.out.println(upper);
			upper = UCB.calculateNormalizedUCB(1.0/1.0,1.0,10000);
			System.out.println(upper);
		}
	}
}
