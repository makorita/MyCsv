import java.io.*;
import java.util.*;

public class FileLoader{
/*
指定フォルダ以下のファイルをListで返す
containSetはファイル名に含まれるもの
jogaiSetはファイル名、フォルダ名に含まれないもの
*/
	static HashSet<String> containSet;
	static HashSet<String> jogaiSet;
	
	public static ArrayList<File> loadFileList(String rootPath,String containPath,String jogaiPath) throws Exception{	//ファイルのロード
		ArrayList<File> returnList=new ArrayList<File>();
		
		if(containPath!=null){
			containSet=new HashSet<String>();
			
			BufferedReader br = new BufferedReader(new FileReader(containPath));
			String line;
			while ((line = br.readLine()) != null) {
				if(line.matches(";.*"))continue;
				
				containSet.add(line);
			}
			br.close();
		}
		
		if(jogaiPath!=null){
			jogaiSet=new HashSet<String>();
			
			BufferedReader br = new BufferedReader(new FileReader(jogaiPath));
			String line;
			while ((line = br.readLine()) != null) {
				if(line.matches(";.*"))continue;
				
				jogaiSet.add(line);
			}
			br.close();
		}
		
		File rootDir=new File(rootPath);
		recursiveCheck(rootDir,returnList);
		
		return returnList;
	}
	
	public static void recursiveCheck(File curDir,ArrayList<File> returnList){
		File[] childList=curDir.listFiles();
		LABEL:for(File childFile:childList){
			if(jogaiSet!=null){
				for(String curStr:jogaiSet)if(childFile.getName().matches(".*"+curStr+".*"))continue LABEL;
			}
			if(childFile.isDirectory())recursiveCheck(childFile,returnList);
			else{
				if(jogaiSet!=null){
					for(String curStr:jogaiSet)if(childFile.getName().matches(".*"+curStr+".*"))continue LABEL;
				}
				if(containSet!=null){
					boolean containFlag=false;
					for(String curStr:containSet){
						if(childFile.getName().matches(".*"+curStr+".*")){
							containFlag=true;
							break;
						}
					}
					if(!containFlag)continue;
				}
				returnList.add(childFile);
			}
		}
	}
}
