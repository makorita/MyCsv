import java.util.*;

public class NJsonFilter{
	public static NJson matchKeyFilter(NJson srcJson,String searchStr){
		NJson returnJson=new NJson();
		
		Iterator<String> it=srcJson.childKeyIterator();
		int index=1;
		while(it.hasNext()){
			String curStr=it.next();
			if(curStr.matches(searchStr))returnJson.put(String.valueOf(index++),srcJson.getChild(curStr));
		}
		
		return returnJson;
	}
	
	public static NJson matchValueFilter(NJson srcJson,String keyStr,String searchStr){
		NJson returnJson=new NJson();
		
		Iterator<NJson> it=srcJson.childIterator();
		int index=1;
		while(it.hasNext()){
			NJson curJson=it.next();
			String curStr=curJson.getChild(keyStr).getValue();
			if(curStr.matches(searchStr))returnJson.put(String.valueOf(index++),curJson);
		}
		
		return returnJson;
	}
}
