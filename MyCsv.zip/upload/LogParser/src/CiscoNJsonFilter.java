import java.util.*;
import java.io.*;

public class CiscoNJsonFilter{
	public static HashMap<String,NJson> loadJson(String rootPath) throws Exception{
		HashMap<String,NJson> returnMap=new HashMap<String,NJson>();
		
		File rootDir=new File(rootPath);
		File[] fileList=rootDir.listFiles();
		for(File curFile:fileList){
			NJson curJson=NJsonParser.loadJson(curFile);
			returnMap.put(curJson.getChild("hostname").getValue(),curJson);
		}
		
		return returnMap;
	}
	
	public static NJson containProtocolFilter(NJson srcJson,String protocolStr){
		NJson returnJson=new NJson();
		
		Iterator<NJson> it=srcJson.childIterator();
		int index=1;
		while(it.hasNext()){
			NJson curJson=it.next();
			String curProtocol=curJson.getChild("プロトコル").getValue();
			if(curProtocol==null)returnJson.put(String.valueOf(index++),curJson);	//any扱い
			else if(curProtocol.equals("ip"))returnJson.put(String.valueOf(index++),curJson);
			else if(protocolStr==null)continue;
			else if(curProtocol.equals(protocolStr))returnJson.put(String.valueOf(index++),curJson);
		}
		
		return returnJson;
	}
	
	public static NJson ciscoIPFilter(NJson srcJson,String ipPath,String wildPath,Address searchedIP){
		NJson returnJson=new NJson();
		
		Iterator<NJson> it=srcJson.childIterator();
		int index=1;
		while(it.hasNext()){
			NJson curJson=it.next();
			String curIP=curJson.getChild(ipPath).getValue();
			long curWildBit=AddressUtility.getBit(curJson.getChild(wildPath).getValue());
			long curMaskBit=AddressUtility.reverseBit(curWildBit);
			String curMask=AddressUtility.getStrExp(curMaskBit);
			Address curAddr=new Address(curIP,curMask);
			if(AddressUtility.contains(curAddr,searchedIP))returnJson.put(String.valueOf(index++),curJson);
		}
		
		return returnJson;
	}
	
	public static NJson ciscoFWIPFilter(NJson aclListJson,String ogPath,NJson ogDB,Address searchedIP){
		NJson returnJson=new NJson();
		
		Iterator<NJson> it=aclListJson.childIterator();
		int index=1;
		while(it.hasNext()){
			NJson curAcl=it.next();
			if(curAcl.getChild(ogPath)==null)continue;
			
			String curOgName=curAcl.getChild(ogPath).getValue();
			NJson ogJson=ogDB.getChild(curOgName);
			boolean containFlag=recursiveContainIPCheck(ogJson,ogDB,searchedIP);
			if(containFlag)returnJson.put(String.valueOf(index++),curAcl);
		}
		
		return returnJson;
	}
	
	private static boolean recursiveContainIPCheck(NJson ogJson,NJson ogDB,Address searchedIP){
		Iterator<NJson> it=ogJson.getChild("child").childIterator();
		while(it.hasNext()){
			NJson memberJson=it.next();
			if(memberJson.getChild("ogType").getValue().equals("network")){
				Address tmpAddr=new Address(memberJson.getChild("ip").getValue(),memberJson.getChild("mask").getValue());
				if(AddressUtility.contains(tmpAddr,searchedIP))return true;
			}else if(memberJson.getChild("ogType").getValue().equals("group")){
				NJson childJson=ogDB.getChild(memberJson.getChild("ogName").getValue());
				boolean childBoolean=recursiveContainIPCheck(childJson,ogDB,searchedIP);
				if(childBoolean)return true;
			}else throw new IllegalArgumentException("想定外メンバーJson:"+memberJson.toPrettyJsonString());
		}
		
		return false;
	}
	
	public static NJson ciscoPortFilter(NJson srcJson,String portPath,Integer port){
		NJson returnJson=new NJson();
		
		Iterator<NJson> it=srcJson.childIterator();
		int index=1;
		while(it.hasNext()){
			NJson curJson=it.next();
			if(curJson.getChild(portPath)==null){	//any扱い
				returnJson.put(String.valueOf(index++),curJson);
				continue;
			}
			if(port==null)continue;
			
			String curPort=curJson.getChild(portPath).getValue();
			if(curPort.matches("eq \\d+")){
				String[] word=curPort.split(" ");
				if(port==Integer.parseInt(word[1]))returnJson.put(String.valueOf(index++),curJson);
			}else if(curPort.matches("gt \\d+")){
				String[] word=curPort.split(" ");
				if(port>Integer.parseInt(word[1]))returnJson.put(String.valueOf(index++),curJson);
			}else if(curPort.matches("range \\d+ \\d+")){
				String[] word=curPort.split(" ");
				if(port>=Integer.parseInt(word[1]) && port<=Integer.parseInt(word[2]))returnJson.put(String.valueOf(index++),curJson);
			}else throw new IllegalArgumentException("想定外PORT:"+curPort);
		}
		
		return returnJson;
	}
}
