import java.io.*;
import java.util.*;

public class Test01_LogParser{
	public static void main(String[] args) throws Exception{
		//旧ファイル削除
		LogParser.deleteFileAtFolder("../output");
		
		LinkedHashMap<String,List<String>> returnMap=LogParser.getLogMap("E:\\program\\@old\\Config2DB\\_退避");
		for(String curFileName:returnMap.keySet()){
			System.out.println(curFileName);
			
			//master準備
			LinkedHashMap<String,String> curMaster=new LinkedHashMap<String,String>();
			curMaster.put("ソースファイル",curFileName);
			
			//ログを取得
			List<String> curLog=returnMap.get(curFileName);
			
			//タイプを取得
			String typeStr=LogParser.getType(curLog);
			curMaster.put("機器タイプ",typeStr);
			if(typeStr==null)throw new IllegalArgumentException("機器タイプ未取得:"+curFileName);
			
			//タイプ別の対応
			if(typeStr.equals("CISCO")){
				//コンフィグ抽出
				List<String> curConfig=CiscoParser.extractConfig(curLog);
				
				//ホスト名抽出
				String hostname=CiscoParser.getHostname(curConfig);
				curMaster.put("hostname",hostname);
				if(hostname==null)throw new IllegalArgumentException("hostname未取得:"+curFileName);
				
				//インターフェース抽出
				CiscoParser.addInterface(curConfig,curMaster);
				
				//NAT抽出
				CiscoParser.addNat(curConfig,curMaster);
				
				//Static Route抽出
				CiscoParser.addStaticRoute(curConfig,curMaster);
				
				//access-list抽出
				CiscoParser.addAcl(curConfig,curMaster);
				
				//新access-list抽出
				CiscoParser.addAclNew(curConfig,curMaster);
				
				//show ip route抽出
				List<String> curShIpRou=CiscoParser.extractShIpRoute(curLog);
				CiscoParser.addLogRoute(curShIpRou,curMaster);
				
			}else if(typeStr.equals("CISCO_FW")){
				//コンフィグ抽出
				List<String> curConfig=CiscoFWParser.extractConfig(curLog);
				
				//ホスト名抽出
				String hostname=CiscoFWParser.getHostname(curConfig);
				curMaster.put("hostname",hostname);
				if(hostname==null)throw new IllegalArgumentException("hostname未取得:"+curFileName);
				
				//インターフェース抽出
				CiscoFWParser.addInterface(curConfig,curMaster);
				
				//Static Route抽出
				CiscoFWParser.addStaticRoute(curConfig,curMaster);
				
				//object-group抽出。object-group参照用のNJson作成のため一時的Map作成
				LinkedHashMap<String,String> objectGroupMap=new LinkedHashMap<String,String>();
				CiscoFWParser.addObjectGroup(curConfig,objectGroupMap);
				curMaster.putAll(objectGroupMap);
				NJson ogJson=new NJson();
				for(String pathStr:objectGroupMap.keySet()){
					String valueStr=objectGroupMap.get(pathStr);
					ogJson.addPathChild(pathStr,valueStr);
				}
				
				//access-group抽出
				CiscoFWParser.addAccessGroup(curConfig,curMaster);
				
				//access-list抽出
				CiscoFWParser.addAcl(curConfig,curMaster,ogJson);
				
			}else{
				//System.out.println(typeStr);
				continue;
			}
			
			//Json出力
			if(curMaster.size()>0){	//実質必ず0より大きくなる
				NJson outputJson=new NJson();
				for(String pathStr:curMaster.keySet()){
					String valueStr=curMaster.get(pathStr);
					outputJson.addPathChild(pathStr,valueStr);
				}
				PrintWriter wr=new PrintWriter(new FileWriter("../output/"+curMaster.get("hostname")+".json"));
				wr.println(outputJson.toPrettyJsonString());
				//System.out.println(outputJson.toPrettyJsonString());
				wr.close();
			}
			//break;
		}
	}
}
