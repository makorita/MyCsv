import java.util.*;

public class NetworkUtility{
	public static boolean isIfName(String curStr){
		if(curStr.matches("FastEthernet.*"))return true;
		if(curStr.matches("GigabitEthernet.*"))return true;
		if(curStr.matches("Vlan.*"))return true;
		if(curStr.matches("Tunnel.*"))return true;
		if(curStr.matches("BRI.*"))return true;
		if(curStr.matches("Dialer.*"))return true;
		
		return false;
	}
	
	public static boolean isProtocol(String curStr){
		if(curStr.equals("ip"))return true;
		if(curStr.equals("tcp"))return true;
		if(curStr.equals("udp"))return true;
		if(curStr.equals("icmp"))return true;
		if(curStr.equals("esp"))return true;
		if(curStr.equals("gre"))return true;
		if(curStr.equals("112"))return true;	//VRRP
		
		return false;
	}

	/**
	 * Ciscoのサービス名を対応するポート番号(String)に変換する
	 * @param serviceName サービス名 (例: "http", "ssh", "ftp")
	 * @return ポート番号の文字列 (例: "80")、未対応の場合は null
	 */
	public static String toPortNumber(String serviceName) {
		if(serviceName == null) return null;
		if(serviceName.matches("\\d+"))return serviceName;

		String name = serviceName.toLowerCase();

		if (name.equals("discard")) return "9";
		if (name.equals("ftp-data")) return "20";
		if (name.equals("ftp")) return "21";
		if (name.equals("ssh")) return "22";
		if (name.equals("telnet")) return "23";
		if (name.equals("smtp")) return "25";
		if (name.equals("domain")) return "53";
		if (name.equals("bootps")) return "67";
		if (name.equals("bootpc")) return "68";
		if (name.equals("tftp")) return "69";
		if (name.equals("http")) return "80";
		if (name.equals("www")) return "80";
		if (name.equals("pop3")) return "110";
		if (name.equals("sunrpc")) return "111";
		if (name.equals("nntp")) return "119";
		if (name.equals("ntp")) return "123";
		if (name.equals("netbios-ns")) return "137";
		if (name.equals("netbios-dgm")) return "138";
		if (name.equals("netbios-ss")) return "139";
		if (name.equals("netbios-ssn")) return "139";
		if (name.equals("imap")) return "143";
		if (name.equals("bftp")) return "152";
		if (name.equals("snmp")) return "161";
		if (name.equals("snmptrap")) return "162";
		if (name.equals("xdmcp")) return "177";
		if (name.equals("bgp")) return "179";
		if (name.equals("ldap")) return "389";
		if (name.equals("https")) return "443";
		if (name.equals("isakmp")) return "500";
		if (name.equals("exec")) return "512";
		if (name.equals("login")) return "513";
		if (name.equals("cmd")) return "514";
		if (name.equals("syslog")) return "514";
		if (name.equals("ldaps")) return "636";
		if (name.equals("ftps")) return "990";
		if (name.equals("telnets")) return "992";
		if (name.equals("imaps")) return "993";
		if (name.equals("pop3s")) return "995";
		throw new IllegalArgumentException("想定外ポート番号:"+serviceName);
	}

}
