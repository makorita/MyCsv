import java.io.*;
import java.util.*;

public class Test01_NJson{
	public static void main(String[] args) throws Exception{
		if(true){
			NJson curJson=NJsonParser.loadJson("test3.json");
			//System.out.println(curJson.toPrettyJsonString());
			//NJson childJson=curJson.getPathChild("AAA##dir1##dir2");
			//System.out.println(childJson.toPrettyJsonString());
			curJson.addPathChild("テスト##dir1##dir2##key2","AAA");
			System.out.println(curJson.toPrettyJsonString());
		}
	}
}
