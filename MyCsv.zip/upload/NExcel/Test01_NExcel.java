import java.io.*;
import java.util.*;

import org.apache.poi.*;
import org.apache.poi.ss.formula.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.openxml4j.exceptions.*;
import org.apache.poi.xssf.usermodel.*;

public class Test01_NExcel{
/*
javac -cp "./;lib/*" Test01_NExcel.java
java -cp "./;lib/*" Test01_NExcel
*/	
	public static void main(String[] args) throws Exception{
		if(false){
			NExcel curExl=new NExcel();
			ArrayList<String> headerList=new ArrayList<String>();
			headerList.add("test01");
			headerList.add("test02");
			headerList.add("test03");
			curExl.setHeader(headerList);
			System.out.println(curExl);
			
			System.out.println(curExl.getHeader(1));
			System.out.println(curExl.getHeaderSize());
			System.out.println(curExl.containsHeader("test02"));
			curExl.addHeader("test04");
			System.out.println(curExl);
			curExl.removeColumn("test02");
			System.out.println(curExl);
		}
		
		if(false){
			NExcel curExl=new NExcel();
			HashMap<String,String> tmpMap=new HashMap<String,String>();
			tmpMap.put("head01","value01");
			tmpMap.put("head02","value02");
			tmpMap.put("head03","value03");
			curExl.addRow(tmpMap);
			System.out.println(curExl);
			curExl.removeRow(0);
			System.out.println(curExl);
		}
		
		if(false){
			NExcel curExl=new NExcel();
			HashMap<String,String> tmpMap=new HashMap<String,String>();
			tmpMap.put("head01","value01");
			tmpMap.put("head02","value02");
			tmpMap.put("head03","value03");
			curExl.addRow(tmpMap);
			System.out.println(curExl.getValue(0,"head02"));
			System.out.println(curExl.containsKey(0,"head03"));
			System.out.println(curExl.containsKey(0,"head04"));
			curExl.setValue(0,"head04","value04");
			System.out.println(curExl);
			curExl.removeColValue(0,"head01");
			System.out.println(curExl);
		}
		
		//NExcelIO
		if(false){
			NExcel curExl=NExcelIO.loadExcel("Siken01.xlsx","Sheet1");
			//System.out.println(curExl);
			ArrayList<NExcel> returnList=NExcelIO.loadExcel("Siken01.xlsx");
			for(NExcel tmpExl:returnList){
				//System.out.println(tmpExl);
			}
			Workbook wb = new XSSFWorkbook();
			NExcelIO.saveExcel(curExl,wb,"test","Siken01_modified.xlsx");
		}
		
		//NExcelModifier,NExcelFilter
		if(true){
			NExcel curExl=NExcelIO.loadExcel("Siken01.xlsx","Sheet2");
			//NExcel returnExl=NExcelModifier.extractReturn(curExl,"header06");
			//System.out.println(returnExl);
			//NExcel returnExl=NExcelModifier.grouping(curExl,"header08");
			//NExcel returnExl=NExcelModifier.sort(curExl,"header09",false);
			//NExcel returnExl=NExcelModifier.replaceColumn(curExl,"header08","試験","しけん");
			//NExcel mapExl=NExcelIO.loadExcel("Siken01.xlsx","map");
			//HashMap<String,String> lookupMap=NExcelUtility.getLookupMap(mapExl,"key","value");
			//for(String key:lookupMap.keySet())System.out.println(key+","+lookupMap.get(key));
			//NExcel returnExl=NExcelModifier.addMapValue(curExl,lookupMap,"header07","vaule");
			//NExcel returnExl=NExcelFilter.matchFilter(curExl,"header06","TEST\\d{2}",false);
			//NExcel orgExl=NExcelIO.loadExcel("Siken01.xlsx","Sheet1");
			//NExcel addExl=NExcelIO.loadExcel("Siken01.xlsx","Sheet1dash");
			//NExcel returnExl=NExcelModifier.merge(orgExl,addExl);
			NExcel returnExl=NExcelFilter.rangeFilter(curExl,"header09",null,50.0);
			
			Workbook wb = new XSSFWorkbook();
			NExcelIO.saveExcel(returnExl,wb,"test","Siken01_modified.xlsx");
			
		}
		
		//IPFilter
		if(true){
			NExcel curExl=NExcelIO.loadExcel("Siken01.xlsx","Sheet2");
			
			//Address tmpAddr=new Address("10.0.0.1");
			//NExcel returnExl=NExcelFilter.containIPFilter(curExl,"header10",tmpAddr,false);
			Address tmpAddr=new Address("10.0.0.1/16");
			NExcel returnExl=NExcelFilter.containedIPFilter(curExl,"header11",tmpAddr,false);
			Workbook wb = new XSSFWorkbook();
			NExcelIO.saveExcel(returnExl,wb,"test","Siken01_modified.xlsx");
		}
	}
}
