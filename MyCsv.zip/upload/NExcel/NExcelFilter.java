import java.util.*;

public class NExcelFilter{
	public static NExcel getCopy(NExcel srcExl){
		NExcel returnExl=new NExcel();
		returnExl.setHeader(srcExl.getHeader());
		for(int rowIndex=0;rowIndex<srcExl.getContentSize();rowIndex++){
			HashMap<String,String> curRow=new HashMap<String,String>(srcExl.getRow(rowIndex));
			returnExl.addRow(curRow);
		}
		
		return returnExl;
	}
	
	public static NExcel matchFilter(NExcel srcExl,String colName,String reStr,boolean matchFlag){	//マッチ行でフィルタ
		NExcel returnExl=new NExcel();
		returnExl.setHeader(srcExl.getHeader());
		
		for(int rowIndex=0;rowIndex<srcExl.getContentSize();rowIndex++){
			String curStr=srcExl.getValue(rowIndex,colName);
			
			if(curStr==null){
				if(!matchFlag)returnExl.addRow(srcExl.getRow(rowIndex));
			}else if(matchFlag && curStr.matches(reStr))returnExl.addRow(srcExl.getRow(rowIndex));
			else if(!matchFlag && !curStr.matches(reStr))returnExl.addRow(srcExl.getRow(rowIndex));
		}
		
		return returnExl;
	}
	
	public static NExcel rangeFilter(NExcel srcExl,String colName,Double minValue,Double maxValue){	//範囲内フィルタ
		NExcel returnExl=new NExcel();
		returnExl.setHeader(srcExl.getHeader());
		
		for(int rowIndex=0;rowIndex<srcExl.getContentSize();rowIndex++){
			if(srcExl.getValue(rowIndex,colName)==null)continue;
			
			double curValue=Double.parseDouble(srcExl.getValue(rowIndex,colName));
			if(minValue!=null && curValue<minValue)continue;
			if(maxValue!=null && curValue>maxValue)continue;
			
			returnExl.addRow(srcExl.getRow(rowIndex));
		}
		
		return returnExl;
	}
	
	public static NExcel containIPFilter(NExcel srcExl,String colName,Address taisyouAddr,boolean matchFlag){	//対象IPが含まれるかフィルタ
		NExcel returnExl=new NExcel();
		returnExl.setHeader(srcExl.getHeader());
		
		for(int rowIndex=0;rowIndex<srcExl.getContentSize();rowIndex++){
			String curStr=srcExl.getValue(rowIndex,colName);
			if(curStr==null && matchFlag){	//Any扱い
				returnExl.addRow(srcExl.getRow(rowIndex));
				continue;
			}
			Address tmpAddr=new Address(curStr);
			if(matchFlag && AddressUtility.contains(tmpAddr,taisyouAddr))returnExl.addRow(srcExl.getRow(rowIndex));
			else if(!matchFlag && !AddressUtility.contains(tmpAddr,taisyouAddr))returnExl.addRow(srcExl.getRow(rowIndex));
		}
		
		return returnExl;
	}
	
	public static NExcel containedIPFilter(NExcel srcExl,String colName,Address checkAddr,boolean matchFlag){	//チェックIPに含まれるかフィルタ
		NExcel returnExl=new NExcel();
		returnExl.setHeader(srcExl.getHeader());
		
		for(int rowIndex=0;rowIndex<srcExl.getContentSize();rowIndex++){
			String curStr=srcExl.getValue(rowIndex,colName);
			Address tmpAddr=null;
			if(curStr==null){	//Any扱い
				tmpAddr=new Address("0.0.0.0/0");
			}else{
				tmpAddr=new Address(curStr);
			}
			if(matchFlag && AddressUtility.contains(checkAddr,tmpAddr))returnExl.addRow(srcExl.getRow(rowIndex));
			else if(!matchFlag && !AddressUtility.contains(checkAddr,tmpAddr))returnExl.addRow(srcExl.getRow(rowIndex));
		}
		
		return returnExl;
	}
}
