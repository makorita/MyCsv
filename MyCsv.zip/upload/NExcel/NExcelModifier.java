import java.util.*;

public class NExcelModifier{
	public static NExcel extractReturn(NExcel srcExl,String colName){	//colName列に改行を含むセルがあれば、分割してそれぞれの値を含む行に変換して追加する
		NExcel returnExl=new NExcel();
		returnExl.setHeader(srcExl.getHeader());
		for(int rowIndex=0;rowIndex<srcExl.getContentSize();rowIndex++){
			HashMap<String,String> curRow=new HashMap<String,String>(srcExl.getRow(rowIndex));
			String tmpStr=srcExl.getValue(rowIndex,colName);
			if(tmpStr==null){
				returnExl.addRow(curRow);
				continue;
			}else if(!tmpStr.contains("\n")){
				returnExl.addRow(curRow);
				continue;
			}
			
			String[] word=tmpStr.split("\n");
			for(String curStr:word){
				curRow.put(colName,curStr);
				returnExl.addRow(curRow);
			}
		}
		
		return returnExl;
	}
	
	public static NExcel grouping(NExcel srcExl,String colName){	//colName列を改行でまとめる
		NExcel returnExl=new NExcel();
		returnExl.setHeader(srcExl.getHeader());
		
		HashMap<String,Integer> rowStrMap=new HashMap<String,Integer>();	//HashMap<[対象列を省いた行文字列],[returnExlの方の行番号]>
		int returnRowIndex=0;
		for(int rowIndex=0;rowIndex<srcExl.getContentSize();rowIndex++){
			HashMap<String,String> curRow=new HashMap<String,String>(srcExl.getRow(rowIndex));
			String curValue=curRow.get(colName);
			if(curValue==null)continue;
			String curRowStr=srcExl.getRowStr(rowIndex);
			curRowStr=curRowStr.replace(","+curValue,"");
			curRowStr=curRowStr.replace(curValue,"");
			if(!rowStrMap.containsKey(curRowStr)){
				rowStrMap.put(curRowStr,returnRowIndex);
				returnExl.addRow(curRow);
				returnRowIndex++;
			}else{
				returnExl.setValue(rowStrMap.get(curRowStr),colName,returnExl.getValue(rowStrMap.get(curRowStr),colName)+"\n"+curValue);
			}
		}
		
		return returnExl;
	}
	
	public static NExcel sort(NExcel srcExl,String colName,boolean upperFlag){	//ソート。upperFlag:ture昇順
		NExcel returnExl=new NExcel();
		returnExl.setHeader(srcExl.getHeader());
		
		NExcel editExl=NExcelFilter.getCopy(srcExl);
		while(editExl.getContentSize()>0){
			HashMap<String,String> topRow=null;
			int topIndex=-1;
			for(int rowIndex=0;rowIndex<editExl.getContentSize();rowIndex++){
				HashMap<String,String> curRow=editExl.getRow(rowIndex);
				if(curRow.get(colName)==null)continue;
				if(topRow==null){
					topRow=curRow;
					topIndex=rowIndex;
					continue;
				}
				
				double curValue=Double.parseDouble(curRow.get(colName));
				double topValue=Double.parseDouble(topRow.get(colName));
				if(upperFlag && curValue<topValue){
					topRow=curRow;
					topIndex=rowIndex;
				}else if(!upperFlag && curValue>topValue){
					topRow=curRow;
					topIndex=rowIndex;
				}
			}
			returnExl.addRow(topRow);
			editExl.removeRow(topIndex);
		}
		
		return returnExl;
	}
	
	public static NExcel replaceColumn(NExcel srcExl,String colName,String befStr,String aftStr){	//指定列の値の置換
		NExcel returnExl=NExcelFilter.getCopy(srcExl);
		
		for(int rowIndex=0;rowIndex<returnExl.getContentSize();rowIndex++){
			if(returnExl.getValue(rowIndex,colName)==null)continue;
			
			returnExl.setValue(rowIndex,colName,returnExl.getValue(rowIndex,colName).replaceAll(befStr,aftStr));
		}
		
		return returnExl;
	}
	
	public static NExcel addMapValue(NExcel srcExl,HashMap<String,String> lookupMap,String keyColName,String valueColName){	//vlookup風
		NExcel returnExl=NExcelFilter.getCopy(srcExl);
		
		returnExl.addHeader(valueColName);
		for(int rowIndex=0;rowIndex<returnExl.getContentSize();rowIndex++){
			String curStr=returnExl.getValue(rowIndex,keyColName);
			if(curStr==null)continue;
			
			if(lookupMap.containsKey(curStr))returnExl.setValue(rowIndex,valueColName,lookupMap.get(curStr));
		}
		
		return returnExl;
	}
	
	public static NExcel merge(NExcel originalExl,NExcel addExl){	//Exl追加
		NExcel returnExl=NExcelFilter.getCopy(originalExl);
		
		for(int rowIndex=0;rowIndex<addExl.getContentSize();rowIndex++){
			returnExl.addRow(addExl.getRow(rowIndex));
		}
		
		return returnExl;
	}
}
