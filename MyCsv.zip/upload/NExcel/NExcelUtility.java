import java.util.*;

public class NExcelUtility{
	public static HashMap<String,String> getLookupMap(NExcel srcExl,String keyCol,String valueCol){	//key列とvalue列のMapを返す。キーは先勝ち
		HashMap<String,String> returnMap=new HashMap<String,String>();
		
		for(int rowIndex=0;rowIndex<srcExl.getContentSize();rowIndex++){
			String keyStr=srcExl.getValue(rowIndex,keyCol);
			String valueStr=srcExl.getValue(rowIndex,valueCol);
			if(keyStr==null)continue;
			if(valueStr==null)continue;
			
			if(!returnMap.containsKey(keyStr))returnMap.put(keyStr,valueStr);
		}
		
		return returnMap;
	}
}
